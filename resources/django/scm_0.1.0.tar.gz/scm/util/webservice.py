# -*- coding:utf8 -*-

import suds
import re
from scm.settings import WEBSERVICE_WSDL_URL
from scm.settings import WEBSERVICE_TIMEOUT

def remote_auth(username,password):
    client = suds.client.Client(WEBSERVICE_WSDL_URL, timeout = WEBSERVICE_TIMEOUT)
    result =  client.service.authenticate(username,password)
    return result['code']

def get_username(sessionID):
    username = None
    client = suds.client.Client(WEBSERVICE_WSDL_URL, timeout = WEBSERVICE_TIMEOUT)
    res =  client.service.sesTimeOut(sessionID)
    code = res['code']
    if code == 0:
        result = res['result']
        match = re.search('^uid=(.+?)\&', result)
        if match:
            username = match.group(1)
    return username


# -*- encoding=utf-8 -*-
"""
    This module implements multi-threading management:producer and consumer.
    There are three roles(classes) in this module, they are producer, consumer, and manager
"""
import Queue, threading, sys
from threading import Thread
import time
import urllib

debug_level = 0
done = True

# Producer thread
class Producer(Thread):
    count = 0  # the total number of producer thread 
    timeout = 2  # the max time for getting a task, default is 2s
    sleep = 2 # the producer's break time

    def __init__( self, proQueue, conQueue, **kwds):
        Thread.__init__( self, **kwds )
        self.id = Producer.count
        Producer.count += 1
        self.setDaemon(True)
        self.proQueue = proQueue
        self.conQueue = conQueue
        self.start()

    def run(self):
        ''' get the task from proQueue and deal with it '''
        global debug_level, done
        while done:
            try:
                produce, args, kwds = self.proQueue.get(timeout=Producer.timeout)
                try:
                    consume, goods = produce(*args, **kwds)
                    if consume:
                        self.conQueue.put((consume, goods))
                    else:
                        self.conQueue.put(goods)
                except ValueError:
                    res = produce(*args, **kwds)
                    self.conQueue.put(goods)
                if debug_level:
                    print "producer[%2d]: %s" % (self.id, str(goods))
                time.sleep(Producer.sleep)
            except Queue.Empty:
                pass
            except :
                print 'producer[%2d]' % self.id, sys.exc_info()[:2]
                raise

# Producer thread
class Consumer(Thread):
    count = 0  # the total number of producer thread 
    timeout = 2  # the max time for getting a piece of consumer goods, default is 2s
    sleep = 2 # the consumer's break time

    def __init__(self, conQueue, **kwds):
        Thread.__init__(self, **kwds)
        self.id = Consumer.count
        Consumer.count += 1
        self.setDaemon(True)
        self.conQueue = conQueue
        self.start()

    def run(self):
        ''' get the consumer goods from conQueue and deal with it '''
        global debug_level, done
        while done:
            try:
                res = 'consuming'
                try:
                    consume, goods = self.conQueue.get(timeout=Consumer.timeout)
                    res = consume(goods)
                except ValueError:
                    goods = self.conQueue.get(timeout=Consumer.timeout)
                if debug_level:
                    print "consumer[%2d]: %s" % (self.id, str(res))
                time.sleep(Consumer.sleep)
            except Queue.Empty:
                pass
            except :
                print 'consumer[%2d]' % self.id, sys.exc_info()[:2]
                raise

class Manager:
    def __init__(self, num_of_producer=10, num_of_consumer=10, timeout=2):
        self.proQueue = Queue.Queue()
        self.conQueue = Queue.Queue()
        self.producers = []
        self.consumers = []
        self.timeout = timeout
        self.num_of_producer = 0
        self.num_of_consumer = 0
        self.addProducer(num_of_producer)
        self.addConsumer(num_of_consumer)

    def get_num_of_producers():
        return self.num_of_producer

    def get_num_of_consumers():
        return self.num_of_consumer

    def addProducer(self, num_of_producer=0):
        for i in range(num_of_producer):
            producer = Producer(self.proQueue, self.conQueue)
            self.producers.append(producer)
        self.num_of_producer += num_of_producer
    
    def addConsumer(self, num_of_consumer=10):
        for i in range(num_of_consumer):
            consumer = Consumer(self.conQueue)
            self.consumers.append(consumer)
        self.num_of_consumer += num_of_consumer

    def wait_for_complete(self):
        # ...then, wait for each of them to terminate:
        global done
        sleep_time = 5
        while done:
            if self.proQueue.empty() and self.conQueue.empty():
                done = False
                print "All jobs are are completed."
            else:
                proLen = self.get_proQueueLen()
                conLen = self.get_conQueueLen()
                print "producer queue's length is %d"%proLen
                print "consumer queue's length is %d"%conLen
                #maxLen = max(proLen,conLen)
                time.sleep(5)

    def add_task(self, callable, *args, **kwds ):
        self.proQueue.put((callable, args, kwds))

    def get_conQueue(self):
        return self.conQueue

    def get_proQueueLen(self): # get current producer queue's length
        return self.proQueue.qsize()

    def get_conQueueLen(self): # get current producer queue's length
        return self.conQueue.qsize()

def produce(*args, **kwds):
    try:
        ret = ''
        url = kwds.get('url','')
        if url:
            ret = urllib.urlopen(url).read()
    except:
        print '[%4d]' % id, sys.exc_info()[:2]
    return (consume, ret)

def consume(goods, path='E:\\project\\sis\\log'):
    f = open(path + '\\index.html', 'a')
    f.write(goods)
    f.close()

def test():
    import socket
    socket.setdefaulttimeout(10)
    print 'start testing'
    l = ['http://www.baidu.com',
         'http://www.sina.com.cn',
         'http://www.163.com',
         'http://www.qq.com',
         'http://www.g.cn',
         ]
    m = Manager(len(l),2)
    for i in range(len(l)):
        m.add_task(produce, url=l[i])
    m.wait_for_complete()
    print 'end testing'

if __name__ == '__main__':
    test()

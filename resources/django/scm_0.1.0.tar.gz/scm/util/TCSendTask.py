#!/usr/bin/env python
#vim: set encoding=utf-8 :
import sys,os,string,time
import socket
import hashlib, urllib2,re,shutil
import tarfile
from django.db import connection
from scm.settings import ROOT_PATH

"""
Task to files
"""
class FPObject(object):
    def __init__(self,file,mode):
        self.__fp=open(file,mode)
        self.__buf=""
    def write(self,content):
        try:
            self.__fp.write(content)
        except Exception,e:
            pass
        try:
            self.__buf=self.__buf+content
        except Exception,e:
            pass
    def close(self):
        try:
            self.__fp.close()
        except Exception,e:
            pass
    def flush(self):
        try:
            self.__fp.flush()
        except Exception,e:
            pass
    def getContent(self):
        return self.__buf

class TCSendTask(object):
    """
    tasktype == 0 : 不需要TA/TE来获取而是通过应用程序自动发送过去
                    根据taskname来找对应的发送程序
    
    tasktype == 1 : TA/TE主动来拿任务
    
    TA/TE查询任务按照设备id查询，中央把所有这个设备的任务都告诉ta，
    ta汇报状态的时候要说明是哪个应用
    """
    FC_APP_ID="200102010001"
    CMP_APP_ID="200301020001"
    DLC_APP_ID="200301020002"
    DNS_APP_ID="200301020003"
    NPM_APP_ID="200301020004"
    NG_APP_ID="200101010001"
    def __init__(self,taskname='',user='',tasktype=0):
        self.m_fp_map={}
        self.m_fp_info_map={}
        self.m_atts=[]
        self.m_tar_md5hex=None
        self.m_basedir=("%s/media/task_files"%ROOT_PATH).replace('//','/')
        #self.m_basedir="D:/Workspace/python/webluker/media/task_files"
        self.m_sender=user
        self.m_taskname = taskname
        self.m_tar_file=None
        self.m_tasktype=tasktype
        strTime="%d"%(int(time.time()*1000))
        sub1=strTime[0:7]
        sub2=strTime[8:]
        if os.path.exists("%s/%s"%(self.m_basedir,sub1))==False:
            os.mkdir("%s/%s"%(self.m_basedir,sub1))
        if os.path.exists("%s/%s/%s"%(self.m_basedir,sub1,sub2))==False:
            os.mkdir("%s/%s/%s"%(self.m_basedir,sub1,sub2))
        self.m_dir="%s/%s/%s"%(self.m_basedir,sub1,sub2)
        self.m_subdir="%s/%s"%(sub1,sub2)
        
    def __del__(self):
        self.close()
    
    def open(self,filename,mode="w"):
        """
            打开一个文件句柄，如果已经打开就返回该句柄
        """
        if self.m_fp_map.has_key(filename):
            return self.m_fp_map[filename]
        else:
            fp=open("%s/%s"%(self.m_dir,filename),mode)
            if fp:
                self.m_fp_map[filename]=fp
            return fp
    def addExtFile(self,filepath):
        """
            该方法在调用压缩方法时候会用到
            主要是将某些固定文件如1.sh之类的文件也直接放在压缩包里面
        """
        self.m_atts.append(filepath)
        
    def _compress(self):
        """
            压缩任务的所有文件，包括打开的句柄和额外添加的文件
        """
        tpath = "%s/%s"%(self.m_dir,self.m_taskname)
        if os.path.exists(tpath)==False:
            os.mkdir(tpath)
        for f in self.m_fp_map.keys():
            self.m_fp_map[f].flush()
            self.m_fp_map[f].close()
            shutil.copy("%s/%s"%(self.m_dir,f),tpath)
        for f in self.m_atts:
            print "Copy %s==>%s"%(f,tpath)
            shutil.copy(f,tpath)
        self.m_tar_file = "%s/%s.tar.gz"%(self.m_dir,self.m_taskname)
        tar = tarfile.open(self.m_tar_file,"w:gz")
        tar.add("%s/%s"%(self.m_dir,self.m_taskname),self.m_taskname)
        tar.close()
        fp = open(self.m_tar_file,"rb")
        md5 = hashlib.md5()
        md5.update(fp.read())
        self.m_tar_md5hex ="%s"%md5.hexdigest()
        fp.close()
        
    def makeTar(self, compress=True):
        #如果没有调用压缩，说明该任务不需要压缩，为每个文件计算一个MD5直接入库
        if compress==False:
            for name in self.m_fp_map.keys():
                self.m_fp_map[name].flush()
                self.m_fp_map[name].close()
                fullpath_file = "%s/%s"%(self.m_dir,name)
                fp = open(fullpath_file,"r")
                md5 = hashlib.md5()
                md5.update(fp.read())
                md5hex ="%s"%md5.hexdigest()
                fp.close()
                
                self.m_fp_info_map[name] = ( fullpath_file, md5hex )
        else:
            self._compress()
            
    def send(self,device_sn, appId, info='',compress=True):
        """
            appId : 接收任务的应用Id
            targetId    : 接收任务的目标设备Id,当为None时,TCSendTask 自动找到这个应用的所有设备
            compress    : 用来指定该任务是否需要压缩,当多个附件的情况且有先后顺序最好用压缩方式当时协议本身要支持

            CREATE TABLE `TASK_QUEUE` (
              `id` int(15) NOT NULL auto_increment,
              `task_name` varchar(100)  NOT NULL,
              `file_path` varchar(255)  NOT NULL,
              `uri_file`  varchar(255)  NOT NULL,
              `file_md5`  varchar(128)  NOT NULL,
              `user_id`   bigint(11) not null ,
              `task_type` int(1) not null default 0,
              `target_id`    varchar(50) not null,
              `app_id`    varchar(50) not null,
              `status`    int(1) not null default 0,
              `add_time`  datetime not null,
              `update_time`  datetime not null,
              PRIMARY KEY  (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
        """
        cur=connection.cursor()
        #如果没有调用压缩，说明该任务不需要压缩，为每个文件计算一个MD5直接入库
        if compress==False:
            for fp_info in self.m_fp_info_map.keys():
                sql = "insert into common_task_queue(task_name,file_path,uri_file,file_md5,user_name,task_type,device_sn,app_id,status,add_time,update_time,task_info) values('%s','%s','%s','%s','%s',%d,'%s','%s',%d,now(),now(),'%s') "%(self.m_taskname,fp_info[0],self.m_subdir,fp_info[1],self.m_sender,self.m_tasktype,device_sn,appId,0,info)
                cur.execute(sql)
                connection.connection.commit()
        else:
            sql = """insert into common_task_queue(task_name,file_path,uri_file,file_md5,user_name,task_type,device_sn,app_id,status,add_time,update_time,task_info) 
                
                                    values('%s','%s','%s/%s.tar.gz','%s','%s',%d,'%s','%s',%d,now(),now(),'%s') 
                
                """ %(self.m_taskname,self.m_tar_file,self.m_subdir,self.m_taskname,self.m_tar_md5hex,self.m_sender,self.m_tasktype,device_sn,appId,0,info)
            
            
            cur.execute(sql)
            connection.connection.commit()
        cur.close()
        
    def close(self):
        del self.m_fp_map

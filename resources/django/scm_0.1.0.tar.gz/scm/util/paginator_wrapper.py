# -*- coding:utf8 -*-

from django.core.paginator import Paginator, EmptyPage, InvalidPage

def paginate(model_lst, page, count=30):

    paginator = Paginator(model_lst, count)

    try:
        content = paginator.page(page)
    except (EmptyPage, InvalidPage):
        content = paginator.page(paginator.num_pages)

    return content.object_list, content

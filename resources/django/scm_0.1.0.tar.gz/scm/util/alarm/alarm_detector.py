# -*- coding:utf8 -*-

from django.core.management import execute_manager
try:
    import settings # Assumed to be in the same directory.
    
except ImportError:
    import sys
    sys.stderr.write("Error: Can't find the file 'settings.py' in the directory containing %r. It appears you've customized things.\nYou'll have to run django-admin.py, passing it your settings module.\n(If the file settings.py does indeed exist, it's causing an ImportError somehow.)\n" % __file__)
    sys.exit(1)

def clearMonitorHistory():
    from scm.monitor.models import base_state_history,dns_state_history
    base_state_history.clearHistory()
    dns_state_history.clearHistory()
    
    
def sendBascDetect(dsn, data, recver_map):
    from scm.alarm.models import smtp,recver,base_threshold,dns_threshold
    from scm.common.models import group,application,device
    from scm.util.sendmail import CCSendMail
    
    
    smtp_list = smtp.objects.all()
    for item in device.objects.filter(sn=dsn):
        head = u'设备名：'+item.hostname + "<br>"
        head += u'设备类型：'+item.app.cn_name+ "<br>"
        head += u'所属解析组：'+item.group.name+ "<br>"
        if recver_map.has_key( item.app.cn_name + '@' + item.group.name ):
            for p in recver_map[item.app.cn_name + '@' + item.group.name ]:
                send=CCSendMail(smtp_list[0].host, smtp_list[0].user, smtp_list[0].passwd)
                send.setFromAlias(smtp_list[0].alias)
                send.sendHtml(p, smtp_list[0].titel.encode('utf8') + ' 基础状态告警', head+data)
                
                print "sendmail to " + p + "<br>"
                
def sendDnsDetect(dsn, data, recver_map):
    from scm.alarm.models import smtp,recver,base_threshold,dns_threshold
    from scm.common.models import group,application,device
    from scm.util.sendmail import CCSendMail
    
    smtp_list = smtp.objects.all()
    for item in device.objects.filter(sn=dsn, app__id='200301020003'):
        head = u'设备名：'+item.hostname + "<br>"
        head += u'设备类型：'+item.app.cn_name+ "<br>"
        head += u'所属解析组：'+item.group.name+ "<br>"
        if recver_map.has_key( item.app.cn_name + '@' + item.group.name ):
            for p in recver_map[item.app.cn_name + '@' + item.group.name ]:
                send=CCSendMail(smtp_list[0].host, smtp_list[0].user, smtp_list[0].passwd)
                send.setFromAlias(smtp_list[0].alias)
                send.sendHtml(p, smtp_list[0].titel.encode('utf8') + ' DNS状态告警', head+data)
                
                print "sendmail to " + p + "<br>"

def runDetector():
    from scm.alarm.models import smtp,recver,base_threshold,dns_threshold
    from scm.monitor.models import base_state,dns_state
    #from scm.common.models import group,appliaction
    import time
    from time import mktime
    import datetime
    
    base_th_map = {}
    for item in base_threshold.objects.all():
        base_th_map[item.group_id] = item
     
    dns_th_map = {}
    for item in dns_threshold.objects.all():
        dns_th_map[item.group_id] = item
        
    recver_map = {}
    for item in recver.objects.all():
        groups = item.group_list.split('|')
        apps = item.app_list.split('|')
        for a in apps:
            for g in groups:
                if not recver_map.has_key( a+'@'+g ):
                    recver_map[a+'@'+g] = []
                recver_map[a+'@'+g].append(item.email)

    blist = base_state.getState()
    dlist = dns_state.getState()
    
    now_time = time.time()
    for item in blist:
        #detect base stat.
        alarm = ''
        
        last_up = mktime( datetime.datetime.strptime(item[13], '%Y-%m-%d %X').timetuple() )
        if (last_up < now_time-60*5):
            alarm += u"设备5分值内没有基础状态汇报<br>"
        
        if int(base_th_map[item[0]].mem_left)>0 and int(item[5]) < int(base_th_map[item[0]].mem_left):
            alarm += u"设备可用内存低于阀值,"  + str(item[5]) + u"低于" + str(base_th_map[item[0]].mem_left) + "<br>"
            
        if int(base_th_map[item[0]].load)>0 and float(item[6]) > float(base_th_map[item[0]].load):
            alarm += u"设备负载高于阀值,"  + str(item[6]) + u"高于" + str(base_th_map[item[0]].load) + "<br>"
            
        if int(base_th_map[item[0]].out_put)>0 and int(item[7]) > int(base_th_map[item[0]].out_put):
            alarm += u"设备输出带宽高于阀值,"  + str(item[7]) + u"高于" + str(base_th_map[item[0]].out_put) + "<br>"
            
        if int(base_th_map[item[0]].mem_left)>0 and int(item[8]) > int(base_th_map[item[0]].in_put):
            alarm += u"设备输入带宽高于阀值,"  + str(item[8]) + u"高于" + str(base_th_map[item[0]].in_put) + "<br>"
            
        if int(base_th_map[item[0]].connects)>0 and int(item[9]) > int(base_th_map[item[0]].connects):
            alarm += u"设备连接数高于阀值,"  + str(item[9]) + u"高于" + str(base_th_map[item[0]].connects) + "<br>"
        
        if int(base_th_map[item[0]].tasks)>0 and int(item[10]) > int(base_th_map[item[0]].tasks):
            alarm += u"设备任务数高于阀值,"  + str(item[10]) + u"高于" + str(base_th_map[item[0]].tasks) + "<br>"
            
        if int(base_th_map[item[0]].df_use)>0 and int(item[11]) > int(base_th_map[item[0]].df_use):
            alarm += u"设备磁盘利用率高于阀值,"  + str(item[11]) + u"高于" + str(base_th_map[item[0]].df_use) + "<br>"
            
        if len(alarm) > 0:
            sendBascDetect(item[14], alarm, recver_map)
        
    for item in dlist:
        alarm = ''
        
        last_up = mktime( datetime.datetime.strptime(item[12], '%Y-%m-%d %X').timetuple() )
        if (last_up < now_time-60*5):
            alarm += u"设备5分值内没有基础状态汇报<br>"
        
        if int(item[3]) != 0:
            alarm += u"设备DNS进程没有启动" + "<br>"
            
        if int(item[4]) != 0:
            alarm += u"设备DNS服务不可用" + "<br>"
            
        if int(dns_th_map[item[0]].total_query)>0 and int(item[5]) > int(dns_th_map[item[0]].total_query):
            alarm += u"设备每分钟访问量高于阀值,"  + str(item[5]) + u"高于" + str(dns_th_map[item[0]].total_query) + "<br>"
            
        if int(dns_th_map[item[0]].ip_max_query)>0 and int(item[6]) > int(dns_th_map[item[0]].ip_max_query):
            alarm += u"设备每分钟单IP访问量高于阀值,"  + str(item[6]) + u"高于" + str(dns_th_map[item[0]].ip_max_query) + "<br>"
          
        if int(dns_th_map[item[0]].domain_max_query)>0 and int(item[7]) > int(dns_th_map[item[0]].domain_max_query):
            alarm += u"设备每分钟单域名访问量高于阀值,"  + str(item[7]) + u"高于" + str(dns_th_map[item[0]].domain_max_query) + "<br>"
        
        if int(dns_th_map[item[0]].recursion_query)>0 and int(item[9]) > int(dns_th_map[item[0]].recursion_query):
            alarm += u"设备每分钟递归次数高于阀值,"  + str(item[9]) + u"高于" + str(dns_th_map[item[0]].recursion_query) + "<br>"
        
        if int(dns_th_map[item[0]].recursion_time)>0 and int(item[10]) > int(dns_th_map[item[0]].recursion_time):
            alarm += u"设备每分钟递归平均时间高于阀值,"  + str(item[10]) + u"高于" + str(dns_th_map[item[0]].recursion_time) + "<br>"
        
        if int(dns_th_map[item[0]].poison_count)>0 and int(item[11]) > int(dns_th_map[item[0]].poison_count):
            alarm += u"设备每分钟投毒数高于阀值,"  + str(item[11]) + u"高于" + str(dns_th_map[item[0]].poison_count) + "<br>"
            
        if len(alarm) > 0:
            sendDnsDetect(item[13], alarm, recver_map)
    
        
if __name__ == "__main__":
    try:
        execute_manager(settings)
        clearMonitorHistory()
        runDetector()
        print 'all done.'
    except:
        raise


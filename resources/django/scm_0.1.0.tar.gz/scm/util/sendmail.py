#/usr/bin/env python
# -*- encoding=utf-8 -*-

import socket,string,time,os,sys
import base64
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text  import MIMEText

class CCSendMail:
    def __init__(self,host="smtp.qiye.163.com",username='helper@webluker.com',password='12345678@WLK'):
        self.__smtp=smtplib.SMTP(host)
        self.__subject=None
        self.__content=None
        self.__from=None
        self.__to=[]
        self.__style='html'
        self.__charset='UTF-8'
        self.username = username
        self.password = password
        self.fromAlias='SSR'
        
    def close(self):
        try:
            self.__smtp.quit()
        except Exception ,e:
            pass   
    def setFromAlias(self,alias):
        self.fromAlias=alias
    def setStyle(self,style):
        self.__style = style
        
    def setSubject(self,subject):
        self.__subject=subject
        
    def setContent(self,content):
        self.__content=content
        
    def setFrom(self,address):
        self.__from=address
        
    def addTo(self,address):
        self.__to.append(address)
        
    def setCharset(self,charset):
        self.__charset=charset
        
    def send(self):
        try:
            self.__smtp.set_debuglevel(1)
            
            #login if necessary
            if self.username and self.password:
                #self.__smtp.starttls() #only for gmail
                self.__smtp.login(self.username,self.password)
                
            msgRoot = MIMEMultipart('related')
            msgRoot['Subject'] = self.__subject
            aliasB6=base64.encodestring(self.fromAlias.encode(self.__charset))
            msgRoot['From'] = "=?%s?B?%s?=%s"%(self.__charset,aliasB6.strip(),self.__from)
            msgRoot['To'] = ";".join(self.__to)
            
            
            msgAlternative = MIMEMultipart('alternative')
            msgRoot.attach(msgAlternative)
            
            msgText = MIMEText(self.__content, self.__style,self.__charset)
            msgAlternative.attach(msgText)

            self.__smtp.sendmail(self.__from,self.__to,msgRoot.as_string())
            return True
        except Exception,e:
            print "Error ",e
            return False
        
    def clearRecipient(self):
        self.__to = []
    
    def sendHtml(self,address,title,content):
        self.setStyle('html')
        self.setFrom("<%s>" % self.username)
        if not isinstance(content,str):
            content = content.encode('utf8')
        self.addTo(address)
        self.setSubject(title)
        self.setContent(content)
        self.send()
        self.close()

def main():
    send=CCSendMail('smtp.qiye.163.com','helper@webluker.com','12345678@WLK')
    send.setFromAlias(u"QQ管理员")
    send.sendHtml('zhanglihai.com@gmail.com',u'测试',u'Webluker测试')
    
if __name__=='__main__':
    #bma_sendmail("Hello")
    main()

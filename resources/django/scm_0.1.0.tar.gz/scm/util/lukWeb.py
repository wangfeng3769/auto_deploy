#!/usr/bin/python
# -*- coding: utf-8 -*-
# vim: set encoding=utf-8:
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.views.generic import list_detail
from django.db.backends import util
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.template import RequestContext
from django.db import connection
from scm.user.models import ChildUser, DeviceInfo, OperateLog
import cPickle as pickle
import re

def alertMessagesForIndex(request,title,desc,left_tpl=None):
    """
       用于 提交表单后的处理界面或者某些错误提示界面 (webluker主页)
    """
    if not left_tpl:
        path_info=request.path_info
        path_info = path_info[1:]
        p = path_info.find("/")
        path_info=path_info[0:p]
        left_tpl="left_%s.html"%(path_info.lower())
    return render_to_response('message.html',{'left_menu':left_tpl,'process_title':title,'process_desc':desc},context_instance=RequestContext(request))

def addUserIp(userId,ip):
    # 添加用户ip信息
    try:
        cur = connection.cursor()
        cur.execute("replace into USER_IP_RESOURCE(userId,ip) values(%d,'%s')"%(userId,ip))
        cur.close()
    except Exception,e:
        pass
    
def addUserDevice(userId,devName,devIp):
    # 添加用户设备记录
    try:
        cur = connection.cursor()
        cur.execute("replace into USER_DEVICE_RESOURCE(userId,devName,devIp) values(%d,'%s','%s')"%(userId,devName,devIp))
        cur.execute("replace into USER_IP_RESOURCE(userId,ip) values(%d,'%s')"%(userId,devIp))
        cur.close()
    except Exception,e:
        pass


"""
   Author: shengli.zhang
   Function：用于分页的函数
   Arguments：
        hits: 记录总数
        pagenav: 分页URL链接的前缀(若URL中不带任何参数需以?结尾）
        results_per_page: 每页记录数，默认30
        page: 当前页，默认第一页
   return：字典，包含是否有上一页或下一页的标志、记录起止序号等等。
"""
def split_page(hits, pagenav, results_per_page=30, page=1):
    pages = hits/results_per_page
    if hits%results_per_page > 0:
        pages += 1
    has_previous = False
    has_next = False
    previous = 0
    next = 0
    if pages > 1:
        if page == 1:
            has_next = True
            next = page + 1
        elif page < pages:
            has_previous = True
            previous = page -1
            has_next = True
            next = page + 1
        elif page == pages:
            has_previous = True
            previous = page -1
    start = (page-1)*results_per_page
    end = start + results_per_page
    if end > hits:
        end = hits
    pagination = {'hits':hits, 'pages':pages, 'results_per_page':results_per_page, 'has_previous':has_previous,
                  'previous':previous, 'has_next':has_next, 'next':next, 'page':page, 'pagenav':pagenav, 'start':start, 'end':end}
    return pagination

"""
    Author: shengli.zhang
    Function：求A、B两个集合的交集、并集、差集
    Arguments：
        A: 集合1，可以为列表或元组
        B: 集合2，可以为列表或元组
        t: 计算类型，A^B求交集，A+B求并集，A-B求属于A不属于B的集合（同理，B-A），A-B&B-A包含A-B与B-A，返回两个集合
        blank:是否允许集合中有空元素，blank=True可以允许，即不过滤集合中的空元素，blank=False过滤A与B内的空元素
    return：当t不为A-B&B-A时，返回列表，否则返回元组，元组内包含两个列表，分别代表A-B和B-A
"""
def intersect(A,B,t='A^B',blank=True):
    d = {}
    C = None
    if len(A) > len(B):
        C = A
        A = B
        B = C    
    for a in A:
        if not blank and not a:
            continue
        if C == None:
            d[a] = [1,'A']
        else:
            d[a] = [1,'B']
    for b in B:
        if not blank and not b:
            continue
        if d.has_key(b):
            d[b][0] += 1
            d[b][1] = 'A^B'
        else:
            if C == None:
                d[b] = [1, 'B']
            else:
                d[b] = [1, 'A']

    items = d.items()
    if t == 'A^B':
        return [x[0] for x in items if x[1][0]>1]
    elif t == 'A+B':
        return [x[0] for x in items]
    elif t == 'A-B':
        return [x[0] for x in items if x[1][1]=='A']
    elif t == 'B-A':
        return [x[0] for x in items if x[1][1]=='B']
    elif t == 'A-B&B-A':
        a_b = []
        b_a = []
        for x in items:
            if x[1][1] == 'A':
                a_b.append(x[0])
            elif x[1][1] == 'B':
                b_a.append(x[0])
        return (a_b, b_a)
    else:
        return []

def getUser(request):
    if 'cur_user_id' in request.session:
        cur_user_id = int(request.session['cur_user_id'])
        if not is_father_son(request.user,cur_user_id):
            return request.user
        try:
            return User.objects.get(id=cur_user_id)
        except User.DoesNotExist:
            return request.user
    else:
        return request.user

def is_father_son(user_f, user_s):
    try:
        user_f = isUserExist(user_f)
        user_s = isUserExist(user_s)
        if not user_f or not user_s:
            return False
        if user_f.is_superuser and not user_s.is_superuser:
            return True
        if user_f.has_module_perms('common') and not user_s.has_module_perms('common'):
            return True
        cu = ChildUser.objects.get(puser=user_f,cuser=user_s)
        return True
    except ChildUser.DoesNotExist:
        return False

def isUserExist(identification):
    try:
        if isinstance(identification,User):
            return identification
        elif isinstance(identification,int):
            user = User.objects.get(id=identification)
        else:
            user = User.objects.get(username=identification)
        return user
    except User.DoesNotExist:
        return None

def generateXmlMessage(message,redirect=''):
    xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
    xml = '<root>'
    xml += '<message>%s</message>'%message
    xml += '<redirect>%s</redirect>'%redirect
    xml += '</root>'
    return xml

def addUserDev(user,ip,service=''):#user is User object or user_id, service is like MiniCDN、域名管理等
    if SD.has_key(service):
        service = SD[service]
    try:
        if isinstance(user,int):
            user = User.objects.get(id=user)
        elif not isinstance(user,User):
            return 'argument is error'
        
        deviceinfo = DeviceInfo.objects.filter(user=user,ip=ip)
        if deviceinfo:
            dev = deviceinfo[0]
            if not dev.belong:
                dev.belong = '%s;'%service
                dev.save()
            elif dev.belong.find(service) == -1:
                dev.belong += '%s;'%service
                dev.save()
            return ''
        device = DeviceInfo(user=user,ip=ip,belong='%s;'%service)
        #from webluker.seeG.get_ipset import Cipset
        #device.ipset=Cipset.getIpset(ip)['info']
        device.save()
        return ''
    except Exception,e:
        return str(e)

#----------------------------------------------------------------------
Service_Type = {
'group':0,
'device':1,
'gslb':2,
'zone':3,
'acl':4,
'nameid':5,
'black':6,
'operate':7,
'alarm':8,
'user':9
}

def writeLog(uid, uservice, uinfo):
    try:
        lg = OperateLog()
        lg.service = Service_Type[uservice]
        lg.user_id = uid
        lg.info = uinfo[:128]
        lg.save()
    except:
        pass


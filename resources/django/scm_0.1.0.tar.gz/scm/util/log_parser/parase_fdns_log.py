# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from dbsettings import get_conn_log, LOG_UNIQ
import datetime,time,os,sys,re

"""
|210.83.229.254|cc00065.h.cncssr.chinacache.net|cnc-s|123.235.43.118;123.235.43.96;|cnc-sh-zj;default;|A|success|-E|qr aa ad |40046|

目前准备处理两个表
1,按 域名 + 请求类型 + 解析状态
 xxx cc00065.h.cncssr.chinacache.net|A|success

2，按IP + 请求类型 + 解析状态
 xxx 210.83.229.254|A|success
"""


RESPONE = {
'success':'queries_ok_count',
'referral':'queries_ref_count',
'nxrrset':'queries_nxr_count',
'nxdomain':'queries_nxd_count',
'recursion':'queries_rec_count',
'failure':'queries_fail_count'
}

def importDomainLog(conn, filename, dt, sn='-'):
    p_domain = re.compile('^[\t ]*([0-9]{1,11})[\t ]+([0-9a-zA-Z\-\.]{1,255})\|([a-zA-Z]{0,20})[\t \r\n]*')
    
    qtype = '-'
    cursor = conn.cursor()
    fp = open( filename )
    for eachLine in fp:
        mA = p_domain.search(eachLine)
	if mA:
	    try:
		up_count = cursor.execute("""
		UPDATE domain_sum_%s
		SET queries_count=queries_count+%d,%s=%s+%d
		WHERE domain='%s' AND device_sn='%s'
		""" %(dt, int(mA.groups()[0]), RESPONE[mA.groups()[2]], RESPONE[mA.groups()[2]], int(mA.groups()[0]), mA.groups()[1], sn) 
		)
		if up_count==0:
		    if mA.groups()[2]=="success":
			cursor.execute("""
			INSERT INTO domain_sum_%s VALUES
			('%s','%s','%s',%d,%d,0,0,0,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="referral":
			cursor.execute("""
			INSERT INTO domain_sum_%s VALUES
			('%s','%s','%s',%d,0,%d,0,0,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="nxrrset":
			cursor.execute("""
			INSERT INTO domain_sum_%s VALUES
			('%s','%s','%s',%d,0,0,%d,0,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="nxdomain":
			cursor.execute("""
			INSERT INTO domain_sum_%s VALUES
			('%s','%s','%s',%d,0,0,0,%d,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="recursion":
			cursor.execute("""
			INSERT INTO domain_sum_%s VALUES
			('%s','%s','%s',%d,0,0,%d,0,%d,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="failure":
			cursor.execute("""
			INSERT INTO domain_sum_%s VALUES
			('%s','%s','%s',%d,0,0,%d,0,0,%d)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
	    except:
		pass
    fp.close()
    os.remove(filename)

def importLocaldnsLog(conn, filename, dt, sn='-'):
    p_localdns = re.compile('^[\t ]*([0-9]{1,11})[\t ]+([0-9\.]{1,15})\|([a-zA-Z]{0,20})[\t \r\n]*')
    
    qtype = '-'
    cursor = conn.cursor()
    fp = open( filename )
    for eachLine in fp:
        mA = p_localdns.search(eachLine)
	if mA:
	    try:
		#print mA.groups()[0] + mA.groups()[1] + qtype + mA.groups()[2]
		up_count = cursor.execute("""
		UPDATE localdns_sum_%s
		SET queries_count=queries_count+%d,%s=%s+%d
		WHERE localdns='%s' AND device_sn='%s'
		""" %(dt, int(mA.groups()[0]), RESPONE[mA.groups()[2]], RESPONE[mA.groups()[2]], int(mA.groups()[0]), mA.groups()[1], sn)
		)
		if up_count==0:
		    if mA.groups()[2]=="success":
			cursor.execute("""
			INSERT INTO localdns_sum_%s VALUES
			('%s','%s','%s',%d,%d,0,0,0,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="referral":
			cursor.execute("""
			INSERT INTO localdns_sum_%s VALUES
			('%s','%s','%s',%d,0,%d,0,0,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="nxrrset":
			cursor.execute("""
			INSERT INTO localdns_sum_%s VALUES
			('%s','%s','%s',%d,0,0,%d,0,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="nxdomain":
			cursor.execute("""
			INSERT INTO localdns_sum_%s VALUES
			('%s','%s','%s',%d,0,0,0,%d,0,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="recursion":
			cursor.execute("""
			INSERT INTO localdns_sum_%s VALUES
			('%s','%s','%s',%d,0,0,%d,0,%d,0)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
		    elif mA.groups()[2]=="failure":
			cursor.execute("""
			INSERT INTO localdns_sum_%s VALUES
			('%s','%s','%s',%d,0,0,%d,0,0,%d)
     
			""" %(dt,mA.groups()[1], sn, qtype, int(mA.groups()[0]), int(mA.groups()[0]) ) 
			)
	    except:
		pass
    fp.close()
    os.remove(filename)

def runLogPraser(path):
    tm = str(datetime.date.today().year)[2:] + str(datetime.date.today().month) + str(datetime.date.today().day)
    print str(time.localtime()) + "run log parser..."
    conn = get_conn_log()

    p_domain = re.compile('^uniq_domain_([0-9a-zA-Z\-]{1,16})_([0-9]{1,30})')
    p_localdns = re.compile('^uniq_localdns_([0-9a-zA-Z\-]{1,16})_([0-9]{1,30})')
    
    os.chdir(path)
    dirs = os.listdir( os.getcwd() )
    for fl in dirs:
        subpath = os.path.join(path , fl)
        if not os.path.isdir(subpath):
            if fl.startswith('uniq_domain_'):
		mA = p_domain.search(fl)
		if mA:
		    #print mA.groups()[0]
		    importDomainLog(conn, subpath, tm, mA.groups()[0])
            elif fl.startswith('uniq_localdns_'):
		mA = p_localdns.search(fl)
		if mA:
		    #print mA.groups()[0]
		    importLocaldnsLog(conn, subpath, tm, mA.groups()[0])

    conn.close()    
    print "log parser finish.\n"
    
if __name__=='__main__':
    #runLogPraser("c:\\")
    runLogPraser(LOG_UNIQ)
    



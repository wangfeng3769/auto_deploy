# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from dbsettings import get_conn_log
import datetime	 

def createDomainSum(conn, dt):
    sql = """CREATE TABLE `domain_sum_%s` (
      `domain` VARCHAR(255) NOT NULL DEFAULT '',
      `device_sn` CHAR(16)  NOT NULL,
      `queries_type` CHAR(5) NOT NULL,
      `queries_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_ok_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_ref_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_nxr_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_nxd_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_rec_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_fail_count` INT(11) UNSIGNED DEFAULT '0',
      KEY `index_domain_sum_%s` (`domain`,`device_sn`,`queries_type`,`queries_count`)
    ) 
    """ % (dt, dt)
    
    print sql
    cursor = conn.cursor()
    cursor.execute(sql)
    cursor.fetchall()
    
def createIpSum(conn, dt):
    sql="""CREATE TABLE `localdns_sum_%s` (
      `localdns` VARCHAR(15) NOT NULL DEFAULT '',
      `device_sn` CHAR(16)  NOT NULL,
      `queries_type` CHAR(5) NOT NULL,
      `queries_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_ok_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_ref_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_nxr_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_nxd_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_rec_count` INT(11) UNSIGNED DEFAULT '0',
      `queries_fail_count` INT(11) UNSIGNED DEFAULT '0',
      KEY `index_localdns_sum_%s` (`localdns`,`device_sn`,`queries_type`,`queries_count`)
    ) 
    """% (dt, dt)
    
    print sql
    cursor = conn.cursor()
    cursor.execute(sql)
    cursor.fetchall()
    
if __name__=='__main__':
    tm = str(datetime.date.today().year)[2:] + str(datetime.date.today().month) + str(datetime.date.today().day)
    conn = get_conn_log()
    
    createDomainSum(conn, tm)
    createIpSum(conn, tm)
    
    conn.close()    
    print "create log tables [" + tm + "] ok\n"
    

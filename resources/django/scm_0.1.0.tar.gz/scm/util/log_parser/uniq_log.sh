#!/bin/sh

#echo '1'
LOG_PATH='/data/cache1/upload/'
LOG_UNIQ='/data/cache1/uniq/'
LOG_BACKUP='/data/cache1/backup/'

#echo `ps ax|grep "uniq_log.sh"|grep -v grep`
#if [ $(ps ax|grep "uniq_log.sh"|grep -v grep|wc -l) -lt 2 ] ; then
#        echo "now run uniq log process."
#else
#        echo "uniq log process is already exist."
#	 exit 0
#fi

#echo '3'
LOG_TIME=`date -d '-1 hour' +'%Y%m%d%H%M%S'`
BACK_TIME=`date -d '-1 hour' +'%Y%m%d'`
cd $LOG_PATH
mv queries.log.* $LOG_UNIQ
cd $LOG_UNIQ
zcat  queries.log.*|cut -f 2,5 -d '|' |sort| uniq -c > temp_uniq_domain_SN_$LOG_TIME
mv temp_uniq_domain_SN_$LOG_TIME uniq_domain_SN_$LOG_TIME
zcat  queries.log.*|cut -f 1,5 -d '|' |sort| uniq -c > temp_uniq_localdns_SN_$LOG_TIME
mv temp_uniq_localdns_SN_$LOG_TIME uniq_localdns_SN_$LOG_TIME
mkdir -p $LOG_BACKUP/$BACK_TIME
mv queries.log.* $LOG_BACKUP/$BACK_TIME




# -*- coding:utf8 -*-

import MySQLdb

LOG_PATH='/data/cache1/upload/'
LOG_UNIQ='/data/cache1/uniq/'
LOG_BACKUP='/data/cache1/backup/'

#connect log db
def get_conn_log():
   return  MySQLdb.connect(user='root', db='scm_log', passwd='webluker_test', host='localhost', use_unicode=True, charset='utf8')



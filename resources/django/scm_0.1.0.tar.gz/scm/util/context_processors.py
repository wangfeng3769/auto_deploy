# encoding=utf8

from django.template import RequestContext
from scm.user.models import User_Power
from scm.util.lukWeb import getUser

def power(request):
    "A context processor that provides service list of user."
    power = {'power':0}
    user = getUser(request)
    if 'AnonymousUser' == str(user):
        return power
    
    if user.is_superuser:
        power['power'] = 1000
    else:
        try:
            obj = User_Power.objects.get(user=user)
            power['power'] =  obj.power
        except:
            pass
    
    return power
    

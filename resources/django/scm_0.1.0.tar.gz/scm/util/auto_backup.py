# -*- coding:utf8 -*-

import sys
import os
import time

workpath = "%s/../../" % os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, workpath)
sys.path.insert(0, os.path.join(workpath, 'scm'))

from django.core.management import execute_manager
from scm.settings import DATABASES
from scm.settings import BACKUP_DIR

try:
    from scm import settings
except ImportError:
    pass
execute_manager(settings)

from scm.backup.models import Backup
from scm.backup.models import Zone
from scm.config.models import zone_head

def run_zone_backup(table, condition, backup_file):
    database = DATABASES['default']

    if database['PASSWORD'] == '':
        cmd = "mysqldump -u%(username)s \
--add-drop-table=FALSE \
--no-create-info=TRUE \
%(databasename)s %(table)s \
'-w%(condition)s' > \
%(backup_file)s" % {
            'username':database['USER'],
            'databasename': database['NAME'],
            'table': table,
            'condition': condition,
            'backup_file': backup_file,
    }
    else:
        cmd = "mysqldump -u%(username)s -p%(password)s \
--add-drop-table=FALSE \
--no-create-info=TRUE \
%(databasename)s %(table)s \
'-w%(condition)s' > \
%(backup_file)s" % {
            'username':database['USER'],
            'password':database['PASSWORD'],
            'databasename': database['NAME'],
            'table': table,
            'condition': condition,
            'backup_file': backup_file,
    }

    result = False
    if os.system(cmd) == 0 and os.path.exists(backup_file): result = True

    return result

def main():

    time_stamp = time.strftime('%Y%m%d%H%M%S',time.localtime(time.time()))
    name = 'auto_%s' % time_stamp
    detail = 'auto'
    user_id = 1

    try:
        Backup.objects.get(name=name)
        return False
    except:
        backup = Backup.objects.create(name=name, detail=detail)

        zone_name_list = zone_head.objects.values_list('id', 'zone_name')

        for zone_id, zone_name in zone_name_list:

            head_file = '%s/head_%s_%s.sql' % (BACKUP_DIR, zone_name, name)
            head_condition = 'zone_name="%s"' % zone_name
            record_file = '%s/record_%s_%s.sql' % (BACKUP_DIR, zone_name, name)
            record_condition = 'zone_head_id=%s' % zone_id
            userzone_file = '%s/userzone_%s_%s.sql' % (BACKUP_DIR, zone_name, name)
            userzone_condition = 'zone_id=%s' % zone_id

            if run_zone_backup('config_zone_head', head_condition, head_file) and \
                run_zone_backup('config_zone_record', record_condition, record_file) and \
                run_zone_backup('user_userzone', userzone_condition, userzone_file):

                Zone.objects.create(
                            backup=backup,
                            name=zone_name,
                            head_file=head_file,
                            record_file=record_file,
                            userzone_file=userzone_file
                        )

                #writeLog(user_id, 'black', '添加域名备份:%s' % name)
            else:
                return False

    return True

if __name__ == '__main__':
    print main()


# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

import time
import os
import re
import sys  

########################################################################
class CommonDig:
    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""

      
    #----------------------------------------------------------------------
    def spliteDigret(self, ret_list, rsptime):
        result = {}
        
        result["ldns"] = self.ldns
        result["domain"] = self.domain
        result["rsptime"] = rsptime
        result["rr_cname"] = []
        result["rr_a"] = []
	result["rr_ns"] = []
        result["rr_mx"] = []
	result["rr_aaaa"] = []
        result["rr_ptr"] = []
	result["rr_txt"] = []
        result["istimeout"] = False
        result["hasresult"] = False
        
        pA = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+A[\t ]+([0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3})[\t \r\n]*')
	pNS = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+NS[\t ]+([\.0-9a-zA-Z\-]{1,256})[\t \r\n]*')
	pCNAME = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+CNAME[\t ]+([\.0-9a-zA-Z\-]{1,256})[\t \r\n]*')
	pPTR = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+PTR[\t ]+([\.0-9a-zA-Z\-]{1,256})[\t \r\n]*')
	pMX = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+MX[\t ]+([0-9]{1,8})[\t ]+([\.0-9a-zA-Z\-]{1,256})[\t \r\n]*')
	pTXT = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+TXT[\t ]+([\.0-9a-zA-Z\-\'\" \t\/\?=:\~]{1,256})[\t \r\n]*')
	pAAAA = re.compile('^([\.0-9a-zA-Z\-]{1,256})[\t ]+([0-9]{1,8})[\t ]+IN[\t ]+AAAA[\t ]+([0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4})[\t \r\n]*')
        pTimeout = re.compile('^;; connection timed out; no servers could be reached')
        
        for line in ret_list:
	    mA = pA.search(line)
	    if mA:
		result["rr_a"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2]) )
		result["hasresult"] = True
		continue
			
	    mA = pCNAME.search(line)
	    if mA:
		result["rr_cname"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2]) )
		result["hasresult"] = True
		continue
				
	    mA = pNS.search(line)
	    if mA:
		result["rr_ns"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2]) )
		result["hasresult"] = True
		continue
			
	    mA = pMX.search(line)
	    if mA:
		result["rr_mx"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2], mA.groups()[3]) )
		result["hasresult"] = True
		continue

	    mA = pTXT.search(line)
	    if mA:
		result["rr_txt"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2]) )
		result["hasresult"] = True
		continue

	    mA = pPTR.search(line)
	    if mA:
		result["rr_ptr"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2]) )
		result["hasresult"] = True
		continue

	    mA = pAAAA.search(line)
	    if mA:
		result["rr_aaaa"].append( (mA.groups()[0], mA.groups()[1], mA.groups()[2]) )
		result["hasresult"] = True
		continue
				
            mA = pTimeout.search(line)
	    if mA:
                result["istimeout"] = True
				
        return  result
        
    #----------------------------------------------------------------------
    def dig(self, domain, ty='', ldns='', tm=5,retry=0,tries=1):
        self.ldns = ldns
        self.domain = domain
	if ldns == '':
	    self.digCmd = """dig %s %s +noall +answer +time=%s +retry=%s +tries=%s""" % (self.domain, ty, tm, retry, tries)
	else:
	    self.digCmd = """dig @%s %s %s +noall +answer +time=%s +retry=%s +tries=%s""" % (self.ldns, self.domain, ty, tm, retry, tries)
	    
	if ty=='ns' or ty=="NS":
	    self.digCmd += " +authority"
        #print self.digCmd
        
        btime = time.time()
        #print self.digCmd
        fp = os.popen( self.digCmd )
        ret_list = fp.readlines()
        #print ret_list
        fp.close
        etime = time.time()
        rsptime = int( (etime-btime) * 1000)   
        
        return self.spliteDigret(ret_list, rsptime)   
	 
if __name__=='__main__':
    a = CommonDig()
    results = a.dig("www.qq.com", '', "221.130.13.133")
    print results

# -*- coding:utf8 -*-

# log
def LOG_ADD_USER(name):
    return '添加用户%s' % name

def LOG_DEL_USER(name):
    return '删除用户%s' % name

def LOG_UPDATE_ZONE_HEAD(old_name, old_ttl, old_email, name, ttl, email):
    return '修改域名%s %s %s 为 %s %s %s' % (old_name, old_ttl, old_email, name, ttl, email)

def LOG_DEL_ZONE_HEAD(name):
    return '删除域名%s' % name

def LOG_CREATE_ZONE_HEAD(name):
    return '添加域名%s' % name

def LOG_ADD_ZONE_RECORD(full_name, ttl, type, full_value):
    return "添加记录%s %s %s %s" % (full_name, ttl, type, full_value)

# info
def INFO_ADD_USER_S(name):
    return '用户[%s]添加成功！' % name

def INFO_ADD_USER_F(name):
    return '用户[%s]已经存在，不能重复添加！' % name

def INFO_DEL_USER_S(name):
    return '删除[%s]用户成功！' % name

def INFO_UPDATE_ZONE_HEAD_S(name):
    return '域名[%s]更新成功！' % name

def INFO_ZONE_HEAD_EXIST(name):
    return '域名[%s]在该解析组已经存在，不能创建！' % name

INFO_CREATE_ZONE_HEAD_S = '域名创建成功!'
INFO_UPDATE_ZONE_HEAD_F = '域名更新失败!'
INFO_DEL_ZONE_HEAD_S = '删除成功!'
INFO_OLD_PWD_ERROR = '旧密码错误!'
INFO_DOMAIN_VALUE_NOT_SAME = '域名和记录值不能相同！'
INFO_ZONE_RECORD_EXIST = '相同的记录已经存在，不能重复创建！'


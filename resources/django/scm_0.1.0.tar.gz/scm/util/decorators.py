# -*- encoding=utf8 -*-

from django.contrib.auth import REDIRECT_FIELD_NAME
from django.utils.http import urlquote
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponseRedirect
from scm.user.models import User_Power
from scm.util.lukWeb import getUser

def app_required(app, redirect_url='/site_media/html/auth_error.html'):
    """
    Decorator for views that checks whether a user has a app permission
    enabled, redirecting to the redirect page if necessary.
    """
    return user_passes_test(lambda u: u.has_module_perms(app), login_url=redirect_url)

def authority_required(power, redirect_url='/site_media/html/auth_error.html', login_url='/accounts/login/'):
    """
    Decorator for views that checks whether a user has a service permission
    enabled, redirecting to the redirect page if necessary.
    """
    def wrapper(f):
        def decorate(*arg):
            request = arg[0]
            user = getUser(request)
            if not user.is_authenticated():
                path = urlquote(request.get_full_path())
                tup = login_url, REDIRECT_FIELD_NAME, path
                return HttpResponseRedirect('%s?%s=%s' % tup)
            if _has_service(user, power):
                return f(arg[0])
            else:
                return HttpResponseRedirect(redirect_url)
        return decorate
    return wrapper

def _has_service(user, power):
    try:
        if not user.is_active:
            return False
        if user.is_superuser:
            return True
        try:
            obj = User_Power.objects.get(user=user)
            if obj.power >= power:
                return True
            else:
                return False
        except:
            return False

    except:
        return False

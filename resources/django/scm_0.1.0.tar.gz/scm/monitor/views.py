# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.template import RequestContext
from scm.common.models import group,device,application
from scm.monitor.models import base_state,dns_state,base_state_history,dns_state_history
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage, addUserDev
from scm.util.decorators import authority_required

def indexRedirct(request):
    return HttpResponseRedirect('/monitor/base/')

def index(request):
    return baseState(request)

@authority_required(1)
def baseState(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rip = request.REQUEST.get('rip', '')
    rhost = request.REQUEST.get('rhost', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    group_list = group.objects.all()
    app_list = application.objects.all()  
    group_map = {}
    for item in group_list:
        group_map[item.id] = item.name 
    app_map = {}
    for item in app_list:
        app_map[item.id] = item.cn_name 
        
    state_tmp = base_state.getState(rhost,rgroup,rapp)
    state_list = []
    for item in state_tmp:
        data = {}
        data['group'] =  group_map[item[0]]
        data['app'] =  app_map[item[1]]
        data['hostname'] =  item[2]
        data['cpu'] =  item[3]
        data['mem_total'] =  item[4]
        data['mem_used'] =  item[5]
        data['load'] =  item[6]
        data['out_put'] =  item[7]
        data['in_put'] =  item[8]
        data['connects'] =  item[9]
        data['tasks'] =  item[10]
        data['df_use'] =  item[11]
        data['run_time'] =  item[12]
        data['add_time'] =  item[13][11:]
        data['sn'] =  item[14]
        
        state_list.append(data)
      
        
    if hits:
        pagination = split_page(hits, '/monitor/base/?rapp=%s&rip=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rip, rhost, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(len(state_list), '/monitor/base/?rapp=%s&rip=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rip, rhost, rgroup), \
                                results_per_page, page)
        
    return render_to_response('monitor/base_state.html', {'rapp':rapp, 'rip':rip,'rhost':rhost,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'app_list':app_list,'state_list':state_list[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))

@authority_required(1)
def dnsState(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rip = request.REQUEST.get('rip', '')
    rhost = request.REQUEST.get('rhost', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    group_list = group.objects.all()
    app_list = application.objects.all()  
    group_map = {}
    for item in group_list:
        group_map[item.id] = item.name 
    app_map = {}
    for item in app_list:
        app_map[item.id] = item.cn_name 
        
    state_tmp = dns_state.getState(rhost,rgroup)
    state_list = []
    for item in state_tmp:
        data = {}
        data['group'] =  group_map[item[0]]
        data['app'] =  app_map[item[1]]
        data['hostname'] =  item[2]
        data['run_state'] =  item[3]
        data['server_state'] =  item[4]
        data['total_query'] =  item[5]
        data['ip_max_query'] =  item[6]
        data['domain_max_query'] =  item[7]
        data['hit_query'] =  item[8]
        data['recursion_query'] =  item[9]
        data['recursion_time'] =  item[10]
        data['poison_count'] =  item[11]
        data['add_time'] =  item[12][11:]
        data['sn'] =  item[13]
        
        state_list.append(data)
      
        
    if hits:
        pagination = split_page(hits, '/monitor/dns/?rapp=%s&rip=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rip, rhost, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(len(state_list), '/monitor/dns/?rapp=%s&rip=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rip, rhost, rgroup), \
                                results_per_page, page)
        
    return render_to_response('monitor/dns_state.html', {'rapp':rapp, 'rip':rip,'rhost':rhost,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'app_list':app_list,'state_list':state_list[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))




@authority_required(1)
def baseStateHistory(request):
    device_sn = request.REQUEST.get('device_sn', '')
    device_name = request.REQUEST.get('device_name', '')
    
    state_list = []
    if len(device_sn) > 0:
        state_tmp = base_state_history.getHistory(device_sn)
        for item in state_tmp:
            data = {}
            data['cpu'] =  item[0]
            data['mem_total'] =  item[1]
            data['mem_used'] =  item[2]
            data['load'] =  item[3]
            data['out_put'] =  item[4]
            data['in_put'] =  item[5]
            data['connects'] =  item[6]
            data['tasks'] =  item[7]
            data['df_use'] =  item[8]
            data['run_time'] =  item[9]
            data['add_time'] =  str(item[10])[11:]
            
            state_list.append(data)
        
    return render_to_response('monitor/base_state_history.html', {'state_list':state_list,'device_sn':device_sn,'device_name':device_name}, context_instance = RequestContext(request))

@authority_required(1)
def dnsStateHistory(request):
    device_sn = request.REQUEST.get('device_sn', '')
    device_name = request.REQUEST.get('device_name', '')
    
    state_list = []
    if len(device_sn) > 0:
        state_tmp = dns_state_history.getHistory(device_sn)
        for item in state_tmp:
            data = {}
            data['run_state'] =  str(item[0])
            data['server_state'] =  str(item[1])
            data['total_query'] =  item[2]
            data['ip_max_query'] =  item[3]
            data['domain_max_query'] =  item[4]
            data['hit_query'] =  item[5]
            data['recursion_query'] =  item[6]
            data['recursion_time'] =  item[7]
            data['poison_count'] =  item[8]
            data['add_time'] =  str(item[9])[11:]
            
            state_list.append(data)
        
    return render_to_response('monitor/dns_state_history.html', {'state_list':state_list,'device_sn':device_sn,'device_name':device_name}, context_instance = RequestContext(request))

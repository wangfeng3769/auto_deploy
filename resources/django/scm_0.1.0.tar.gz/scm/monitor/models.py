# -*- encoding=utf-8 -*-

from django.db import models
from django.db import connection
from scm.common.models import *
import time

class base_state(models.Model):
    device_sn = models.CharField(max_length=16, unique=True)
    cpu = models.IntegerField()
    mem_total = models.IntegerField()
    mem_used = models.IntegerField()
    load = models.FloatField()
    out_put = models.IntegerField()
    in_put = models.IntegerField()
    connects = models.IntegerField()
    tasks = models.IntegerField()
    df_use = models.IntegerField(default=95)
    run_time = models.CharField(max_length=32)
    modify_time = models.DateTimeField(auto_now=True)

    @staticmethod
    def getState(dvc='',gp_id='', app_id=''):
        condition ="WHERE 1=1 "
        
        if len(app_id) > 0:
            condition += 'AND d.app_id=%d ' % int(app_id)
        if len(gp_id) > 0:
            condition += 'AND d.group_id=%d ' % int(gp_id)
        #if len(dvc) > 0:
        #    condition += "AND d.hostname like '%s%s%s' " % ('\%', dvc, '\%')

        cursor = connection.cursor()
        sql = """
            SELECT d.group_id,d.app_id,d.hostname,IFNULL(m.cpu, '-'),IFNULL(m.mem_total, '-'),
            IFNULL(m.mem_used, '-'),IFNULL(m.load, '-'),IFNULL(m.out_put, '-'),
            IFNULL(m.in_put, '-'),IFNULL(m.connects, '-'),IFNULL(m.tasks, '-'),IFNULL(m.df_use, '-'),IFNULL(m.run_time, '-'),IFNULL(m.modify_time, '-'),d.sn
            FROM common_device AS d
            LEFT JOIN monitor_base_state AS m
            ON d.sn=m.device_sn 
             """ + condition
        cursor.execute( sql )
        return cursor.fetchall()

class dns_state(models.Model):
    device_sn = models.CharField(max_length=16, unique=True)
    run_state = models.IntegerField(default=0)
    server_state = models.IntegerField(default=0)
    total_query = models.IntegerField(verbose_name=u'总解析数')
    ip_max_query = models.IntegerField(verbose_name=u'IP最大解析数')
    domain_max_query = models.IntegerField(verbose_name=u'域名最大解析数')
    hit_query = models.IntegerField(verbose_name=u'命中查询')
    recursion_query = models.IntegerField(verbose_name=u'递归次数')
    recursion_time = models.IntegerField(verbose_name=u'递归延时')
    poison_count = models.IntegerField(verbose_name=u'投毒数')
    modify_time = models.DateTimeField(auto_now=True)
  
    @staticmethod
    def getState(dvc='',gp_id=''):
        condition ="WHERE d.app_id='200301020003' "
        
        if len(gp_id) > 0:
            condition += 'AND d.group_id=%d ' % int(gp_id)
        #if len(dvc) > 0:
        #    condition += "AND d.hostname like '%s%s%s' " % ('\%', dvc, '\%')
        
        cursor = connection.cursor()
        cursor.execute("""
            SELECT d.group_id,d.app_id,d.hostname,IFNULL(m.run_state, '-'),IFNULL(m.server_state, '-'),IFNULL(m.total_query, '-'),IFNULL(m.ip_max_query, '-'),
            IFNULL(m.domain_max_query, '-'),IFNULL(m.hit_query, '-'),IFNULL(m.recursion_query, '-'),
            IFNULL(m.recursion_time, '-'),IFNULL(m.poison_count, '-'),IFNULL(m.modify_time, '-'),d.sn
            FROM common_device AS d
            LEFT JOIN monitor_dns_state AS m
            ON d.sn=m.device_sn 
             """ + condition )
        
        return cursor.fetchall()

class dlc_state(models.Model):
    device_sn = models.CharField(max_length=16, unique=True)
    
    modify_time = models.DateTimeField(auto_now=True)
    

class base_state_history(models.Model):
    device_sn = models.CharField(max_length=16)
    cpu = models.IntegerField()
    mem_total = models.IntegerField()
    mem_used = models.IntegerField()
    load = models.FloatField()
    out_put = models.IntegerField()
    in_put = models.IntegerField()
    connects = models.IntegerField()
    tasks = models.IntegerField()
    df_use = models.IntegerField(default=95)
    run_time = models.CharField(max_length=32)
    add_time = models.DateTimeField(auto_now=True)
    
    @staticmethod
    def getHistory(rsn):
        cursor = connection.cursor()
        sql = """
            SELECT cpu,mem_total,mem_used,`load`,out_put,in_put,connects,tasks,df_use,run_time,add_time
            FROM monitor_base_state_history
            WHERE device_sn='%s'
            ORDER BY add_time DESC
            LIMIT 50
             """ % rsn
        cursor.execute( sql )
        
        return cursor.fetchall()
    
    @staticmethod
    def clearHistory():
        oldtime = time.strftime('%Y-%m-%d %X',time.localtime(time.time()-2*60*60))
        cursor = connection.cursor()
        sql = """
            delete from monitor_base_state_history
            WHERE add_time<'%s'
             """ % oldtime
        cursor.execute( sql )
        
        return cursor.fetchall()
    
class dns_state_history(models.Model):
    device_sn = models.CharField(max_length=16)
    run_state = models.IntegerField(default=0)
    server_state = models.IntegerField(default=0)
    total_query = models.IntegerField(verbose_name=u'总解析数')
    ip_max_query = models.IntegerField(verbose_name=u'IP最大解析数')
    domain_max_query = models.IntegerField(verbose_name=u'域名最大解析数')
    hit_query = models.IntegerField(verbose_name=u'命中查询')
    recursion_query = models.IntegerField(verbose_name=u'递归次数')
    recursion_time = models.IntegerField(verbose_name=u'递归延时')
    poison_count = models.IntegerField(verbose_name=u'投毒数')
    add_time = models.DateTimeField(auto_now=True)
    
    @staticmethod
    def getHistory(rsn):
        oldtime = time.strftime('%Y-%m-%d %X',time.localtime(time.time()-4*60*60))
        cursor = connection.cursor()
        sql = """
            #SELECT run_state,server_state,total_query,ip_max_query,domain_max_query,hit_query,recursion_query,recursion_time,poison_count,add_time
            #FROM monitor_dns_state_history
            #WHERE device_sn='%s'
            #ORDER BY add_time DESC
            #LIMIT 50
             #""" % rsn
        cursor.execute( sql )
        
        return cursor.fetchall()
    
    @staticmethod
    def clearHistory():
        oldtime = time.strftime('%Y-%m-%d %X',time.localtime(time.time()-4*60*60))
        cursor = connection.cursor()
        sql = """
            delete from monitor_dns_state_history
            WHERE add_time<'%s'
             """ % oldtime
        cursor.execute( sql )
        
        return cursor.fetchall()

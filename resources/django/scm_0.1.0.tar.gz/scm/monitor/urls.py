from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:

urlpatterns = patterns('',
     (r'^$','scm.monitor.views.index'),
     (r'^index/$','scm.monitor.views.index'),
     
     
     (r'^base/?','scm.monitor.views.baseState'),
     (r'^dns/?','scm.monitor.views.dnsState'),
     (r'^historybase/?','scm.monitor.views.baseStateHistory'),
     (r'^historydns/?','scm.monitor.views.dnsStateHistory'),
)



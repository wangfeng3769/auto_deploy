# -*- encoding=utf-8 -*-

# author wang.yuan #

from time import sleep
from django.core.management import execute_manager
try:
    import scm.settings # Assumed to be in the same directory.
except ImportError:
    import sys
    sys.stderr.write("Error: Can't find the file 'settings.py' in the directory containing %r. It appears you've customized things.\nYou'll have to run django-admin.py, passing it your settings module.\n(If the file settings.py does indeed exist, it's causing an ImportError somehow.)\n" % __file__)
    sys.exit(1)
execute_manager(scm.settings)
from scm.monitor.models import dns_state
from scm.util.sendmail import CCSendMail
from scm.settings import MAIL_ADDRESS

def alarm():
    state_tmp = dns_state.getState()
    state_list = []
    for item in state_tmp:
        runState = 0
        serverState = 0
        try:
            runState = int(item[3])
            serverState = int(item[4])
        except:
            pass
        if runState or serverState:
            data = {}
            data['sn'] = item[13]
            data['run_state'] = '正常'
            data['server_state'] = '正常'
            if runState:
                data['run_state'] = '异常'
            if serverState:
                data['server_state'] = '异常'
            state_list.append(data)
    if len(state_list):
        content = ''
        for state in state_list:
            content += '设备号：%s<br>运行状态：%s<br>服务状态：%s<br>' % (state.get('sn'), state.get('run_state'), state.get('server_state'))
        send=CCSendMail('corp.chinacache.com','SSR-TEAM@chinacache.com','')
        for addr in MAIL_ADDRESS:
            send.addTo(addr)
        send.setSubject(u'FDNS告警')
        send.setContent(content)
        send.send()
        send.close()

alarm()
    

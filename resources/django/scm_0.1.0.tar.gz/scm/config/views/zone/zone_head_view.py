# -*- coding:utf8 -*-

import time
import re
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.db.models import Q
from scm.common.models import group
from scm.user.models import User_Power
from scm.user.models import UserZone
from scm.config.models import zone_head
from scm.config.models import zone_record
from scm.config.helpers.zone.head_helper import endwith_dot
from scm.util.lukWeb import getUser
from scm.util.lukWeb import writeLog
from scm.util.decorators import authority_required
from scm.util.paginator_wrapper import paginate
from scm.util.json_wrapper import render_to_json
from scm.util import message

@authority_required(10)
def index(request):
    ret_info = request.REQUEST.get('ret_info', '')
    record = request.REQUEST.get('record', '')
    rgroup = request.REQUEST.get('rgroup', '')
    rzone = request.REQUEST.get('rzone', '')
    page = int(request.REQUEST.get('page', 1))
    user = getUser(request)

    group_lst = group.objects.all()

    zone_head_list = _query(user, record, rgroup, rzone)
    content, pagination = paginate(zone_head_list, page)

    return render_to_response(
            'config/zone/zone_head/index.html',
            {
                'group_list':group_lst,
                'rzone':rzone,
                'record':record,
                'rgroup':rgroup,
                'ret_info':ret_info,
                'zone_list':content,
                'pagination':pagination,
                'condition':'rzone=%srecord=%s&rgroup=%s' % (rzone, record, rgroup)
            },
            context_instance = RequestContext(request)
        )

def _query(user, record=None, rgroup=None, rzone=None):
    power = User_Power.objects.get(user=user).power

    condition = Q()

    if power != 1000:
        zone_head_ids = list(UserZone.objects.filter(user=user).values_list('zone_id', flat=True))
        condition &= Q(id__in=zone_head_ids)

    if record:
        zone_head_ids = list(zone_record.objects.filter(value__contains=record).values_list('zone_head_id', flat=True))
        condition &= Q(id__in=zone_head_ids)

    if rgroup:
        condition &= Q(group__id=rgroup)

    if rzone:
        condition &= Q(zone_name__contains=rzone)

    zone_head_lst = zone_head.objects.filter(condition)

    return zone_head_lst

@authority_required(10)
def show(request):
    ret_info = request.REQUEST.get('ret_info', '')
    zone_id = request.REQUEST.get('zone_id', '')
    zone_head_data = zone_head.objects.get(id=zone_id)

    return render_to_response(
            'config/zone/zone_head/show.html',
            {
                'zone_data':zone_head_data,
                'ret_info':ret_info
            },
            context_instance = RequestContext(request)
        )

@authority_required(1000)
def new(request):
    ret_info = request.REQUEST.get('ret_info', '')

    group_list = group.objects.all()

    return render_to_response(
            'config/zone/zone_head/new.html',
            {
                'group_list':group_list,
                'ret_info':ret_info
            },
            context_instance = RequestContext(request)
        )

@authority_required(1000)
def create(request):
    zone_name = request.REQUEST.get('zone_name', '')
    rgroup = int(request.REQUEST.get('rgroup', ''))
    ttl = request.REQUEST.get('ttl', '')
    master_email = request.REQUEST.get('master_email', '')

    zone_name = '%s.' % endwith_dot(zone_name)

    count = zone_head.objects.filter(zone_name=zone_name, group__id=rgroup).count()
    if count > 0:
        info = message.INFO_ZONE_HEAD_EXIST(zone_name)
        return HttpResponseRedirect('/zone/new?ret_info=%s' % info)

    zone_head_data = zone_head()
    zone_head_data.zone_name=zone_name
    zone_head_data.ttl=ttl
    zone_head_data.master_email=master_email

    # FIXME
    zone_head_data.sn = str(time.time())[0:10]

    zone_head_data.group_id=rgroup
    zone_head_data.save()

    writeLog(getUser(request).id, 'zone', message.LOG_CREATE_ZONE_HEAD(zone_name))
    info = message.INFO_CREATE_ZONE_HEAD_S

    return HttpResponseRedirect('/zone?ret_info=%s' % info)

@authority_required(10)
def update(request):
    zone_id = request.REQUEST.get('zone_id', '')
    zone_name = request.REQUEST.get('zone_name', '')
    ttl = request.REQUEST.get('ttl', '')
    master_email = request.REQUEST.get('master_email', '')

    try:
        zone_head_ins = zone_head.objects.get(id=zone_id)
        zone_name = '%s.' % endwith_dot(zone_name)

        group_id = zone_head_ins.group.id
        count = zone_head.objects.filter(group__id=group_id, zone_name=zone_name).count()
        if count > 0:
            info = '该域名%s已存在，不能修改!' % zone_name
            return HttpResponseRedirect('/zone/show?zone_id=%s&ret_info=%s' % (zone_id, info))


        old_name = zone_head_ins.zone_name
        old_ttl = zone_head_ins.ttl
        old_email = zone_head_ins.master_email

        zone_head_ins.zone_name = zone_name
        zone_head_ins.ttl = ttl
        zone_head_ins.master_email = master_email
        zone_head_ins.save()

        #kkk
        record_list = zone_record.objects.filter(zone_head__id=zone_id)
        regex = re.compile(r'%s$' % old_name)
        for record in record_list:
            record.record_name = regex.sub('%s' % zone_name, record.record_name, 1)
            record.save()

    except:
        info = message.INFO_UPDATE_ZONE_HEAD_F
        return HttpResponseRedirect('/zone/show?zone_id=%s&ret_info=%s' % (zone_id, info))

    writeLog(getUser(request).id, 'zone', message.LOG_UPDATE_ZONE_HEAD(old_name, old_ttl, old_email, zone_name, ttl, master_email))
    info = message.INFO_UPDATE_ZONE_HEAD_S(zone_name)

    return HttpResponseRedirect('/zone/show?zone_id=%s&ret_info=%s' % (zone_id, info))

@authority_required(10)
def delete(request):
    zone_id = request.REQUEST.get('zone_id', '-1')
    zone_name = request.REQUEST.get('zone_name', '')

    try:
        zone_head_data = zone_head.objects.get(id=zone_id).delete()
    except:
        pass

    writeLog(getUser(request).id, 'zone', message.LOG_DEL_ZONE_HEAD(zone_name))
    info = message.INFO_DEL_ZONE_HEAD_S

    return HttpResponseRedirect('/zone?ret_info=%s' % info)

@authority_required(10)
def toggle(request):
    zone_id = request.REQUEST.get('zone_id', '')
    status = request.REQUEST.get('status', '')

    try:
        zone_head_data = zone_head.objects.get(id=zone_id)
        zone_name = zone_head_data.zone_name
        zone_head_data.status = status
        zone_head_data.save()
    except:
        pass

    if status == 1:
        writeLog(getUser(request).id, 'zone', "启用域名%s" % zone_name)
        info = u"启用成功！"
    else:
        writeLog(getUser(request).id, 'zone', "禁用域名%s" % zone_name)
        info = u"禁用成功！"

    return HttpResponseRedirect('/zone?ret_info=%s' % info)


# -*- coding:utf8 -*-

import re
import os
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.lukWeb import writeLog
from scm.util.lukWeb import getUser
from scm.config.models import zone_head
from scm.config.models import zone_data
from scm.config.models import zone_record
from scm.util.decorators import authority_required
from scm.config.helpers.zone.file_helper import is_valid_file_type
from scm.config.helpers.zone.file_helper import is_valid_file_content
from scm.config.helpers.zone.file_helper import import_zone_file
from scm.settings import EXPORT_DIR
from scm.settings import ROOT_DIR

@authority_required(10)
def new(request):
    ret_info = request.REQUEST.get('ret_info', '')
    return render_to_response('config/zone/zone_file/new.html',{'ret_info':ret_info},context_instance= RequestContext(request))

@authority_required(10)
def create(request):
    file_obj = request.FILES.get("file",None)
    try:
        content = file_obj.readlines()
    except:
        info = '没有选择上传文件！'
        return HttpResponseRedirect('/zone/zone_file/new?ret_info=%s' % info)

    zone_info = is_valid_file_content(content)
    if not is_valid_file_type(file_obj.name) or not zone_info:
        info = '导入失败!'
        return HttpResponseRedirect('/zone/zone_file/new?ret_info=%s' % info)

    import_zone_file(zone_info)
    info = '导入成功!'
    return HttpResponseRedirect('/zone?ret_info=%s' % info)

@authority_required(10)
def export(request):
    ids = request.GET.get("zone_ids",None).split("|")

    zone_data_list = zone_data.objects.filter(zone_head_id__in = ids)

    scm_zone_path = '%s/scm_zone' % EXPORT_DIR
    zone_file_path = '%s/zone_file' % scm_zone_path
    scm_zone_zip = '%s/scm_zone.zip' % EXPORT_DIR

    os.popen('rm -rf %s' % scm_zone_path)
    os.popen('mkdir %s' % scm_zone_path)
    os.popen('rm -f %s' % scm_zone_zip)
    os.popen('mkdir %s' % zone_file_path)

    for zone_data_ins in zone_data_list:
        if not zone_data_ins.is_delete :
             zone_name= zone_data_ins.zone_name
             file_data = zone_data_ins.zone_data

             bind_head = 'zone "%s" {\n  type master;\n  file "/etc/bind/zone_file/%s";\n};\n\n' % (zone_name, zone_name)
             f = open('%s/scm_zone' % scm_zone_path, 'a')
             f.write(bind_head)
             f.close()

             f = open('%s/%s' % (zone_file_path, zone_name), 'w')
             f.write(file_data[file_data.find('{')+2:file_data.find('}')])
             f.close()

    os.chdir(EXPORT_DIR)
    os.popen('zip -rm scm_zone.zip scm_zone/')

    f = open(scm_zone_zip)
    data = f.read()
    f.close()

    response = HttpResponse(data, mimetype = 'application/octet-stream')
    response['Content-Disposition'] = 'attachment; filename=%s' % 'scm_zone.zip'

    return response


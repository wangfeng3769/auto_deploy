# -*- coding:utf8 -*-

from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.db.models import Q
from django.db import IntegrityError
from scm.common.models import group
from scm.user.models import User_Power
from scm.user.models import UserZone
from scm.config.models import zone_head
from scm.config.models import zone_record
from scm.config.helpers.zone import record_helper
from scm.util.lukWeb import getUser
from scm.util.lukWeb import writeLog
from scm.util.decorators import authority_required
from scm.util.paginator_wrapper import paginate
from scm.util.json_wrapper import render_to_json
from scm.util import message

RECORD_TYPE = {
    'A':0,
    'NS':1,
    'CNAME':2,
    'MX':3,
    'AAAA':4,
    'PTR':5,
    'TXT':6
}

@authority_required(10)
def index(request):
    zone_id = request.REQUEST.get('zone_id', '-1')
    zone_name = request.REQUEST.get('zone_name', '')

    rdomain = request.REQUEST.get('rdomain', '')
    rtype = request.REQUEST.get('rtype', 'ALL')
    rvalue = request.REQUEST.get('rvalue', '')
    page = int(request.REQUEST.get('page', 1))

    record_list = _query(zone_id, rdomain, rtype, rvalue)

    content, pagination = paginate(record_list, page)

    return render_to_response(
            'config/zone/zone_record/index.html',
            {
                'zone_name':zone_name,
                'zone_id':zone_id,
                'rdomain':rdomain,
                'rtype':rtype,
                'rvalue':rvalue,
                'record_list':content,
                'pagination':pagination
            },
            context_instance = RequestContext(request)
        )

def _query(zone_id, rdomain, rtype, rvalue):
    condition = Q()
    condition &= Q(zone_head__id=zone_id)

    if rdomain:
        condition &= Q(record_name__contains=rdomain)
    if rtype != 'ALL':
        condition &= Q(record_type=RECORD_TYPE[rtype])
    if rvalue:
        condition &= Q(value__contains=rvalue)

    record_list = zone_record.objects.filter(condition).order_by('record_name').order_by('can_modify')

    return record_list

@authority_required(10)
@render_to_json()
def create(request):
    return _create_or_update(request)

@authority_required(10)
@render_to_json()
def update(request):
    return _create_or_update(request, task='update')

def _create_or_update(request, task='create'):
    status = request.REQUEST.get('status', '')
    record_id = request.REQUEST.get('record_id', '')
    zone_name = request.REQUEST.get('zone_name', '')
    zone_id = request.REQUEST.get('zone_id', '')
    domain = request.REQUEST.get('domain', '')
    type = request.REQUEST.get('type', '')
    value = request.REQUEST.get('value', '')
    mx = request.REQUEST.get('mx', 10)
    ttl = request.REQUEST.get('ttl', '')

    full_name, full_value = record_helper.get_full_record(domain, value, type, zone_name)

    if type in ('NS', 'CNAME', 'MX', 'PTR') and full_name == full_value:
        return ['fail', message.INFO_DOMAIN_VALUE_NOT_SAME]

    result = record_helper.is_invalid(zone_id, type, full_name, full_value, record_id)
    if result:
        return ['fail', result]

    if task == 'create':
        try:
            zone_head_ins = zone_head.objects.get(id=zone_id)
            if value[-1] == '.': full_value = value
            zone_record.objects.create(
                    zone_head = zone_head_ins,
                    record_name = full_name,
                    record_type = RECORD_TYPE[type],
                    mx_preced = mx,
                    value = full_value,
                    ttl = ttl
            )

            #writeLog(getUser(request).id, 'zone', message.LOG_ADD_ZONE_RECORD(full_name, ttl, type, full_value))
            return ['success', '创建成功！']
        except IntegrityError, e:
            return ['fail', '该记录已经存在！']
    else:
        try:
            zone_record_ins = zone_record.objects.get(id=record_id)
            if zone_record_ins.record_name != domain:
                zone_name_len = len(zone_name)

                if domain[-zone_name_len:] == zone_name:
                    zone_record_ins.record_name = domain
                else:
                    zone_record_ins.record_name = full_name

            if zone_record_ins.value != value:
                zone_name_len = len(zone_name)

                if value[-zone_name_len:] == zone_name:
                    zone_record_ins.value = value
                else:
                    if value[-1] == '.': full_value = value
                    zone_record_ins.value = full_value

            zone_record_ins.record_type = RECORD_TYPE[type]
            zone_record_ins.ttl = ttl
            zone_record_ins.save()
        except:
            return ['fail', '更新失败！']

        #writeLog(getUser(request).id, 'zone', message.LOG_ADD_ZONE_RECORD(full_name, ttl, type, full_value))
        return ['success', '更新成功！']

@authority_required(10)
@render_to_json()
def delete(request):

    record_id = request.REQUEST.get('record_id', '')
    zone_record.objects.get(id=record_id).delete()
    #writeLog(getUser(request).id, 'zone', "删除记录%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8')) )

    return ['success', '删除成功!']

@authority_required(10)
@render_to_json()
def toggle(request):
    record_id = request.REQUEST.get('record_id', '')
    status = request.REQUEST.get('status', '')

    try:
        zone_record_data = zone_record.objects.get(id=record_id)
        old_status = zone_record_data.status
        zone_record_data.status = status
        zone_record_data.save()

        #writeLog(getUser(request).id, 'zone', "启用记录%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8')) )

        #writeLog(getUser(request).id, 'zone', "禁用记录%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8')) )
    except:
        pass

    return ['success']


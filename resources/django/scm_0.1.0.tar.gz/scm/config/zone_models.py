# -*- coding:utf8 -*-

from django.db import models
from django.db import connection
from scm.common.models import group
from django.contrib.auth.models import User

RECORD_TYPE = (
        (0,'A'),
        (1,'NS'),
        (2,'CNAME'),
        (3,'MX'),
        (4,'AAAA'),
        (5,'PTR'),
        (6,'TXT'),
)

STATUS = (
        (0,'disable'),
        (1,'ensable'),
        (2,'delete'),
)

class zone_head(models.Model):
    STATUS = (
            (0,'disable'),
            (1,'ensable'),
            (2,'delete'),
    )

    group = models.ForeignKey(group)
    zone_name = models.CharField(max_length=128)
    ttl = models.CharField(max_length=16, default='120')
    master_host = models.CharField(max_length=32, default='ns1.xgslb.net.')
    master_email = models.CharField(max_length=32, default='root.xgslb.net.')
    sn = models.CharField(max_length=32)
    ttl_refresh = models.CharField(max_length=8, default='10800')
    ttl_retry = models.CharField(max_length=8, default='900')
    ttl_expire = models.CharField(max_length=8, default='604800')
    mix_ttl = models.CharField(max_length=8, default='120')
    record_count = models.IntegerField(default=0)
    enable_record_count = models.IntegerField(default=0)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = (('group', 'zone_name'),)

class zone_record(models.Model):
    RECORD_TYPE = (
        (0,'A'),
        (1,'NS'),
        (2,'CNAME'),
        (3,'MX'),
        (4,'AAAA'),
        (5,'PTR'),
        (6,'TXT'),
    )

    STATUS = (
            (0,'disable'),
            (1,'ensable'),
            (2,'delete'),
    )

    zone_head = models.ForeignKey(zone_head)
    record_name = models.CharField(max_length=128)
    record_type = models.IntegerField(max_length=1, choices=RECORD_TYPE)
    mx_preced = models.IntegerField(default=10)
    ttl = models.CharField(max_length=16, default='3600')
    value = models.CharField(max_length=128)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    can_modify = models.IntegerField(max_length=1, default=1)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = (('record_name', 'record_type', 'value'),)

class zone_template(models.Model):
    RECORD_TYPE = (
        (0,'A'),
        (1,'NS'),
        (2,'CNAME'),
        (3,'MX'),
        (4,'AAAA'),
        (5,'PTR'),
        (6,'TXT'),
    )

    STATUS = (
            (0,'disable'),
            (1,'ensable'),
            (2,'delete'),
    )

    record_name = models.CharField(max_length=128)
    record_type = models.IntegerField(max_length=1, choices=RECORD_TYPE)
    mx_preced = models.IntegerField(default=10)
    ttl = models.CharField(max_length=16, default='3600')
    value = models.CharField(max_length=128)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)

class zone_version(models.Model):
    version = models.AutoField(primary_key=True)
    group_id = models.IntegerField()
    zone_head_id = models.IntegerField()
    add_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        get_latest_by = 'version'

class zone_data(models.Model):
    zone_head_id = models.IntegerField(primary_key=True)
    group_id = models.IntegerField()
    zone_name = models.CharField(max_length=64)
    is_delete = models.BooleanField(default=False)
    zone_data = models.TextField()
    modify_time = models.DateTimeField(auto_now=True)

    @staticmethod
    def getDataByVersion(version, g_id):
        cursor = connection.cursor()
        cursor.execute("""
            select d.zone_head_id,d.zone_data
            from config_zone_version as v, config_zone_data as d
            where v.version>%s and v.group_id=%d and v.zone_head_id=d.zone_head_id
            group by v.zone_head_id""" % (version, g_id))
        return cursor.fetchall()

    @staticmethod
    def updateDataByNull(zone_id):
        try:
            zone_head_data = zone_head.objects.get(id=zone_id)
            zone_data.objects.get(zone_head_id=zone_id).delete()
            zone_version.objects.create(zone_head_id=zone_id, group_id=zone_head_data.group_id)
        except:
            return False

        return True

    @staticmethod
    def updateDataByZoneHead(zone_id):
        try:
            zone_head_data = zone_head.objects.get(id=zone_id)
        except:
            return False
        data = zone_data()
        data.zone_head_id = zone_id
        data.zone_name = zone_head_data.zone_name
        data.group_id = zone_head_data.group_id
        old_zone_data = zone_data.objects.filter(zone_name=zone_head_data.zone_name, group_id=zone_head_data.group_id)
        old_zone_data.delete()
        if zone_head_data.status!=1:
            data.zone_data = "zone \"%s\" delete\n" % zone_head_data.zone_name
            data.is_delete = True
            data.save()
            return True

        data.zone_data = "zone \"%s\" {\n" % zone_head_data.zone_name[:-1]

        zone_real_soa = "%s\t%s\tIN\tSOA\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (
            zone_head_data.zone_name,
            zone_head_data.ttl,
            zone_head_data.master_host,
            zone_head_data.master_email.replace("@", "."),
            zone_head_data.sn,
            zone_head_data.ttl_refresh,
            zone_head_data.ttl_retry,
            zone_head_data.ttl_expire,
            zone_head_data.mix_ttl,
        )
	
        data.zone_data += zone_real_soa
        zone_record_list = zone_record.objects.filter(zone_head__id=zone_id, status=1)
        zone_real_data=''
        for record in zone_record_list:
            if RECORD_TYPE[record.record_type][1]=='MX':
                zone_real_data = "%s%s\t%s\tIN\t%s\t%s\t%s\n" % (
                    zone_real_data,
                    record.record_name,
                    record.ttl,
                    RECORD_TYPE[record.record_type][1],
                    record.mx_preced,
                    record.value
                )
            else:
                zone_real_data= "%s%s\t%s\tIN\t%s\t%s\n" % (
                    zone_real_data,
                    record.record_name,
                    record.ttl,
                    RECORD_TYPE[record.record_type][1],
                    record.value
                )
	
        data.zone_data = data.zone_data + zone_real_data + "}\n"

        data.is_delete = False
        data.save()

        ver = zone_version.objects.create(zone_head_id=zone_id, group_id=zone_head_data.group_id)

        return True

class zone_file(models.Model):
    user = models.ForeignKey(User)
    name = models.CharField(max_length=128)
    file = models.FileField(upload_to='file/%Y/%m/%d',blank=True,null=True)
    add_time = models.DateTimeField(auto_now_add=True)


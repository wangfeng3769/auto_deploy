from django.conf.urls.defaults import *

urlpatterns = patterns('',
     #(r'^operate/dns/$','scm.config.operate_views.listDns'),
     #(r'^operate/dns/index/?','scm.config.operate_views.listDns'),
     #(r'^operate/dns/clear_single/?','scm.config.operate_views.clearSingle'),
     #(r'^operate/dns/clear_all/?','scm.config.operate_views.clearAll'),
     #(r'^operate/dns/restart_dns/?','scm.config.operate_views.restartDns'),

     #(r'^gslb/index/$','scm.config.gslb_views.listNameid'),
     #(r'^gslb/list_gslb/$','scm.config.gslb_views.listNameid'),
     #(r'^gslb/edit_gslb/?','scm.config.gslb_views.editNameid'),
     #(r'^gslb/del_gslb/?','scm.config.gslb_views.delNameid'),
     #(r'^gslb/disable_gslb/?','scm.config.gslb_views.disableNameid'),
     #(r'^gslb/enable_gslb/?','scm.config.gslb_views.enableNameid'),
     #(r'^gslb/edit_location/?','scm.config.gslb_views.editLocation'),
     #(r'^gslb/disable_location/?','scm.config.gslb_views.disableLocation'),
     #(r'^gslb/enable_location/?','scm.config.gslb_views.enableLocation'),     
     #(r'^gslb/save_location/?','scm.config.gslb_views.saveLocation'),
     #(r'^gslb/add_vip/?','scm.config.gslb_views.addVip'),
     #(r'^gslb/del_vip/?','scm.config.gslb_views.delVip'),
     #(r'^gslb/save_vip/?','scm.config.gslb_views.saveVip'),
     #(r'^gslb/set_status_vip/?','scm.config.gslb_views.setStatusVip'),
     #(r'^gslb/add_gslb_page/?','scm.config.gslb_views.addGslbNameidPage'),
     #(r'^gslb/add_gslb/?','scm.config.gslb_views.addGslbNameid'),
)


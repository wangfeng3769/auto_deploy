from django.db import models
from django.db import connection
from scm.common.models import group
import time

#from scm.scZone.check_zone import checkZone
#from scm.util.sendmail import CCSendMail
# Create your models here.

        
ISOTIMEFORMAT="%Y-%m-%d %H:%M:%S"
def Time2ISOString( s ):
    return time.strftime( ISOTIMEFORMAT, time.localtime( float( s ) ) )

def ISOString2Time( s ):
    return time.strptime( s, ISOTIMEFORMAT )

def str2steamp( s ):
    return time.mktime(time.strptime(s, "%Y-%m-%d %H:%M:%S"))

#  ------------nameid begin -------------------

RECORD_TYPE = (
        (0,'A'),
        (1,'CNAME'),
)

PREFERRED_CHOICES = (
        (0,'rr'),
        (1,'ratio'),
        (2,'ga'),
        (3,'path'),
)

STATUS = (
        (0,'disable'),
        (1,'enable'),
        (2,'delete'),
)


CHECK_SUCESS = (
        (False,'fail'),
        (True,'sucess'),
)

CALCULAT_STATUS = (
    (True,'calculat'),
    (False,'no calculat'),
)

GROUP_TYPE = (
        (0,'gslb'),
        (1,'common'),
        (2,'minicdn'),
)

TEMPLATE_TYPE = (
        (0,'gslbcommon'),
        (1,'userdefine'),
)

#----------------------------------------------------------------------
class nameid_template_location(models.Model):
    group = models.ForeignKey(group)
    template_type = models.IntegerField(default=1)
    template_name = models.CharField(max_length=32)
    location_count = models.IntegerField(default=0)
    enable_location_count = models.IntegerField(default=0)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)
    
#----------------------------------------------------------------------
class nameid_template_location_body(models.Model):
    group = models.ForeignKey(group)
    template_location = models.ForeignKey(nameid_template_location)
    location_name = models.CharField(max_length=16)
    location_ipset = models.CharField(max_length=16)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)
    
#------------------------------------------------------------------------------
class nameid_head(models.Model):
    CHECK_SUCESS = (
        (False,'fail'),
        (True,'sucess'),
    )
    
    STATUS = (
        (0,'disable'),
        (1,'enable'),
        (2,'delete'),
    )
    
    CALCULAT_STATUS = (
        (True,'calculat'),
        (False,'no calculat'),
    )
    
    GROUP_TYPE = (
        (0,'gslb'),
        (1,'common'),
        (2,'minicdn'),
    )

    group = models.ForeignKey(group)
    group_type = models.IntegerField(default=0)
    nameid_name = models.CharField(max_length=128)
    dlc_calculat = models.BooleanField(default=True, choices=CALCULAT_STATUS)
    use_probe = models.BooleanField(default=True)
    until = models.CharField(max_length=32)
    location_count = models.IntegerField(default=0)
    enable_location_count = models.IntegerField(default=0)
    vip_count = models.IntegerField(default=0)
    enable_vip_count = models.IntegerField(default=0)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    check_sucess = models.BooleanField(default=False, choices=CHECK_SUCESS)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)

    @staticmethod
    def updateUntil(nameid_head_id=0):
        try:
            nameid_head_data = nameid_head.objects.get(id=nameid_head_id)
            nameid_head_data.until = str(time.time())[:10]
            nameid_head_data.save()
            return True
        except:
            return False
    
#----------------------------------------------------------------------
class nameid_location(models.Model):
    RECORD_TYPE = (
        (0,'A'),
        (1,'CNAME'),
    )
    
    PREFERRED_CHOICES = (
            (0,'rr'),
            (1,'ratio'),
            (2,'ga'),
            (3,'path'),
    )
    
    STATUS = (
            (0,'disable'),
            (1,'enable'),
            (2,'delete'),
    )
    
    nameid_head = models.ForeignKey(nameid_head)
    location_name = models.CharField(max_length=16)
    ttl = models.IntegerField(default=120)
    location_type = models.IntegerField(max_length=1, default=0, choices=RECORD_TYPE)
    until = models.CharField(max_length=32)
    max_ip = models.IntegerField(default=2)
    preferred = models.IntegerField(max_length=8, default=0, choices=PREFERRED_CHOICES)
    use_probe = models.BooleanField(default=True)
    vip_count = models.IntegerField(default=0)
    enable_vip_count = models.IntegerField(default=0)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    location_info = models.CharField(max_length=16, default='')
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)
    
#----------------------------------------------------------------------
class nameid_location_vip(models.Model):
    RECORD_TYPE = (
        (0,'A'),
        (1,'CNAME'),
    )
    
    STATUS = (
            (0,'disable'),
            (1,'enable'),
            (2,'delete'),
    )
    
    nameid_head = models.ForeignKey(nameid_head)
    nameid_location = models.ForeignKey(nameid_location)
    vip_value = models.CharField(max_length=64)
    vip_type = models.IntegerField(max_length=1, default=0, choices=RECORD_TYPE)
    until = models.CharField(max_length=32)
    use_probe = models.BooleanField(default=False)
    probe_port = models.IntegerField(default=80)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    preced = models.IntegerField(default=1)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)

#----------------------------------------------------------------------
class nameid_version(models.Model):
    version = models.AutoField(primary_key=True)
    group_id = models.IntegerField()
    nameid_head_id = models.IntegerField()
    add_time = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        get_latest_by = 'version'   
        
#----------------------------------------------------------------------
class nameid_data(models.Model):
    RECORD_TYPE = (
        (0,'A'),
        (1,'CNAME'),
    )
    
    PREFERRED_CHOICES = (
            (0,'rr'),
            (1,'ratio'),
            (2,'ga'),
            (3,'path'),
    )
    
    STATUS = (
            (0,'disable'),
            (1,'enable'),
            (2,'delete'),
    )
    
    
    CHECK_SUCESS = (
            (0,'fail'),
            (1,'sucess'),
    )
    
    CALCULAT_STATUS = (
        (True,'calculat'),
        (False,'no calculat'),
    )

    nameid_head_id = models.IntegerField(primary_key=True)
    group_id = models.IntegerField()
    nameid_name = models.CharField(max_length=128)
    is_delete = models.BooleanField(default=False)
    dlc_data = models.TextField()
    dns_data = models.TextField()
    modify_time = models.DateTimeField(auto_now=True)
    
    @staticmethod
    def getDataByVersion(version, g_id):
        cursor = connection.cursor()
        cursor.execute("""
            select d.nameid_head_id,d.dlc_data,d.dns_data
            from config_nameid_version as v, config_nameid_data as d
            where v.version>%s and v.group_id=%d and v.nameid_head_id=d.nameid_head_id
            group by v.nameid_head_id""" % (version, g_id))
        return cursor.fetchall()

    @staticmethod
    def __checkNameid(nameid_location_list, nameid_location_map):
        vip_count=0
        location_count=0
        for item in nameid_location_map:
            location_count+=1
            for vip in nameid_location_map[item]['vips']:
                vip_count+=1
                
        if vip_count!=0 and location_count!=0:
            return True
        
        return False
    
    @staticmethod
    def updateDataByNameidHead(nameid_head_id):
        """
        error code:
        0 suecess
        2 can't find nameid by nameid_id
        3 nameid check error..  
        """
        try:
            nameid_head_data = nameid_head.objects.get(id=nameid_head_id)
        except:
            return 2 
        
        data = nameid_data()
        data.nameid_head_id = nameid_head_id
        data.nameid_name = nameid_head_data.nameid_name
        data.group_id = nameid_head_data.group_id
        
        if nameid_head_data.status == 2:
            old_nameid_data = nameid_data.objects.filter(nameid_name=nameid_head_data.nameid_name, group_id=nameid_head_data.group_id)
            old_nameid_data.delete()
            
            data.dlc_data = "nameid {\n"
            data.dlc_data = data.dlc_data + "\tname\t\"" + nameid_head_data.nameid_name + "\"\n"
            data.dlc_data = data.dlc_data + "\tmodify_status\tdel\n"
            data.dlc_data = data.dlc_data + "}\n"
            
            data.dns_data = "nameid {\n"
            data.dns_data += "\tname\t\"" + nameid_head_data.nameid_name + "\"\n"
            data.dns_data += "\tmodify_status\tdel\n"
            data.dns_data += "\tlocation{\n"
            data.dns_data += "\t\tname\t\"default\"\n"
            data.dns_data += "\t\taddress\t1.1.1.1\n"
            data.dns_data += "\t}\n"
            data.dns_data += "}\n"
            
            data.is_delete = True
            data.save()
            return 0
            
        
        # create nameid struct.
        nameid_location_list = nameid_location.objects.filter(nameid_head__id=nameid_head_id,status=1,enable_vip_count__gt=0)
        nameid_location_vip_list = nameid_location_vip.objects.filter(nameid_head__id=nameid_head_id,status=1).order_by('preced')
        nameid_location_map = {}
        for location in nameid_location_list:
            nameid_location_map[location.id] = {}
            nameid_location_map[location.id]['location'] = location
            nameid_location_map[location.id]['vips'] = []
        for vip in nameid_location_vip_list:
            if nameid_location_map.has_key(vip.nameid_location_id):
                nameid_location_map[vip.nameid_location_id]['vips'].append(vip)
        
        if not nameid_data.__checkNameid(nameid_location_list, nameid_location_map):
            nameid_head_data.check_sucess = False
            nameid_head_data.save()
            return 3 

        nameid_head_data.check_sucess = True
        nameid_head_data.save()
        
        old_nameid_data = nameid_data.objects.filter(nameid_name=nameid_head_data.nameid_name, group_id=nameid_head_data.group_id)
        old_nameid_data.delete()
            
        #print nameid struct.
        data.dlc_data = "nameid {\n"
        data.dlc_data = data.dlc_data + "\tname\t\"" + nameid_head_data.nameid_name + "\"\n"
        data.dlc_data = data.dlc_data + "\tstatus\t" + STATUS[nameid_head_data.status][1] + "\n"
        data.dlc_data = data.dlc_data + "\tterritory_group\t\"Territory-Global\"\n"
        data.dlc_data = data.dlc_data + "\tdns_group\t\"" + nameid_head_data.group.name +"\"\n"
        data.dns_data = data.dlc_data
        
        data.dlc_data = data.dlc_data + "\tprobe\t" + STATUS[nameid_head_data.use_probe][1] + "\n"
        if nameid_head_data.dlc_calculat:
            data.dlc_data = data.dlc_data + "\tcalculat_status\tenable\n"
        else:
            data.dlc_data = data.dlc_data + "\tcalculat_status\tdisable\n"
        #data.dlc_data = data.dlc_data + "\tutil\t" + str2steamp( time.strftime("%Y-%m-%d %H:%M:%S",nameid_head_data.modify_time) ) + "\n"

        hasdefault = 0
        for item in nameid_location_map:
            location = nameid_location_map[item]['location']
            if location.location_name=='default':
                hasdefault=1
            tmp_location =  "\tlocation {\n"
            tmp_location += "\t\tname\t\"" + location.location_name + "\"\n"
            tmp_location += "\t\tttl\t" + str(location.ttl) + "\n"
            tmp_location += "\t\tmax_ip\t" + str(location.max_ip) + "\n"
            tmp_location += "\t\tstatus\t" + STATUS[location.status][1] + "\n"
            tmp_location += "\t\tpreferred\t" + PREFERRED_CHOICES[location.preferred][1] + "\n"

            data.dlc_data += tmp_location
            data.dns_data += tmp_location
            
            data.dlc_data += "\t\tprobe\t" + STATUS[location.use_probe][1] + "\n"
            if location.location_type==0:
                for vip in nameid_location_map[item]['vips']:
                    data.dlc_data = data.dlc_data + "\t\tvs {\n"
                    data.dlc_data = data.dlc_data + "\t\t\taddress\t" + vip.vip_value + "\n"
                    data.dlc_data = data.dlc_data + "\t\t\tstatus\t" + STATUS[vip.status][1] + "\n"
                    data.dlc_data = data.dlc_data + "\t\t\tprobe\t" + STATUS[vip.use_probe][1] + "\n"
                    data.dlc_data = data.dlc_data + "\t\t}\n"
                    
                    data.dns_data += "\t\tvs {\n"
                    data.dns_data += "\t\t\taddress\t" + vip.vip_value + "\n"
                    data.dns_data += "\t\t\tstatus\t" + STATUS[vip.status][1] + "\n"
                    data.dns_data += "\t\t}\n"
                    
            else:
                data.dlc_data = data.dlc_data + "\t\ttype cname\n"
                data.dns_data = data.dns_data + "\t\ttype cname\n"
                for vip in nameid_location_map[item]['vips']:
                    data.dlc_data = data.dlc_data + "\t\tcname\t\"" + vip.vip_value + "\"\n"
                    data.dns_data = data.dns_data + "\t\tcname\t\"" + vip.vip_value + "\"\n"

            data.dlc_data = data.dlc_data + "\t}\n"
            data.dns_data = data.dns_data + "\t}\n"
            
        #if default is null.
        if hasdefault==0:
            tmp_location = "\tlocation {\n"
            tmp_location += "\t\tname\t\"default\"\n"
            tmp_location += "\t\tttl\t120\n"
            tmp_location += "\t\tmax_ip\t2\n"
            tmp_location += "\t\tstatus\tenable\n"
            tmp_location += "\t\tpreferred\trr\n"
            
            data.dlc_data = data.dlc_data + tmp_location
            data.dns_data = data.dns_data + tmp_location

            data.dlc_data = data.dlc_data + "\t\tprobe\tenable\n"
            vip_dft_map = {}
            for item in nameid_location_map:
                for vip in nameid_location_map[item]['vips']:
                    if vip_dft_map.has_key(vip.vip_value):
                        continue
                    
                    vip_dft_map[vip.vip_value] = 0
                    data.dlc_data = data.dlc_data + "\t\tvs {\n"
                    data.dlc_data = data.dlc_data + "\t\t\taddress\t" + vip.vip_value + "\n"
                    data.dlc_data = data.dlc_data + "\t\t\tstatus\t" + STATUS[vip.status][1] + "\n"
                    data.dlc_data = data.dlc_data + "\t\t\tprobe\t" + STATUS[vip.use_probe][1] + "\n"
                    data.dlc_data = data.dlc_data + "\t\t}\n" 
                    
                    data.dns_data = data.dns_data + "\t\tvs {\n"
                    data.dns_data = data.dns_data + "\t\t\taddress\t" + vip.vip_value + "\n"
                    data.dns_data = data.dns_data + "\t\t\tstatus\t" + STATUS[vip.status][1] + "\n"
                    data.dns_data = data.dns_data + "\t\t}\n" 
                    
            data.dlc_data = data.dlc_data + "\t}\n"
            data.dns_data = data.dns_data + "\t}\n"
            
        data.dlc_data = data.dlc_data + "}\n"
        data.dns_data += "}\n"
        
        data.is_delete = False
        
        data.save()
        return 0
#  ------------nameid end -------------------
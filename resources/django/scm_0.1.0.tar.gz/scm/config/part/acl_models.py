from django.db import models
from django.db import connection
from scm.common.models import group

#  ------------acl begin -------------------

class acl(models.Model):
    STATUS = (
            (0,'disable'),
            (1,'ensable'),
            (2,'delete'),
    )
    
    group = models.ForeignKey(group)
    cidr = models.CharField(max_length=20)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)

#----------------------------------------------------------------------
class acl_version(models.Model):
    version = models.AutoField(primary_key=True)
    group_id = models.IntegerField()
    add_time = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        get_latest_by = 'version'

#----------------------------------------------------------------------
class acl_data(models.Model):
    group_id = models.IntegerField(primary_key=True)
    acl_data = models.TextField()
    modify_time = models.DateTimeField(auto_now=True)
    
    @staticmethod
    def getDataByVersion(version, g_id):
        cursor = connection.cursor()
        cursor.execute("""
            select d.group_id,d.acl_data
            from config_acl_version as v, config_acl_data as d
            where v.version>%s and v.group_id=%d and v.group_id=d.group_id""" % (version, g_id))
        return cursor.fetchall()
    
    @staticmethod
    def getLastData(g_id):
        cursor = connection.cursor()
        cursor.execute("""
            select group_id,acl_data
            from config_acl_data
            where group_id=%d""" % (g_id))
        return cursor.fetchall()
    
    @staticmethod
    def updateData(g_id=0):
        acl_list = acl.objects.filter(group__id=g_id)
        
        try:
            acl_conf = acl_data.objects.get(group_id=g_id)
        except:
            acl_conf = acl_data(group_id=g_id)
        
        acl_conf.group_id = g_id
        acl_conf.data = 'acl{\n'
        for item in acl_list:
            acl_conf.data += item.cidr + "\n"
        acl_conf.data += '}\n'
        acl_conf.save()
        
        ver = acl_version(group_id=g_id)
        ver.save()
        
        return True
        
#  ------------acl end -------------------

# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage
from scm.common.models import group,device,application
import simplejson
import urllib2
from scm.util.TCSendTask import TCSendTask
from scm.util.decorators import authority_required

# webluker login main page
@login_required
def index(request):
    return listDns(request)

@authority_required(100)
def listDns(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rip = request.REQUEST.get('rip', '')
    rhost = request.REQUEST.get('rhost', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
    
    dvc = device.objects.filter(app__id='200301020003')
    if len(rgroup)!=0:
        dvc = dvc.filter(group__id=rgroup)
    if len(rip)!=0:
        dvc = dvc.filter(mip__contains=rip)
    if len(rhost)!=0:
        dvc = dvc.filter(hostname__contains=rhost)
        
    group_list = group.objects.all()
    
    if hits:
        pagination = split_page(hits, '/config/operate/list_dns/?rip=%s&rhost=%s&rgroup=%s&'% \
                                (rip, rhost, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(dvc.count(), '/config/operate/list_dns/?rip=%s&rhost=%s&rgroup=%s&'% \
                                (rip, rhost, rgroup), \
                                results_per_page, page)
        
    return render_to_response('config/operate/dns_list.html', {'rip':rip,'rhost':rhost,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'device_list':dvc[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))
"""
flush_name --domain "www.sina.com"
flush_cache

/FlexiDNS/application/sbin/rndc flushname www.sina.com
/FlexiDNS/application/sbin/rndc flushcache

flush_cache 清空缓存
flush_name 清空指定名字的缓存

"""
@authority_required(100)
def clearSingle(request):
    device_id= request.REQUEST.get('device_id', '')
    device_sn = request.REQUEST.get('device_sn', '')
    domain = request.REQUEST.get('domain', '')
    
    tc = TCSendTask('dns','',0)
    fp = tc.open("clear_single.sh")
    fp.write("#/bin/sh\n")
    fp.write("""/FlexiDNS/application/sbin/rndc -k /FlexiDNS/conf/rndc.key flushname \"%s\" \n""" % domain)
    tc.makeTar()
    tc.send(device_sn, TCSendTask.DNS_APP_ID, u'清除域名缓存'+domain)
  
    dv = device.objects.filter(sn=device_sn)
    if len(dv) > 0 :
        writeLog(getUser(request).id, 'operate', "清除%s设备上的域名缓存%s" % ( dv[0].hostname.encode('utf8'), domain.encode('utf8')) )
    else:
        writeLog(getUser(request).id, 'operate', "清除域名缓存%s" % (domain.encode('utf8')) )
    
    data = {}
    data['ret_josn']='ok'    
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def clearAll(request):
    device_id= request.REQUEST.get('device_id', '')
    device_sn = request.REQUEST.get('device_sn', '')
   
    tc = TCSendTask('dns','',0)
    fp = tc.open("clear_all.sh")
    fp.write("#/bin/sh\n")
    fp.write("""/FlexiDNS/application/sbin/rndc -k /FlexiDNS/conf/rndc.key flush \n""")
    tc.makeTar()
    tc.send(device_sn, TCSendTask.DNS_APP_ID, u'清除所有域名缓存')
  
    dv = device.objects.filter(sn=device_sn)
    if len(dv) > 0 :
        writeLog(getUser(request).id, 'operate', "清除%s设备上的所有域名缓存" % ( dv[0].hostname.encode('utf8')) )
    else:
        writeLog(getUser(request).id, 'operate', "清除所有域名缓存" )
        
    data = {}
    data['ret_josn']='ok'      
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def restartDns(request):
    device_id= request.REQUEST.get('device_id', '')
    device_sn = request.REQUEST.get('device_sn', '')
    
    tc = TCSendTask('dns','',0)
    fp = tc.open("restart_dns.sh")
    fp.write("#/bin/sh\n")
    fp.write("""/etc/init/fdns restart\n""")
    tc.makeTar()
    tc.send(device_sn, TCSendTask.DNS_APP_ID, u'重启DNS服务')
  
    dv = device.objects.filter(sn=device_sn)
    if len(dv) > 0 :
        writeLog(getUser(request).id, 'operate', "重启%s设备DNS服务" % ( dv[0].hostname.encode('utf8')) )
    else:
        writeLog(getUser(request).id, 'operate', "重启DNS服务" )
    data = {}
    data['ret_josn']='ok'
            
    return HttpResponse(simplejson.dumps(data))



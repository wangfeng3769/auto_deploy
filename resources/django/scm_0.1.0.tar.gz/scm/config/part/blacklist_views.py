# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage, addUserDev
from scm.config.models import zone_version,zone_data,zone_head,zone_record,zone_template
import simplejson
import time
import urllib2
import re


def index(request):
    return render_to_response('monitor/index.html', {}, context_instance = RequestContext(request))



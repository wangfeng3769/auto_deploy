from django.db import models
from django.db import connection
from scm.common.models import group

#  ------------blacklist begin -------------------

class blacklist(models.Model):
    STATUS = (
            (0,'disable'),
            (1,'ensable'),
            (2,'delete'),
    )
    
    group = models.ForeignKey(group)
    cidr = models.CharField(max_length=20)
    status = models.IntegerField(max_length=1, default=1, choices=STATUS)
    add_time = models.DateTimeField(auto_now_add=True)
    modify_time = models.DateTimeField(auto_now=True)

#----------------------------------------------------------------------
class blacklist_version(models.Model):
    version = models.AutoField(primary_key=True)
    group_id = models.IntegerField()
    add_time = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        get_latest_by = 'version'

#----------------------------------------------------------------------
class blacklist_data(models.Model):
    group_id = models.IntegerField(primary_key=True)
    blacklist_data = models.TextField()
    modify_time = models.DateTimeField(auto_now=True)
    
    @staticmethod
    def getDataByVersion(version, g_id):
        cursor = connection.cursor()
        cursor.execute("""
            select d.group_id,d.blacklist_data
            from config_blacklist_version as v, config_blacklist_data as d
            where v.version>%s and v.group_id=%d and v.group_id=d.group_id""" % (version, g_id))
        return cursor.fetchall()
    
    @staticmethod
    def getLastData(g_id):
        cursor = connection.cursor()
        cursor.execute("""
            select group_id,blacklist_data
            from config_blacklist_data
            where group_id=%d""" % (g_id))
        return cursor.fetchall()
    
    @staticmethod
    def updateData(g_id=0):
        blacklist_list = blacklist.objects.filter(group__id=g_id)
        
        try:
            blacklist_conf = blacklist_data.objects.get(group_id=g_id)
        except:
            blacklist_conf = blacklist_data(group_id=g_id)
        
        blacklist_conf.group_id = g_id
        blacklist_conf.data = 'blacklist{\n'
        for item in blacklist_list:
            blacklist_conf.data += item.cidr + "\n"
        blacklist_conf.data += '}\n'
        blacklist_conf.save()
        
        ver = blacklist_version(group_id=g_id)
        ver.save()
        
        return True
        
#  ------------blacklist end -------------------

# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from scm.config.nameid_models import nameid_version,nameid_data,nameid_head,nameid_location,nameid_location_vip,nameid_template_location,nameid_template_location_body
from scm.common.models import group,device,application
from django.template import RequestContext
from scm.util.lukWeb import split_page,getUser,generateXmlMessage,writeLog,addUserDev
import simplejson
import urllib2
import re
from scm.util.decorators import authority_required

RREFERRD_TYPE = {
'RR':0,
'RATIO':1,
'GA':2,
'PATH':3
}

LOCATION_TYPE = {
'A':0,
'CNAME':1
}
  
GROUP_TYPE = {
'gslb':0,
'common':1,
'minicdn':2
}


@authority_required(100)
def addGslbNameidPage(request):
    location_template = nameid_template_location.objects.filter(template_type=0)
    group_list = group.objects.all()
    
    return render_to_response('config/gslb/gslb_add.html', {'group_list':group_list,'location_template':location_template,'error_info':'ok'}, context_instance = RequestContext(request))


@authority_required(100)
def addGslbNameid(request):
    #create nameid head, create location.....
    nameid = request.REQUEST.get('nameid', '')
    rgroup = request.REQUEST.get('rgroup', '')
    #nameid_name = request.REQUEST.get('nameid_name', '')
    location_pref = request.REQUEST.get('location_pref', '-1')
    

    nameid_head_data = nameid_head.objects.filter(nameid_name=nameid, group__id=rgroup)
    if len(nameid_head_data) >= 1:
	info = "域名[ %s ]已经存在，不能添加！" % nameid.encode('utf8')
	xml = generateXmlMessage(info, '/config/gslb/list_gslb/')
	return HttpResponse(xml, content_type="text/xml",mimetype="text/xml")
	#return HttpResponseRedirect('/config/gslb/nameid/list_nameid/?ret_info=%s' % urllib2.quote( info ))

        # error , zone is exist.
    else:
        nameid_head_data = nameid_head()
        nameid_head_data.nameid_name=nameid
        nameid_head_data.group_id=rgroup
        nameid_head_data.group_type=GROUP_TYPE['gslb']
        nameid_head_data.save()

        __addLocation4NameidByTemplate(nameid_head_data.id, nameid_head_data, location_pref)
        
        #if 0 == nameid_data.updateDataByNameidHead(nameid_head_data.id):
        #    ver = nameid_version(nameid_head_id=nameid_head_data.id)
        #    ver.save()
    
    writeLog(getUser(request).id, 'gslb', "添加域名%s" % (nameid_head_data.nameid_name.encode('utf8')) )
    xml = generateXmlMessage(u"添加成功！", '/config/gslb/list_gslb/')
    return HttpResponse(xml, content_type="text/xml",mimetype="text/xml")
    #return HttpResponseRedirect('/config/gslb/nameid/list_nameid/?ret_info=%s' % urllib2.quote( info ))

def __addLocation4NameidByTemplate(nameid_id, nameid_head_data,location_pref):
    nameid_location.objects.filter(nameid_head__id=nameid_id).delete()
    nameid_location_vip.objects.filter(nameid_head__id=nameid_id).delete()
    
    #if location_pref=='-1':
    #locationlist = template_location.objects.filter(template_type=0)
    #else:
    locationlist = nameid_template_location.objects.filter(id=location_pref)
	
    locationbodylist = nameid_template_location_body.objects.filter(template_location__id=locationlist[0].id)
    for loca in locationbodylist:
	location = nameid_location()
	location.nameid_head_id = nameid_id
	location.location_name = loca.location_ipset
	location.location_info = loca.location_name
	location.use_probe = 1
	location.status = 1
	location.save()
	nameid_head_data.location_count = nameid_head_data.location_count +1
	nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1
	    
    nameid_head_data.save()
    
def __addLocation4Nameid(nameid_id, nameid_head_data):
    nameid_location.objects.filter(nameid_head__id=nameid_id).delete()
    nameid_location_vip.objects.filter(nameid_head__id=nameid_id).delete()
    
    location = nameid_location()
    location.nameid_head_id = nameid_id
    location.location_name = 'default'
    location.location_info = u'默认'
    location.status = 1
    location.save()
    nameid_head_data.location_count = nameid_head_data.location_count +1
    nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1 
    
    location = nameid_location()
    location.nameid_head_id = nameid_id
    location.location_name = 'cnc'
    location.location_info = u'网通'
    location.status = 1
    location.save()
    nameid_head_data.location_count = nameid_head_data.location_count +1
    nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1
    
    location = nameid_location()
    location.nameid_head_id = nameid_id
    location.location_name = 'tel'
    location.location_info = '电信'
    location.status = 1
    location.save()
    nameid_head_data.location_count = nameid_head_data.location_count +1
    nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1
    
    location = nameid_location()
    location.nameid_head_id = nameid_id
    location.location_name = 'cer'
    location.location_info = '教育网'
    location.status = 1
    location.save()
    nameid_head_data.location_count = nameid_head_data.location_count +1
    nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1
    
    location = nameid_location()
    location.nameid_head_id = nameid_id
    location.location_name = '!cn'
    location.location_info = '海外'
    location.status = 1
    location.save()
    nameid_head_data.location_count = nameid_head_data.location_count +1
    nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1
    
    nameid_head_data.save()
    

@authority_required(10)
def listNameid(request):
    rgroup = request.REQUEST.get('rgroup', '')
    ret_info = request.REQUEST.get('ret_info', '')
    rnameid = request.REQUEST.get('rnameid', '')
    rvip = request.REQUEST.get('rvip', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
    
    nameid_list = nameid_head.objects.filter(group_type=GROUP_TYPE['gslb'])
    if len(rnameid)!=0:
        nameid_list = nameid_list.filter(nameid_name__contains=rnameid)
    if len(rgroup)!=0:
        nameid_list = nameid_list.filter(group__id=rgroup)
	
    if len(rvip)!=0:
	nameid_hase_id = {}
        vip_list = nameid_location_vip.objects.filter(vip_value__contains=rvip)
        for item in vip_list:
            nameid_hase_id[item.nameid_head_id]=0
            
        nameid_real_list = []
        for item in nameid_list:
            if nameid_hase_id.has_key(item.id):
                nameid_real_list.append(item)
        nameid_list = nameid_real_list
	
    if hits:
        pagination = split_page(hits, '/config/gslb/list_gslb/?rnameid=%s&rvip=%s&rgroup=%s&'% \
                                (rnameid, rvip, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(len(nameid_list), '/config/gslb/list_gslb/?rnameid=%s&rvip=%s&rgroup=%s&'% \
                                (rnameid, rvip, rgroup), \
                                results_per_page, page)
	
    group_list = group.objects.all()
    return render_to_response('config/gslb/gslb_list.html', {'group_list':group_list,'ret_info':ret_info,'rgroup':rgroup,'rnameid':rnameid,'rvip':rvip,'nameid_list':nameid_list[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))

@authority_required(10)
def editNameid(request):
    nameid_name = request.REQUEST.get('nameid_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    ret_info = request.REQUEST.get('ret_info', '')
    
    location_list = nameid_location.objects.filter(nameid_head__id=nameid_id).order_by('id')
    
    return render_to_response('config/gslb/gslb_edit.html', {'location_list':location_list,'nameid_name':nameid_name,'nameid_id':nameid_id,'ret_info':ret_info}, context_instance = RequestContext(request))

@authority_required(100)
def delNameid(request):
    nameid_name = request.REQUEST.get('nameid_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    
    try:
        nameid_head_data = nameid_head.objects.get(id=nameid_id)
        nameid_head_data.status = 2
        nameid_head_data.save()
        rgroup = nameid_head_data.group_id
	
        nameid_data.updateDataByNameidHead(nameid_id)
        vip_list = nameid_location_vip.objects.filter(nameid_head__id=nameid_id)    
        location_list = nameid_location.objects.filter(nameid_head__id=nameid_id)

	nameid_head_data.delete()	    
        location_list.delete()
        vip_list = nameid_location_vip.objects.filter(nameid_head__id=nameid_id)
        vip_list.delete()
        ver = nameid_version(nameid_head_id=nameid_id, group_id=rgroup)
        ver.save()
	
	writeLog(getUser(request).id, 'gslb', "删除域名%s" % (nameid_head_data.nameid_name.encode('utf8')) )
    except:
        #can't get nameid....
        return False
    
    return HttpResponseRedirect('/config/gslb/list_gslb/?ret_info=%s' % u"删除成功！")

@authority_required(100)
def disableNameid(request):
    nameid_name = request.REQUEST.get('nameid_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    
    try:
        nameid_head_data = nameid_head.objects.get(id=nameid_id)
        if nameid_head_data.status == 1:
            nameid_head_data.status = 0
            nameid_head_data.save()
            
            if 0==nameid_data.updateDataByNameidHead(nameid_id):
                ver = nameid_version(nameid_head_id=nameid_id, group_id=nameid_head_data.group_id)
                ver.save()
	writeLog(getUser(request).id, 'gslb', "禁用域名%s" % (nameid_name.encode('utf8')) )
    except:
        #can't get nameid....
        return False
    
    return HttpResponseRedirect('/config/gslb/list_gslb/?ret_info=%s' % u"禁用成功！")

@authority_required(100)
def enableNameid(request):
    nameid_name = request.REQUEST.get('nameid_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    
    try:
        nameid_head_data = nameid_head.objects.get(id=nameid_id)
        if nameid_head_data.status == 0:
            nameid_head_data.status = 1
            nameid_head_data.save()
            
            if 0==nameid_data.updateDataByNameidHead(nameid_id):
                ver = nameid_version(nameid_head_id=nameid_id, group_id=nameid_head_data.group_id)
                ver.save()
		
	writeLog(getUser(request).id, 'gslb', "启用域名%s" % (nameid_name.encode('utf8')) )
    except:
        #can't get nameid....
        return False
    
    return HttpResponseRedirect('/config/gslb/list_gslb/?ret_info=%s' % u"启用成功！")


@authority_required(100)
def saveLocation(request):
    data = __getJosnPostData(request)
    
    url_pram = "nameid_id=%s&nameid_name=%s&" % \
             (data['nameid_id'], data['nameid_name'])
    try:
        nameid_head_data = nameid_head.objects.get(id=data['nameid_id'])
        location_list = nameid_location.objects.filter(nameid_head__id=data['nameid_id'],id=data['location_id'])
        if location_list.count() != 0 and str(location_list[0].id)!=data['location_id']:
            #error nameid's location is exist...
            raise
        
	old_pre=location_list[0].preferred
        location = location_list[0]
        #location.nameid_head_id = data['nameid_id']
        location.location_name = data['location_name']
        #location.location_info = 'empty'
        location.preferred=RREFERRD_TYPE[data['preferred']]
        #location.location_type=LOCATION_TYPE[data['type']]
        location.ttl=data['ttl']
        location.max_ip=data['maxip']
	#if data['preferred']=="GA":
	#    location.max_ip=1
        #location.status = 1
        location.save()
        #data['location_type'] = location.location_type
        #nameid_head_data.location_count = nameid_head_data.location_count +1
        #nameid_head_data.enable_location_count = nameid_head_data.enable_location_count +1
        
        if 0==nameid_data.updateDataByNameidHead(data['nameid_id']):
            ver = nameid_version(nameid_head_id=data['nameid_id'], group_id=nameid_head_data.group_id)
            ver.save()
	 
	writeLog(getUser(request).id, 'gslb', "修改域名%s的%s区域为%s策略,TTL %s,MaxIP %s" % 
	         (nameid_head_data.nameid_name.encode('utf8'), location.location_info.encode('utf8'), data['preferred'].encode('utf8'), data['ttl'].encode('utf8'), data['maxip'].encode('utf8')) )
    except:
        #error , can't find nameid.
        if not nameid_head_data:
            info = "修改失败！找不到域名！"
	    return HttpResponseRedirect('/config/gslb/list_gslb/?ret_info=%s' % urllib2.quote( info ))
        else:
            info = "修改失败！找不到区域！"
	    return HttpResponseRedirect('/config/gslb/list_gslb/?ret_info=%s' % urllib2.quote( info ))
    
    info = u"修改成功！"
    return HttpResponseRedirect('/config/gslb/edit_gslb?%s&ret_info=%s' % ( url_pram, info ) )

@authority_required(100)
def disableLocation(request):
    location_id = request.REQUEST.get('location_id', '')
    location_name = request.REQUEST.get('location_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    nameid_name = request.REQUEST.get('nameid_name', '')
    
    try:
        nameid = nameid_head.objects.get(id=nameid_id)
        location = nameid_location.objects.get(id=location_id)
        if location.status == 1:
            location.status = 0
            location.save()
            nameid.enable_location_count = nameid.enable_location_count-1
            nameid.save()
            
            if 0==nameid_data.updateDataByNameidHead(nameid_id):
                ver = nameid_version(nameid_head_id=nameid_id, group_id=nameid.group_id)
                ver.save()
	writeLog(getUser(request).id, 'gslb', "禁用域名%s的%s区域" % (nameid_name.encode('utf8'), location.location_info.encode('utf8')) )
    except:
        #can't get nameid....
        return False
    
    return HttpResponseRedirect('/config/gslb/edit_gslb/'+
                                '?location_id='+location_id+
                                '&location_name='+location_name+
                                '&nameid_id='+nameid_id+
                                '&nameid_name='+nameid_name+ 
                                '&ret_info='+u"禁用成功！")

@authority_required(100)
def enableLocation(request):
    location_id = request.REQUEST.get('location_id', '')
    location_name = request.REQUEST.get('location_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    nameid_name = request.REQUEST.get('nameid_name', '')
   
    try:
        nameid = nameid_head.objects.get(id=nameid_id)
        location = nameid_location.objects.get(id=location_id)
        if location.status == 0:
            location.status = 1
            location.save()
            nameid.enable_location_count = nameid.enable_location_count+1
            nameid.save()
            
            if 0==nameid_data.updateDataByNameidHead(nameid_id):
                ver = nameid_version(nameid_head_id=nameid_id, group_id=nameid.group_id)
                ver.save()
	writeLog(getUser(request).id, 'gslb', "启用域名%s的%s区域" % (nameid_name.encode('utf8'), location.location_info.encode('utf8')) )
    except:
        #can't get nameid....
        return False
    
    return HttpResponseRedirect('/config/gslb/edit_gslb/'+
                                '?location_id='+location_id+
                                '&location_name='+location_name+
                                '&nameid_id='+nameid_id+
                                '&nameid_name='+nameid_name+ 
                                '&ret_info='+u"启用成功！")

@authority_required(10)
def editLocation(request):
    nameid_name = request.REQUEST.get('nameid_name', '')
    nameid_id = request.REQUEST.get('nameid_id', '')
    location_name = request.REQUEST.get('location_name', '')
    location_info = request.REQUEST.get('location_info', '')
    location_id = request.REQUEST.get('location_id', '')
    location_type = request.REQUEST.get('preferred', '0')
    
    vip_list = nameid_location_vip.objects.filter(nameid_head__id=nameid_id,nameid_location__id=location_id).order_by('preced')
    
    if location_type == '2':
	return render_to_response('config/gslb/gslb_location_edit_ga.html', {'vip_list':vip_list,'nameid_name':nameid_name,'nameid_id':nameid_id,'location_name':location_name,'location_info':location_info,'location_id':location_id}, context_instance = RequestContext(request))
    else:
	return render_to_response('config/gslb/gslb_location_edit.html', {'vip_list':vip_list,'nameid_name':nameid_name,'nameid_id':nameid_id,'location_name':location_name,'location_info':location_info,'location_id':location_id}, context_instance = RequestContext(request))
    
    
def __getJosnPostData(request):
    data = {}
    data['vtime']=request.REQUEST.get('vtime', '')
    data['nameid_id']=request.REQUEST.get('nameid_id', '')
    data['location_id']=request.REQUEST.get('location_id', '')
    data['preferred']=request.REQUEST.get('preferred', 'RR')
    data['type']=request.REQUEST.get('type', '0')
    data['ttl']=request.REQUEST.get('ttl', '120')
    data['maxip']=request.REQUEST.get('maxip', '120')
    data['location_name']=request.REQUEST.get('location_name', '')
    data['location_info']=request.REQUEST.get('location_info', '')
    data['nameid_name']=request.REQUEST.get('nameid_name', '')
    data['vip']=request.REQUEST.get('vip', '')
    data['vip_id']=request.REQUEST.get('vip_id', '')
    data['status']=request.REQUEST.get('status', '1')
    data['ismaster']=request.REQUEST.get('ismaster', '1')
    data['probe_port']=request.REQUEST.get('probe_port', '80')
    data['probe']=request.REQUEST.get('probe', '0')
    
    data['ret_josn']='ok'
    return data

@authority_required(100)
def addVip(request):
    data = __getJosnPostData(request)
    
    try:
        nameid = nameid_head.objects.get(id=data['nameid_id'])
        location = nameid_location.objects.get(nameid_head__id=data['nameid_id'], id=data['location_id'])
	
        vip_list = nameid_location_vip.objects.filter(nameid_head__id=data['nameid_id'],nameid_location__id=data['location_id'],vip_value=data['vip'])
        
        if vip_list.count() == 0:
            vip = nameid_location_vip()
            vip.nameid_head_id=data['nameid_id']
            vip.nameid_location_id=data['location_id']
            vip.vip_value=data['vip']
	    vip.probe_port=data['probe_port']
	    vip.use_probe=int(data['probe'])
	    vip.preced=data['ismaster']
            vip.save()
            
            nameid.vip_count = nameid.vip_count+1
            nameid.enable_vip_count = nameid.enable_vip_count+1
            nameid.save()
            data['vip_id']=vip.id
            
            location.vip_count = location.vip_count+1
            location.enable_vip_count = location.enable_vip_count+1
            location.save()            
            
            if 0==nameid_data.updateDataByNameidHead(data['nameid_id']):
                ver = nameid_version(nameid_head_id=data['nameid_id'], group_id=nameid.group_id)
                ver.save()
		
	    writeLog(getUser(request).id, 'gslb', "为域名%s的%s区域添加VIP%s" % (nameid.nameid_name.encode('utf8'), location.location_info.encode('utf8'), vip.vip_value.encode('utf8')) )
        else :
            #vip is exist.....
            data['ret_josn']='不能添加重复的vip！'
    except:
        #can't get nameid or location ....
        if not nameid:
            data['ret_josn']='不能找到nameid！'
        else:
            data['ret_josn']='不能找到location！'
    
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def delVip(request):
    data = __getJosnPostData(request)
    
    try:
        nameid = nameid_head.objects.get(id=data['nameid_id'])
        location = nameid_location.objects.get(nameid_head__id=data['nameid_id'], id=data['location_id'])
        
        vip = nameid_location_vip.objects.get(nameid_head__id=data['nameid_id'],nameid_location__id=data['location_id'],id=data['vip_id'])
	
	oldprobe = vip.use_probe
        oldvip = vip.vip_value
	oldport = vip.probe_port
	    
        nameid.vip_count = nameid.vip_count-1
        if vip.status==1:
            nameid.enable_vip_count = nameid.enable_vip_count-1
        nameid.save()
            
        location.vip_count = location.vip_count-1
        if vip.status==1:
            location.enable_vip_count = location.enable_vip_count-1
        location.save()            
        
        vip.delete()
        
        if 0==nameid_data.updateDataByNameidHead(data['nameid_id']):
            ver = nameid_version(nameid_head_id=data['nameid_id'], group_id=nameid.group_id)
            ver.save()
	    
	writeLog(getUser(request).id, 'gslb', "为域名%s的%s区域删除VIP%s" % (nameid.nameid_name.encode('utf8'), location.location_info.encode('utf8'), vip.vip_value.encode('utf8')) )
    except:
        #can't get nameid or location or vip....
        if not nameid:
            data['ret_josn']='不能找到nameid！'
        else:
            data['ret_josn']='不能找到location！'
    
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def saveVip(request):
    data = __getJosnPostData(request)
    
    try:
        #nameid = nameid_head.objects.get(id=data['nameid_id'])
        #location = nameid_location.objects.get(nameid_head__id=data['nameid_id'], id=data['location_id'])
	
        vip = nameid_location_vip.objects.get(nameid_head__id=data['nameid_id'],nameid_location__id=data['location_id'],vip_value=data['vip'])
        if vip.id != int(data['vip_id']):
            data['ret_josn']='在同一区域内不能有两个同样的IP！'
	    return HttpResponse(simplejson.dumps(data))  
	
	#if data['ismaster']=='1':
	#    vip_master_list = nameid_location_vip.objects.filter(nameid_head__id=data['nameid_id'],nameid_location__id=data['location_id'],ismaster=1).exclude(vip_value=vip.vip_value)
	#    if vip_master_list.count() != 0:
	#	data['ret_josn']='同区域不能同时有两个主设备！'
	#	return HttpResponse(simplejson.dumps(data))
    except:
	pass
    
    vip = nameid_location_vip.objects.get(id=data['vip_id'])
    oldprobe = vip.use_probe
    oldvip=vip.vip_value
    oldport=vip.probe_port

    vip.vip_value=data['vip']
    vip.probe_port=data['probe_port']
    vip.use_probe=int(data['probe'])
    vip.preced=data['ismaster']
    vip.save()
    if 0==nameid_data.updateDataByNameidHead(data['nameid_id']):
	ver = nameid_version(nameid_head_id=data['nameid_id'], group_id=vip.nameid_head.group_id)
	ver.save()
	
    location = nameid_location.objects.get(nameid_head__id=data['nameid_id'], id=data['location_id'])
    writeLog(getUser(request).id, 'gslb', "为域名%s的%s区域修改VIP%s为%s" % (data['nameid_name'].encode('utf8'), location.location_info.encode('utf8'), oldvip.encode('utf8'), vip.vip_value.encode('utf8')) )
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def setStatusVip(request):
    data = __getJosnPostData(request)
    
    try:
        nameid = nameid_head.objects.get(id=data['nameid_id'])
        location = nameid_location.objects.get(nameid_head__id=data['nameid_id'], id=data['location_id'])
        
        vip = nameid_location_vip.objects.get(nameid_head__id=data['nameid_id'],nameid_location__id=data['location_id'],id=data['vip_id'])
        old_status=vip.status
        vip.status=int(data['status'])
        vip.save()
        
        if old_status!=vip.status and old_status==0:
            nameid.enable_vip_count = nameid.enable_vip_count+1
            nameid.save()
                
            location.enable_vip_count = location.enable_vip_count+1
            location.save() 
            writeLog(getUser(request).id, 'gslb', "为域名%s的%s区域启用VIP%s" % (nameid.nameid_name.encode('utf8'), location.location_info.encode('utf8'), vip.vip_value.encode('utf8')) )
	    
        if old_status!=vip.status and old_status==1:
            nameid.enable_vip_count = nameid.enable_vip_count-1
            nameid.save()
                
            location.enable_vip_count = location.enable_vip_count-1
            location.save()    
	    writeLog(getUser(request).id, 'gslb', "为域名%s的%s区域禁用VIP%s" % (nameid.nameid_name.encode('utf8'), location.location_info.encode('utf8'), vip.vip_value.encode('utf8')) )
	    
        if 0==nameid_data.updateDataByNameidHead(data['nameid_id']):
            ver = nameid_version(nameid_head_id=data['nameid_id'],group_id=nameid.group_id)
            ver.save()  
        
    except:
        #can't get nameid or location or vip....
        return False
    
    return HttpResponse(simplejson.dumps(data))





# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage, addUserDev
from scm.config.zone_models import zone_version,zone_data,zone_head,zone_record,zone_template
from scm.common.models import group,device,application
import simplejson
import time
import urllib2
import re
from scm.util.decorators import authority_required

RECORD_TYPE = {
'A':0,
'NS':1,
'CNAME':2,
'MX':3,
'AAAA':4,
'PTR':5,
'TXT':6
}

X_RECORD_TYPE = (
        (0,'A'),
        (1,'NS'),
        (2,'CNAME'),
        (3,'MX'),
        (4,'AAAA'),
        (5,'PTR'),
        (6,'TXT'),
)

STATUS = (
        (0,'disable'),
        (1,'ensable'),
        (2,'delete'),
)


def __addDefalutNS4Zone(zone_name, zid):
    dft_ns = zone_template.objects.filter(status=1)
    ct = 0
    for ns in dft_ns:
        zone_record_data = zone_record()
        zone_record_data.zone_head_id = zid
        zone_record_data.record_name = zone_name+'.'
        zone_record_data.record_type = ns.record_type
        zone_record_data.mx_preced = ns.mx_preced
        zone_record_data.value = ns.value
        zone_record_data.can_modify = 0
        zone_record_data.ttl = ns.ttl
        zone_record_data.save()
        ct += 1
    return ct

@authority_required(100)
def disableDomain(request):
    zone_id = request.REQUEST.get('zone_id', '-1')
    zone_name = request.REQUEST.get('zone_name', '')

    try:
        zone_head_data = zone_head.objects.get(id=zone_id)
        if zone_head_data.status==1:
            zone_head_data.status = 0
            zone_head_data.save()
            
            ret = zone_data.updateDataByZoneHead(zone_id,  0)
            
            if ret:
                ver = zone_version(zone_head_id=zone_id)
                ver.group_id = zone_head_data.group_id
                ver.save()
    except:
        #can't get zone....
        return False
    
    writeLog(getUser(request).id, 'zone', "禁用域名%s" % zone_name.encode('utf8'))
    info = u"禁用成功！"
    return HttpResponseRedirect('/config/zone/list_domain/?ret_info=%s' % info)

@authority_required(100)
def enableDomain(request):
    zone_id = request.REQUEST.get('zone_id', '-1')
    zone_name = request.REQUEST.get('zone_name', '')

    try:
        zone_head_data = zone_head.objects.get(id=zone_id)
        if zone_head_data.status==0:
            zone_head_data.status = 1
            zone_head_data.save()
            
            ret = zone_data.updateDataByZoneHead(zone_id,  0)
            
            if ret:
                ver = zone_version(zone_head_id=zone_id)
                ver.group_id = zone_head_data.group_id
                ver.save()
    except:
        #can't get zone....
        return False
    
    writeLog(getUser(request).id, 'zone', "启用域名%s" % zone_name.encode('utf8'))
    info = u"启用成功！" 
    return HttpResponseRedirect('/config/zone/list_domain/?ret_info=%s' % info)

@authority_required(100)
def domain_export(request):
    return render_to_response('config/zone/domain_list.html', {})


def __getJosnPostData(request):
    data = {}
    data['vtime']=request.REQUEST.get('vtime', '')
    data['zone_id']=request.REQUEST.get('zone_id', '-1')
    if data['zone_id']=='':
        data['zone_id'] = -1
    data['zone_name']=request.REQUEST.get('zone_name', '')
    data['domain']=request.REQUEST.get('domain', '')
    data['type']=request.REQUEST.get('type', 'A')
    data['value']=request.REQUEST.get('value', '')
    data['mx']=request.REQUEST.get('mx', '10')
    data['ttl']=request.REQUEST.get('ttl', '120')
    data['status']=request.REQUEST.get('status', '1')
    data['record_id']=request.REQUEST.get('record_id', '-1')
    if data['record_id']=='':
        data['record_id'] = -1
    data['ret_josn']='ok'
    return data

#----------------------------------------------------------------------
def __getFullRecordValue(value, zone=""):
    """if is domain and not a, add ."""
    if value=='@':
        return zone+"."
    
    
    #p = re.compile('^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$')
    #if p.match(str(value)):
    #    return value
    
    p = re.compile('^[0-9a-zA-z\-\.]{1,256}$')
    if p.match(str(value)):
        if value[-1] != '.':
            value += "." + zone
        if value[-1] != '.':
            value += "."

    return value
        
def __checkCname(hid, cname, id):
    zone_rcd = zone_record.objects.filter(zone_head__id=hid, value=cname)
    for i in zone_rcd:
        if i.record_type==RECORD_TYPE['NS']:
            return 1
        elif i.record_type==RECORD_TYPE['MX']:
            return 2
        
    zone_rcd = zone_record.objects.filter(zone_head__id=hid, record_name=cname).exclude(id=id)
    for i in zone_rcd:
        if i.record_type==RECORD_TYPE['CNAME']:
            return 3
        
    return 0

def __checkNS(hid, ns):
    zone_rcd = zone_record.objects.filter(zone_head__id=hid, record_type=RECORD_TYPE['CNAME'],record_name=ns)
    if zone_rcd.count() != 0 :
        return 1
    
    return 0

def __checkMX(hid, mx):
    zone_rcd = zone_record.objects.filter(zone_head__id=hid, record_type=RECORD_TYPE['CNAME'],record_name=mx)
    if zone_rcd.count() != 0 :
        return 1
    
    return 0

def __checkAllCnameAbort(data):
    if data['type']=='CNAME':
        ret = __checkCname(data['zone_id'], __getFullRecordValue(data['domain'], data['zone_name']) , data['record_id'])
        if ret==1:
            data['ret_josn']='NS记录['+__getFullRecordValue(data['domain'], data['zone_name']).encode('utf8')+']不能被CNAME！'
            return False
        elif ret==2:
            data['ret_josn']='MX记录['+__getFullRecordValue(data['domain'], data['zone_name']).encode('utf8')+']不能被CNAME！'
            return False
        elif ret==3:
            data['ret_josn']='['+__getFullRecordValue(data['domain'], data['zone_name']).encode('utf8')+']CNAME记录已经存在，不能重复创建CNAME！'
            return False

        
    if data['type']=='NS':
        ret = __checkNS(data['zone_id'], __getFullRecordValue(data['value'], data['zone_name']) )
        if ret==1:
            data['ret_josn']='NS记录已经被CNAME，请先删除['+__getFullRecordValue(data['value'], data['zone_name']).encode('utf8')+"]的CNAME记录！"
            return False

        
    if data['type']=='MX':
        ret = __checkMX(data['zone_id'], __getFullRecordValue(data['value'], data['zone_name']) )
        if ret==1:
            data['ret_josn']='MX记录已经被CNAME，请先删除['+__getFullRecordValue(data['value'], data['zone_name']).encode('utf8')+"]的CNAME记录！"
            return False
        
    return True
    
@authority_required(100)
def addRecord(request):
    data = __getJosnPostData(request)
    
    try:
        full_name=__getFullRecordValue(data['domain'], data['zone_name'])
        if data['type']=='NS' or data['type']=='CNAME' or data['type']=='MX' or data['type']=='PTR':
            full_value = __getFullRecordValue(data['value'], data['zone_name'])
        else:
            full_value = data['value']
            
        if (data['type']=='NS' or data['type']=='CNAME' or data['type']=='MX' or data['type']=='PTR' ) and full_name==full_value:
            data['ret_josn']='域名和记录值不能相同！'
            return HttpResponse(simplejson.dumps(data))
        
        if not __checkAllCnameAbort(data):
            return HttpResponse(simplejson.dumps(data))
            
        
        zone_head_data = zone_head.objects.get(id=data['zone_id'])
            
        zone_rcd = zone_record.objects.filter(zone_head__id=data['zone_id'], record_name=full_name, \
                                              record_type=RECORD_TYPE[ data['type'] ], value=full_value)
        
        if zone_rcd.count()!=0:
            data['ret_josn']='相同的记录已经存在，不能重复创建！'
            return HttpResponse(simplejson.dumps(data))
        
        zone_record_data = zone_record()
        zone_record_data.zone_head_id = data['zone_id']
        zone_record_data.record_name = full_name
        data['domain'] = zone_record_data.record_name
        zone_record_data.record_type = RECORD_TYPE[ data['type'] ]
        zone_record_data.mx_preced = data['mx']
        zone_record_data.value = full_value
        data['value'] = zone_record_data.value
        zone_record_data.ttl = data['ttl']
        zone_record_data.save()

        data['record_id']=zone_record_data.id
        
        ret = zone_data.updateDataByZoneHead(data['zone_id'],  0)
            
        zone_head_data.record_count = zone_head_data.record_count+1
        zone_head_data.enable_record_count = zone_head_data.enable_record_count+1
        zone_head_data.save()
        
        writeLog(getUser(request).id, 'zone', "添加记录%s %s %s %s" % (full_name.encode('utf8'), data['ttl'].encode('utf8'), data['type'].encode('utf8'), full_value.encode('utf8')) )
        
        if ret:
            ver = zone_version(zone_head_id=data['zone_id'])
            ver.group_id = zone_head_data.group_id
            ver.save()
            
        #if data['type']=='A':
        #    addUserDev(getUser(request), zone_record_data.value, "域名管理")
     
    except:
        #can't get zone....
        data['ret_josn']='不能找到域！'
    
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def saveRecord(request):
    data = __getJosnPostData(request)

    try:
        full_name=__getFullRecordValue(data['domain'], data['zone_name'])
        if data['type']=='NS' or data['type']=='CNAME' or data['type']=='MX' or data['type']=='PTR':
            full_value = __getFullRecordValue(data['value'], data['zone_name'])
        else:
            full_value = data['value']
            
        if (data['type']=='NS' or data['type']=='CNAME' or data['type']=='MX' or data['type']=='PTR' ) and full_name==full_value:
            data['ret_josn']='域名和记录值不能相同！'
            return HttpResponse(simplejson.dumps(data))
        
        if not __checkAllCnameAbort(data):
            return HttpResponse(simplejson.dumps(data))
            
        zone_head_data = zone_head.objects.get(id=data['zone_id'])
        
        
            
        zone_rcd = zone_record.objects.filter(zone_head__id=data['zone_id'], record_name=full_name, \
                                              record_type=RECORD_TYPE[ data['type'] ], value=full_value)
        
        if zone_rcd.count()!=0:
            for i in zone_rcd:
                if i.id != int(data['record_id']):
                    data['ret_josn']='相同的记录已经存在，不能重复创建！'
                    return HttpResponse(simplejson.dumps(data))
        
        zone_record_data = zone_record.objects.get(id=data['record_id'])
        
        old_n = zone_record_data.record_name
        old_t = zone_record_data.record_type
        old_ttl = zone_record_data.ttl
        old_v = zone_record_data.value
        old_status = zone_record_data.status
        #zone_record_data.zone_head_id = data['zone_id']
        zone_record_data.record_name = full_name
        data['domain'] = zone_record_data.record_name
        zone_record_data.record_type = RECORD_TYPE[ data['type'] ]
        zone_record_data.mx_preced = data['mx']
        zone_record_data.value = full_value
        data['value'] = zone_record_data.value
        zone_record_data.ttl = data['ttl']
        zone_record_data.save()
        #data['record_id']=zone_record_data.id
        
        ret = zone_data.updateDataByZoneHead(data['zone_id'],  0)

        if old_status!=zone_record_data.status and old_status==0:
            zone_head_data.enable_record_count = zone_head_data.enable_record_count+1
            zone_head_data.save()
        if old_status!=zone_record_data.status and old_status==1:
            zone_head_data.enable_record_count = zone_head_data.enable_record_count-1
            zone_head_data.save()
        
        writeLog(getUser(request).id, 'zone', "修改记录%s %s %s %s为%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8'), \
                                                                                full_name.encode('utf8'), data['ttl'].encode('utf8'), data['type'].encode('utf8'), full_value.encode('utf8')) )
        
        if ret:
            ver = zone_version(zone_head_id=data['zone_id'])
            ver.group_id = zone_head_data.group_id
            ver.save()
            
        #if data['type']=='A':
        #    addUserDev(getUser(request), zone_record_data.value, "域名管理")
    except:
        #can't get zone....
        if not zone_head_data:
            data['ret_josn']='不能找到域！'
        else:
            data['ret_josn']='不能找到记录！'
            
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def delRecord(request):
    data = __getJosnPostData(request)
    
    try:
        zone_head_data = zone_head.objects.get(id=data['zone_id'])
        
        zone_record_data = zone_record.objects.get(id=data['record_id'])
        old_n = zone_record_data.record_name
        old_t = zone_record_data.record_type
        old_ttl = zone_record_data.ttl
        old_v = zone_record_data.value
        old_status = zone_record_data.status
        zone_record_data.delete()
        
        ret = zone_data.updateDataByZoneHead(data['zone_id'],  0)

        zone_head_data.record_count = zone_head_data.record_count-1
        if old_status==1:
            zone_head_data.enable_record_count = zone_head_data.enable_record_count-1
        zone_head_data.save()
        
        writeLog(getUser(request).id, 'zone', "删除记录%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8')) )
        
        if ret:
            ver = zone_version(zone_head_id=data['zone_id'])
            ver.group_id = zone_head_data.group_id
            ver.save()
    except:
        #can't get zone....
        if not zone_head_data:
            data['ret_josn']='不能找到域！'
        else:
            data['ret_josn']='不能找到记录！'
    
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def setStatusRecord(request):
    data = __getJosnPostData(request)
    
    try:
        zone_head_data = zone_head.objects.get(id=data['zone_id'])
        
        zone_record_data = zone_record.objects.get(id=data['record_id'])
        old_status = zone_record_data.status
        zone_record_data.status=data['status']
        zone_record_data.save()

        old_n = zone_record_data.record_name
        old_t = zone_record_data.record_type
        old_ttl = zone_record_data.ttl
        old_v = zone_record_data.value
        
        ret = zone_data.updateDataByZoneHead(data['zone_id'],  0)
        
        if old_status!=int(zone_record_data.status) and old_status==0:
            zone_head_data.enable_record_count = zone_head_data.enable_record_count+1
            zone_head_data.save()
            writeLog(getUser(request).id, 'zone', "启用记录%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8')) )
        
            
        if old_status!=int(zone_record_data.status) and old_status==1:
            zone_head_data.enable_record_count = zone_head_data.enable_record_count-1
            zone_head_data.save()
            writeLog(getUser(request).id, 'zone', "禁用记录%s %s %s %s" % (old_n.encode('utf8'), old_ttl.encode('utf8'), X_RECORD_TYPE[int(old_t)][1], old_v.encode('utf8')) )
            
        if ret:        
            ver = zone_version(zone_head_id=data['zone_id'])
            ver.group_id = zone_head_data.group_id
            ver.save()
            
    except:
        #can't get zone....
        if not zone_head_data:
            data['ret_josn']='不能找到域！'
        else:
            data['ret_josn']='不能找到记录！'
    
    return HttpResponse(simplejson.dumps(data))


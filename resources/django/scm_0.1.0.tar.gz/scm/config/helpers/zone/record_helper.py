# -*- coding:utf8 -*-

import re
from scm.config.models import zone_record

RECORD_TYPE = {
    'A':0,
    'NS':1,
    'CNAME':2,
    'MX':3,
    'AAAA':4,
    'PTR':5,
    'TXT':6
}

VALUE_P = re.compile('^[0-9a-zA-z\-\.]{1,256}$')

def get_full_record(domain, value, type, zone_name):

    full_name = _full_name(domain, zone_name)
    full_value = _full_value(value, type, zone_name)

    return full_name, full_value

def _full_name(domain, zone_name):
    if domain == '':
        return '%s' % zone_name

    if VALUE_P.match(str(domain)):
        if domain[-1] != '.':
            domain += '.%s' % zone_name
        else:
            domain += '%s' % zone_name

    return domain

def _full_value(value, type, zone_name):
    if value == '@':
        return '%s.' % zone_name

    if type in ('NS', 'CNAME', 'MX', 'PTR'):
        if VALUE_P.match(str(value)):
            if value[-1] != '.':
                value += '.%s' % zone_name
            else:
                value += zone_name

    return value

def _check_cname(hid, cname, record_id):
    zone_rcd = zone_record.objects.filter(zone_head__id=hid, value=cname)
    ns_count = zone_record.objects.filter(zone_head__id=hid, value=cname, record_type=RECORD_TYPE['NS']).count()
    mx_count = zone_record.objects.filter(zone_head__id=hid, value=cname, record_type=RECORD_TYPE['MX']).count()

    if ns_count != 0:
        return 'NS记录[%s]不能被CNAME！' % full_domain
    if mx_count != 0:
        return 'MX记录[%s]不能被CNAME！' % full_domain

    try:
        zone_record.objects.get(zone_head__id=hid, record_name=cname, record_type=RECORD_TYPE['CNAME'])
        return '[%s]CNAME记录已经存在，不能重复创建CNAME！' % full_domain
    except:
        pass

    return False

def _check_other(zone_id, full_value, type):
    count = zone_record.objects.filter(zone_head__id=zone_id, record_type=RECORD_TYPE['CNAME'], record_name=full_value).count()

    if count != 0 :
        return '%s记录已经被CNAME，请先删除[%s]的CNAME记录！' % (type, full_value)

    return False

def is_invalid(zone_id, type, full_domain, full_value, record_id):

    if type =='CNAME':
        result = _check_cname(zone_id, full_domain, record_id)

    else:
        result = _check_other(zone_id, full_value, type)

    return result


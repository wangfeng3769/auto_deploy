# -*- coding:utf8 -*-

def endwith_dot(zone_name):
    if zone_name[-1] == '.':
        zone_name = zone_name[:-1]
        return endwith_dot(zone_name)
    else:
        return zone_name

if __name__ == "__main__":
    print endwith_dot('baidu.com....')

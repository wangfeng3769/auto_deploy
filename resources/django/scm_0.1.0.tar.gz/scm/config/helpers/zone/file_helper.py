# -*- coding:utf8 -*-

import re
from scm.config.models  import zone_head, zone_record
from scm.config.models import group
from scm.config.helpers.zone.head_helper import endwith_dot

def is_valid_file_type(f_name):
    file_type = f_name.split('.')[-1]

    if file_type in ('exe',):
        return False
    else:
        return True

def is_valid_file_content(content):
    zone_info = []
    file_dict = {}

    try:
        zone_items = str(content[0]).split('\t')
        # FIXME
        zone_name = '%s.' % endwith_dot(zone_items[0].strip())
        file_dict['zone_name'] = zone_name
        file_dict['ttl'] = zone_items[1].strip()
        file_dict['master_host'] = zone_items[4].strip()
        file_dict['master_email'] = zone_items[5].strip()
        file_dict['sn'] = zone_items[6].strip()
        file_dict['ttl_refresh'] = zone_items[7].strip()
        file_dict['ttl_retry'] = zone_items[8].strip()
        file_dict['ttl_expire'] = zone_items[9].strip()
        file_dict['mix_ttl'] = zone_items[10].strip()

        valid_result = [
                        re.search('^\d{0,100}$',file_dict['ttl']),
                        re.search('^\d{0,100}$',file_dict['sn']),
                        re.search('^\d{0,100}$',file_dict['ttl_refresh']),
                        re.search('^\d{0,100}$',file_dict['ttl_retry']),
                        re.search('^\d{0,100}$',file_dict['ttl_expire']),
                        re.search('^\d{0,100}$',file_dict['mix_ttl'])
                    ]

        if not all(valid_result):
            return False

        zone_info.append(file_dict)

        for item in content[1:]:
            file_dict = {}
            zone_items = item.split('\t')
            # FIXME
            record_name = '%s.' % endwith_dot(zone_items[0].strip())
            file_dict['record_name'] = record_name
            #file_dict['record_name'] = zone_items[0].strip()
            file_dict['ttl'] = zone_items[1].strip()
            file_dict['record_type'] = zone_items[3].strip()
            file_dict['value'] = zone_items[4].strip()
            zone_info.append(file_dict)
            record_types = "A|NS|CNAME|MX|AAA|RTR|TXT"
            if not  (re.search('\d{0,100}$',file_dict['ttl']) and 
            re.search(record_types ,file_dict['record_type'])):
                return False
    except:
        return False

    return zone_info

def import_zone_file(zone_info):
    zone_head_id = _import_zone_head(zone_info[0])
    _import_zone_record(zone_info[1:], zone_head_id)

def _import_zone_head(zone_head_dict):
    try:
        zone_head_ins = zone_head.objects.get(zone_name=zone_head_dict['zone_name'])

        if zone_head_dict['ttl'] != zone_head_ins.ttl: zone_head_ins.ttl = zone_head_dict['ttl']
        if zone_head_dict['master_host'] != zone_head_ins.master_host: zone_head_ins.master_host = zone_head_dict['master_host']
        if zone_head_dict['master_email'] != zone_head_ins.master_host: zone_head_ins.master_email = zone_head_dict['master_email']
        if zone_head_dict['sn'] != zone_head_ins.sn: zone_head_ins.sn = zone_head_dict['sn']
        if zone_head_dict['ttl_refresh'] != zone_head_ins.ttl_refresh: zone_head_ins.ttl_refresh = zone_head_dict['ttl_refresh']
        if zone_head_dict['ttl_retry'] != zone_head_ins.ttl_retry: zone_head_ins.ttl_retry = zone_head_dict['ttl_retry']
        if zone_head_dict['ttl_expire'] != zone_head_ins.ttl_expire: zone_head_ins.ttl_expire = zone_head_dict['ttl_expire']
        if zone_head_dict['mix_ttl'] != zone_head_ins.mix_ttl: zone_head_ins.mix_ttl = zone_head_dict['mix_ttl']

        zone_head_ins.save()
    except :
        zone_head_ins = zone_head(
                    group_id = group.objects.all()[0].id,
                    zone_name = zone_head_dict['zone_name'],
                    ttl = zone_head_dict['ttl'],
                    master_host = zone_head_dict['master_host'],
                    master_email = zone_head_dict['master_email'],
                    sn = zone_head_dict['sn'],
                    ttl_refresh = zone_head_dict['ttl_refresh'],
                    ttl_retry = zone_head_dict['ttl_retry'],
                    ttl_expire = zone_head_dict['ttl_expire'],
                    mix_ttl = zone_head_dict['mix_ttl']
                )

        zone_head_ins.save()

    return zone_head_ins.id

def _import_zone_record(zone_record_dict, zone_head_id):
    for item in zone_record_dict:

        record_type_dict = {'A':0,'NS':1,'CNAME':2,'MX':3,'AAA':4,'RTR':5,'TXT':6}
        try:
            zone_record_ins = zone_record.objects.get(record_name =item['record_name'],
                                                      record_type = record_type_dict[item['record_type']],
                                                      zone_head__id = zone_head_id)
            if item['ttl'] != zone_record_ins.ttl : zone_record_ins.ttl = item['ttl']
            if item['value'] != zone_record_ins.value :zone_record_ins.value = item['value']
            zone_record_ins.save()
        except Exception, e:
            zone_record_ins =zone_record(zone_head_id = zone_head_id,
                        record_name = item['record_name'],
                        record_type = record_type_dict[item['record_type']],
                        ttl = item['ttl'],
                        value = item['value'])
            zone_record_ins.save()



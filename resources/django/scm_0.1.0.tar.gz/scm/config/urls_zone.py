from django.conf.urls.defaults import *

urlpatterns = patterns('scm.config.views.zone.zone_head_view',
     (r'^$', 'index'),
     (r'^new', 'new'),
     (r'^create', 'create'),
     (r'^show', 'show'),
     (r'^update', 'update'),
     (r'^delete', 'delete'),
     (r'^toggle', 'toggle'),
     #(r'^disable_domain/?','scm.config.zone_views.disableDomain'),
     #(r'^enable_domain/?','scm.config.zone_views.enableDomain'),
 )

urlpatterns += patterns('scm.config.views.zone.zone_record_view',
     (r'record$', 'index'),
     (r'record/new', 'new'),
     (r'record/create', 'create'),
     (r'record/show', 'show'),
     (r'record/update', 'update'),
     (r'record/delete', 'delete'),
     (r'record/toggle', 'toggle'),
 )

urlpatterns += patterns('scm.config.views.zone.zone_file_view',
     (r'zone_file/new','new'),
     (r'zone_file/create','create'),
     (r'zone_file/export','export'),
 )



function showHint(message,redirect) {
	if (message == '') {
	  	return;
	}
    var hint = document.getElementById("hint");
    hint.innerHTML=message;
    hint.style.display="block";
    var w = window.screen.width;
    hint.style.right='0px';
    if($.browser.msie){
        hint.style.position='absolute';
        var y =document.documentElement.scrollTop;
        hint.style.top=y+'px';
    }else{
        hint.style.top='0px';
    }
	g_showhint_count = 0;
	g_showhint_count += 1;
	if (redirect=='') {
		setTimeout("hiddenHint('"+redirect+"')", 5000);
	}
	else {
		setTimeout("hiddenHint('"+redirect+"')", 1000);
	}
}

function hiddenHint(redirect) {
	g_showhint_count -= 1;
	if(g_showhint_count != 0) {
		return;
	}
    var hint = document.getElementById("hint");
    hint.innerHtml="";
    hint.style.display="none";
   if(redirect != ''){
   		window.location = redirect;
   }
}

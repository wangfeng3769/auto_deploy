﻿/**
 * AutoComplete Field - JavaScript Code
 *
 * This is a sample source code provided by fromvega.
 * Search for the complete article at http://www.fromvega.com
 *
 * Enjoy!
 *
 * @author fromvega
 *
 */

// global variables
var acZoneListTotal   =  0;
var acZoneListCurrent = -1;
var acZoneDelay		  = 300;
var acZoneURL		  = null;
var acZoneSearchId	  = null;
var acZoneResultsId	  = null;
var acZoneSearchField = null;
var acZoneResultsDiv  = null;
var acZoneName = null;
var acZoneRun = true;

function setAutoCompleteZoneRun(s) {
	acZoneRun = s;
}

function setAutoCompleteZone(field_id, results_id, zone){
	acZoneRun = true;
	// initialize vars
	acZoneSearchId  = "#" + field_id;
	acZoneResultsId = "#" + results_id;
	acZoneName = zone;
	
	// create the results div
	$("body").append('<div id="'+results_id+'" name="'+results_id+'" class="results"></div>');

	// register mostly used vars
	acZoneSearchField	= $(acZoneSearchId);
	acZoneResultsDiv	= $(acZoneResultsId);

	clearautoCompleteZone();
	// reposition div
	repositionResultsDivZone();
	{
		// frist time get josn
		var lastVal = acZoneSearchField.val();
		setTimeout(function () {autoCompleteZone(lastVal)}, acZoneDelay);
	}

	// on blur listener
	acZoneSearchField.blur(function(){ setTimeout("clearautoCompleteZone()", 200) });
	/*
	acZoneSearchField.click(function (e) {
		var lastVal = acZoneSearchField.val();
		// if is text, call with delay
		setTimeout(function () {autoComplete(lastVal)}, acZoneDelay);
	});
	*/
	// on key up listener
	acZoneSearchField.keyup(function (e) {
		if(acZoneRun) {
			// get keyCode (window.event is for IE)
			var keyCode = e.keyCode || window.event.keyCode;
			var lastVal = acZoneSearchField.val();

			// check an treat up and down arrows
			if(updownArrow(keyCode)){
				return;
			}

			// check for an ENTER or ESC
			if(keyCode == 13 || keyCode == 27){
				clearAutoComplete();
				return;
			}

			// if is text, call with delay
			setTimeout(function () {autoCompleteZone(lastVal)}, acZoneDelay);
		}
	});

}


// treat the auto-complete acZonetion (delayed function)
function autoCompleteZone(lastValue)
{
	// get the field value
	var part = acZoneSearchField.val().replace(/(^\s*)|(\s*$)/g, "");
	var fullzone = part;
	if(part.substring(part.length-1,part.length) == '.') {
		var newData = '<div class="selected">等同于:' + part +'</div>';
		fullzone = part;
	}
	else {
		var newData = '';
		if(part=='' || part=='@' || part.replace(/(^\s*)|(\s*$)/g, "")=='' ) {
			newData += '<div class="selected">等同于:'+acZoneName+'</div>';
			fullzone = acZoneName;
		}
		else {
			newData += '<div class="selected">等同于:' + part + '.'+acZoneName+'</div>';
			fullzone = part + '.'+acZoneName;
		}
	}
	// update the results div
	acZoneResultsDiv.html(newData);
	acZoneResultsDiv.css("display","block");
			
	// for all divs in results
	var divs = $(acZoneResultsId + " > div");

	// on click copy the result text to the search field and hide
	divs.click( function() {
		acZoneSearchField.val( fullzone );
		clearautoCompleteZone();
	});
}

// clear auto complete box
function clearautoCompleteZone()
{
	acZoneResultsDiv.html('');
	acZoneResultsDiv.css("display","none");
}

// reposition the results div acZonecordingly to the search field
function repositionResultsDivZone()
{
	// get the field position
	var sf_pos    = acZoneSearchField.offset();
	var sf_top    = sf_pos.top;
	var sf_left   = sf_pos.left;

	// get the field size
	var sf_height = acZoneSearchField.height();
	var sf_width  = acZoneSearchField.width();

	// apply the css styles - optimized for Firefox
	acZoneResultsDiv.css("position","absolute");
	acZoneResultsDiv.css("left", sf_left - 2);
	acZoneResultsDiv.css("top", sf_top + sf_height + 5);
	acZoneResultsDiv.css("width", sf_width - 2);
}


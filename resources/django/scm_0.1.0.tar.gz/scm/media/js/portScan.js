/********************************
 * 端口扫描程序
 * Author: qi.chen
 * Creation data: 2010-8-13
 * ******************************/
 
/********************************
 * 举例
	var callback = function (target, port, status) {
		alert(target+":"+port+" - "+status);
	};
	
	var portScan = function (form) {
		AttackAPI.PortScanner.scanTarget(callback, ip, port, timeout);
	};
  * ******************************/
  
var AttackAPI = {
    version: '0.1',
    author: 'Cage.C',
    homepage: 'http://www.webluker.com'};

AttackAPI.PortScanner = {};

AttackAPI.PortScanner.scanPort = function (callback, target, port, timeout) {
    var timeout = (timeout == null)?100:timeout;
    var img = new Image();
   
    img.onerror = function () {
        if (!img) return;
        img = undefined;
        callback(target, port, '开启');
    };
   
    img.onload = img.onerror;
    img.src = 'http://' + target + ':' + port;
   
    setTimeout(function () {
        if (!img) return;
        img = undefined;
        callback(target, port, '关闭');
    }, timeout);
};

AttackAPI.PortScanner.scanTarget = function (callback, target, ports, timeout)
{
    AttackAPI.PortScanner.scanPort(callback, target, ports, timeout);
};
/********************************
 * webluker自有的JS库
 * Author: shengli.zhang
 * Creation data: 2010-05-18
 * ******************************/

/********************************
 * 以下的search, onSuccess, onFail, fill, setSearch函数
 * 都是为了实现自动补全搜索框功能（类似与搜索引擎下拉框）。
 * 入口为search函数，参数为一个get请求的url。
 * 使用方法：
 *      1 html中放置一个带有keyup事件的文本框，如<input id="[text_id]" type="text" value="" onkeyup="search([url])"/>,
 *        其中[text_id]替换为自己需要的id，[url]需要替换为自己构建的get请求的url。
 *      2 input下方放置一个隐藏的层，如<div id="[div_id]" style="display:none"></div>，同样[div_id]需要替换。
 *      3 python后端代码需要有能够接受1中的url请求的views函数，假设函数名为fun。
 *      4 fun代码事例如下：
 *        def fun(request) {
 *           # 获得参数处理请求
 *           ....
 *
 *           # 以下为返回结果的关键代码。
 *           # [result]变量为后端的返回结果（一般为列表）
             import simplejson
             #注意dumps只接收字典类型，字段中的key不可修改，否则和js代码中的无法对应。
             #[result]为搜索结果，[text_id]为html也中文本框的id， [div_id]为html中对应文本框下方隐藏层的id
             return HttpResponse(simplejson.dumps({'result':[result],'text_id':[text_id],'div_id':[div_id]}))  
 *        }
 *
 * ******************************/
function search(url) { 
    var d = loadJSONDoc(url);
    d.addCallbacks(onSuccessBack, onFailBack);
}

onSuccessBack = function(data) {
	fill(data);
}

onFailBack = function(data){  
    showHint('服务端错误!','');
}

function fill(data) {
	var search_suggest = document.getElementById(data.div_id);
	search_suggest.innerHTML = "";
	search_suggest.style.display="none";
	var groups = data.result
    fun = "setSearch('" + data.text_id + "', '" + data.div_id + "', this.innerHTML)"
	//alert(groups);
	var len = groups.length;
	if (len > 0) {
		for(var i=0; i<len; i++) {
			var suggest = '<div onmouseover="javascript:suggestOver(this);" onmouseout="javascript:sugggestOut(this);" onclick="javascript:' + fun + '(this.innerHTML);" class="suggest_link">'
			//alert(suggest);
			suggest += groups[i] + '<div>';
			search_suggest.innerHTML += suggest;
		}
		search_suggest.style.display="block";
	}	
}

function setSearch(text_id, div_id, div_value)
{ 
   if(document.getElementById(text_id)!=null) {
       div_value = div_value.replace("<DIV></DIV>", "");
       div_value = div_value.replace("<div></div>", "");
       document.getElementById(text_id).value=div_value;
   }    
   document.getElementById(div_id).innerHTML="";
   document.getElementById(div_id).style.display="none";
}

/******* 以下是用户输入内容的安全性检查函数 *********/
/**** 是否为合法域名 ****/
function isDomain(domain) {
	var reg_domain = new RegExp('^[0-9a-zA-Z\-\.]{3,128}$');
    if ( ! reg_domain.exec(domain) ) {
        return false;
    }
	
	var strs = domain.split("."); 
	for (var i=0;i<strs.length ;i++ ) {   
        if (strs[i].length>63 || strs[i].length<1) {
			if(i==strs.length-1) {
				return true;
			}
			return false;
		}
    } 
	
	return true;
}


/**** 是否为合法IP地址 ****/
function isIP(value) {
	var reg_ip = new RegExp('^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$');
    if ( ! reg_ip.exec(value) ) {
        return false; 
    }
	
	var strs = value.split("."); 
	if( strs.length != 4) {
		return false; 
	}
	for (var i=0;i<strs.length ;i++ ) {   
        if (parseInt(strs[i])>255 || parseInt(strs[i])<0) {
			return false;
		}
    } 
	return true; 
}

/**** 是否为合法Email地址 ****/
function isEmail(value) {
    if(value.search(/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/) == -1)
        return false;
    else
        return true;
}

/**** 是否为合法的国内电话号码 ****/
function isTelphone(value) {
    if(value.search(/^\d{3}-\d{8}|\d{4}-\d{7}|\d{4}-\d{8}$/) == -1)
        return false;
    else
        return true;
}

/**** 是否为合法的国内邮政编码 ****/
function isZipcode(value) {
    if(value.search(/^[1-9]\d{5}$/) == -1)
        return false;
    else
        return true;
}

/**** 是否为合法的QQ号 ****/
function isQQ(value) {
    if(value.search(/^[1-9][0-9]{4,}$/) == -1)
        return false;
    else
        return true;
}

/**** 是否为数字串，length等于0不限制长度 ****/
function isNumber(value, length) {
    var regx;
    if(length==0)
        regx = new RegExp("^\\d*$");
    else
        regx = new RegExp("^\\d{" + length + "}$");
    if(value.search(regx) == -1)
        return false;
    else
        return true;
}

g_showhint_count=0;
/**** hint显示 ****/
function showHint(message,redirect) {
	if (message == '') {
	  	return;
	}
    var ie4 = document.all && navigator.userAgent.indexOf("Opera") == -1;
    var ns6 = document.getElementById && !document.all;
    var ns4 = document.layers;
    var isIE6 = (Prototype.Browser.IE && parseInt(navigator.appVersion) == 4 && navigator.userAgent.toLowerCase().indexOf('msie 6.') != -1);
    var hint = document.getElementById("hint");
    hint.innerHTML=message;
    hint.style.display="block";
    //hint.style.width="250px";
    //hint.style.height="100px";
    var w = window.screen.width;
    hint.style.right='0px';
    if(isIE6){
        hint.style.position='absolute';
        var y =document.documentElement.scrollTop;
        hint.style.top=y+'px';
    }else{
        hint.style.top='0px';
    }
	g_showhint_count += 1;
	if (redirect=='') {
		setTimeout("hiddenHint('"+redirect+"')", 5000);
	}
	else {
		setTimeout("hiddenHint('"+redirect+"')", 1000);
	}
}

/**** hint隐藏 ****/
function hiddenHint(redirect) {
	g_showhint_count -= 1;
	if(g_showhint_count != 0) {
		return;
	}
    var hint = document.getElementById("hint");
    hint.innerHtml="";
    hint.style.display="none";
   
   if(redirect != ''){
   		window.location = redirect;
   }
}

/***** 页面密码输入校验 *****/
function password_check(pwd1,pwd2,error_box) {
    var pwd1 = document.getElementById(pwd1).value;
    var wd2 = document.getElementById(pwd2).value;
    var error_box = document.getElementById(error_box);
    if (pwd1=="" || pwd2=="") {
        error_box.innerHTML = "<font color=red>密码不能为空！</font>";
        error_box.style.display = "block";
    }
    else if (pwd1 != pwd2) {
    		error_box.innerHTML = "<font color=red>两次输入的密码不同！</font>";
        error_box.style.display = "block";
    }else{
    	error_box.style.display = "none";
    }
}

function sendSimpleGet(uri) {
	var d = doSimpleXMLHttpRequest(uri);
	d.addCallbacks(showMessage, onFailBack);
}

function sendGet(uri,formObj) {
	var d = doSimpleXMLHttpRequest(uri,formObj);
	d.addCallbacks(showMessage, onFailBack);
}

function sendPost(uri,formObj) {
	var d = doPostXMLHttpRequest(uri,formObj);
	d.addCallbacks(showMessage, onFailBack);
}

function showMessage(data) {
	xmldoc = data.responseXML;
	var message = xmldoc.getElementsByTagName("message");
	var t = message[0].childNodes[0].nodeValue;
	t = t.replace(/\n/g,'<br>');
	var redirect = xmldoc.getElementsByTagName("redirect");
	var uri='';
	if(redirect[0].childNodes.length>0) {
		var uri = redirect[0].childNodes[0].nodeValue;
	}
	showHint(t,uri);
}

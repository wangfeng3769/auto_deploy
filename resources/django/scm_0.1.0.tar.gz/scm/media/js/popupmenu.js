var menuOffX = 0;
var menuOffY = 18;

var fo_shadows = new Array();
var linkset = new Array();

var ie4 = document.all && navigator.userAgent.indexOf("Opera") == -1;
var ns6 = document.getElementById && !document.all;
var ns4 = document.layers;

/**
 * e event
 * vmenu menu
 * mod on or off
 */
function showmenu(e, vmenu, mod){
  if(!(ie4 || ns4 || ns6)) {
    return;
  }
  var mcobj=document.getElementById(vmenu);
  if(mcobj){
       which=mcobj.innerHTML; 
  }
  //which = encodeHtmlTag(vmenu);
  clearhidemenu();
  ie_clearshadow();
  menuobj = ie4 ? document.all.popmenu : ns6 ? document.getElementById("popmenu") : ns4 ? document.popmenu : "";
  menuobj.thestyle = (ie4 || ns6) ? menuobj.style : menuobj;
  
  if(ie4 || ns6) {
    menuobj.innerHTML = which;
  }
  else {
    menuobj.document.write('<layer name="gui" bgColor="#E6E6E6" width="365" onmouseover="clearhidemenu()" onmouseout="hidemenu()">' + which + '</layer>');
    menuobj.document.close();
  }
  menuobj.contentwidth = (ie4 || ns6) ? menuobj.offsetWidth : menuobj.document.gui.document.width;
  menuobj.contentheight = (ie4 || ns6)? menuobj.offsetHeight : menuobj.document.gui.document.height;
  
  eventX = ie4 ? event.clientX : ns6 ? e.clientX : e.x;
  eventY = ie4 ? event.clientY : ns6 ? e.clientY : e.y;
  
  var rightedge = ie4 ? document.body.clientWidth - eventX : window.innerWidth - eventX;
  var bottomedge = ie4 ? document.body.clientHeight - eventY : window.innerHeight-eventY;
 
  if(rightedge < menuobj.contentwidth) {
    menuobj.thestyle.left = ie4 ? document.body.scrollLeft + eventX - menuobj.contentwidth + menuOffX : ns6? (window.pageXOffset + eventX - menuobj.contentwidth) + 'px' : eventX - menuobj.contentwidth;
  }
  else {
    menuobj.thestyle.left = ie4 ? ie_x(event.srcElement) + menuOffX : ns6 ? (window.pageXOffset + eventX) + 'px' : eventX;
  }
  if(bottomedge<menuobj.contentheight&&mod != 0) {
    menuobj.thestyle.top = ie4 ? document.body.scrollTop + eventY - menuobj.contentheight-event.offsetY + menuOffY - 23 : ns6 ? (window.pageYOffset + eventY - menuobj.contentheight-10) + 'px' : eventY-menuobj.contentheight;
  }
  else {
    menuobj.thestyle.top = ie4 ? ie_y(event.srcElement) + menuOffY : ns6 ? (window.pageYOffset + eventY + 10) + 'px' : eventY;
  }
  menuobj.thestyle.visibility = "visible";
  ie_dropshadow(menuobj, "#999999", 3);
  return false;
}

function ie_y(e) {  
  var t = e.offsetTop;  
  while(e = e.offsetParent) {  
    t += e.offsetTop;  
  }  
  return t;  
}  

function ie_x(e){  
  var l = e.offsetLeft;  
  while(e = e.offsetParent){  
    l += e.offsetLeft;  
  }  
  return l;  
}  

function ie_dropshadow(el, color, size) {
  var i;
  for (i = size; i > 0; i--) {
    var rect = document.createElement('div');
    var rs = rect.style;
    rs.position = 'absolute';
    rs.left = (el.style.posLeft + i) + 'px';
    rs.top = (el.style.posTop + i) + 'px';
    rs.width = el.offsetWidth + 'px';
    rs.height = el.offsetHeight + 'px';
    rs.zIndex = el.style.zIndex - i;
    rs.backgroundColor = color;
    var opacity = 1 - i / (i + 1);
    rs.filter = 'alpha(opacity=' + (100 * opacity) + ')';
    fo_shadows[fo_shadows.length] = rect;
  }
}

function ie_clearshadow() {
  for(var i = 0; i < fo_shadows.length; i++) {
    if (fo_shadows[i]) {
      fo_shadows[i].style.display = "none";
    }
  }
  fo_shadows = new Array();
}

function contains_ns6(a, b) {
  while(b.parentNode) {
    if((b = b.parentNode) == a) {
      return true;
    }
  }
  return false;
}

function hidemenu() {
  if(window.menuobj) {
    menuobj.thestyle.visibility = (ie4 || ns6) ? "hidden" : "hide";
  }
  ie_clearshadow();
}
function delayhidemenu() {
  if(ie4 || ns6 || ns4) {
    delayhide = setTimeout("hidemenu()", 5000);
  }
}
function clearhidemenu() {
  if(window.delayhide) {
    clearTimeout(delayhide);
  }
}
/*
function highlightmenu(e, state) {
  if(document.all) {
    source_el = event.srcElement;
  }
  else if(document.getElementById) {
    source_el = e.target;
  }
  if(source_el.className == "menuitems") {
    source_el.id = (state == "on") ? "mouseoverstyle" : "";
  }
  else {
    while(source_el.id != "popmenu") {
      source_el = document.getElementById ? source_el.parentNode : source_el.parentElement;
      if(source_el.className == "menuitems") {
        source_el.id = (state == "on") ? "mouseoverstyle" : "";
      }
    }
  }
}
*/
/*
if (ie4||ns6)
document.onclick=hidemenu
function doSClick() {
  var targetId, srcElement, targetElement, imageId, imageElement;
  srcElement = window.event.srcElement;
  targetId = srcElement.id + "content";
  targetElement = document.all(targetId);
  imageId = srcElement.id;
  imageId = imageId.charAt(0);
  imageElement = document.all(imageId);
  if (targetElement.style.display == "none") {
    imageElement.src = "Skins/Default/minus.gif"
    targetElement.style.display = "";
  } else {
    imageElement.src = "Skins/Default/plus.gif"
    targetElement.style.display = "none";
  }
}*//*
function doClick() {
  var targetId, srcElement, targetElement;
  srcElement = window.event.srcElement;
  targetId = srcElement.id + "_content";
  targetElement = document.all(targetId);
  if (targetElement.style.display == "none") {
    srcElement.src = "Skins/Default/minus.gif"
    targetElement.style.display = "";
  } else {
    srcElement.src = "Skins/Default/plus.gif"
    targetElement.style.display = "none";
  }
}
*/

function encodeHtmlTag(text) {
  return text.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/&lt;br\/&gt;/g , "<br/>");
}

function HTMLEncode(text) {
  return text.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#146;");
}

function bbimg(o){
  var zoom=parseInt(o.style.zoom, 10) || 100;
  zoom += event.wheelDelta / 12;
  if (zoom>0) o.style.zoom=zoom+'%';
  return false;
}

function leftMenuClick(obj) {

}

function JumpTo(uri) {
    self.location.href = uri;
}

//
String.prototype.trim = function() {
	return this.replace(/^\s*|\s*$/g,"");
};

Array.prototype.remove = function(n) {
	if (n < 0) {
		return this;
	} else {
		return this.slice(0, n).concat(this.slice(n + 1, this.length));
	}
};

var LUK = new Object();

LUK.cache = {
	index_pic: null,
	task_id_list: [],
	task_list_data: [],
	task_id:		0,
	ids:			'',
	host_id:		0,
	curr_period:	'',
	date_range:		'', //
	task_comp_sum:	0,
	task_list_page:	'', //
	page:			1,	//
	display_cache:	{},
	addTaskId: function(id) {
		this.task_id_list.push(id);
	},
	setCurrPeriod: function(period) {
		this.curr_period = period;
	},
	url_add_period: function(a) {
		a.href += (a.href.indexOf('?') == -1 ? '?' : '&') + 'period=' + this.curr_period + '&range=' + this.date_range;
	},
	curr_show: '',
	curr_taskObj_id: '' 
};

LUK.loader = {
	loading_str:	'正在加载...',
	showAjaxLoader: function() {
		//jQuery('#mskDiv').show();
		var scrollTop = document.body.scrollTop;
		var top = ((document.documentElement.clientHeight / 2 - 50) + scrollTop) + 'px';
		var left = (document.documentElement.clientWidth / 2 - 50) + 'px';
		jQuery('#mskLoader').css('top', top);
		jQuery('#mskLoader').css('left', left);
		jQuery('#mskLoader').show();
	},
	hideAjaxLoader: function()
	{
		//alert('hideAjaxLoader');
		//jQuery('#mskDiv').hide();
		jQuery('#mskLoader').hide();
	},
	switchTasksOptList: function()
	{
		var obj = document.__form.task_comp;
		var checked_sum = 0;
		if (obj.length)
		{
			for (var i = 0, length = obj.length; i < length; ++i)
			{
				if (obj[i].checked)
				{
					checked_sum++;
					jQuery('#__task_' + obj[i].value).css('backgroundColor', '#E4F3D6');
				}
				else
				{
					jQuery('#__task_' + obj[i].value).css('backgroundColor', '#fafafa');
				}
			}
		}
		else
		{
			if (obj.checked)
			{
				checked_sum++;
				jQuery('#__task_' + obj.value).css('backgroundColor', '#E4F3D6');
				jQuery('#__task_' + obj.value).css('backgroundColor', '#fafafa');
			}
		}
		if (checked_sum == 0)
		{
			jQuery('#__tasks_opt_list').fadeOut();
		}
		else
		{
			jQuery('#__tasks_opt_list').fadeIn();
		}
	},
	switchTaskListTab: function(tab, content)
	{
		jQuery('#' + LUK.cache.task_list_tab).removeClass();
		jQuery('#' + tab).addClass('selected');
		LUK.cache.task_list_tab = tab;
		LUK.cache.task_list_page = content;
		this.loadTaskListPage();
	},
	switchTaskListPage: function(page)
	{
		LUK.cache.page = page;
		this.loadTaskListPage();
	},
	// 加载项目列表页面
	loadTaskListPage: function() {
		//return;
		this.showAjaxLoader();
		ajax_url = getAjaxWrapper('get_task_list_page', { type: LUK.cache.task_list_type, 
														  owner: LUK.cache.task_list_owner, 
														  priority: LUK.cache.task_list_priority, 
														  class_id:LUK.cache.task_list_class_id, 
														  status:LUK.cache.task_list_status, 
														  temp: LUK.cache.task_list_page, 
														  page: LUK.cache.page});
		//alert(ajax_url);
		//载入远程 HTML 文件代码并插入至 DOM 中
		jQuery('#__div_task_list').load(getRandomUrl(ajax_url), function() {
			//alert('fuck');
			LUK.loader.hideAjaxLoader();
			
			var ids = jQuery('#__task_list').attr('data');
			LUK.cache.task_id_list = ids.split(',');
			switch (LUK.cache.task_list_page) {
				case 'task_list_main':
					LUK.loader.loadTaskListMainData(LUK.cache.curr_period);
					break;
				case 'task_list_avai':
					LUK.loader.loadTaskListAvailabilityData(LUK.cache.curr_period);
					breakgg
				case 'task_list_resptime':
					LUK.loader.loadTaskListRespTimeData(LUK.cache.curr_period);
					break;
				case 'task_list_resptime_isp':
					LUK.loader.loadTaskListRespTimeIspData(LUK.cache.curr_period);
					break;
			}
			
		});
	},
	loadTaskListData: function(period) {
		//alert(LUK.cache.task_list_page);
		this.switchDateRangeSelected(period);
		switch (LUK.cache.task_list_page) {
			case 'task_list_main':
				LUK.loader.loadTaskListMainData(period);
				break;
			case 'task_list_avai':
				LUK.loader.loadTaskListAvailabilityData(period);
				break;
			case 'task_list_resptime':
				LUK.loader.loadTaskListRespTimeData(period);
				break;
			case 'task_list_resptime_isp':
				LUK.loader.loadTaskListRespTimeIspData(period);
				break;
		}
	},
	// 日期范围的选择切换
	switchDateRangeSelected: function(period) {
		if (period != '') {
			jQuery.each(jQuery('#__daterange_control').children(), function(k, v) {
				jQuery(v).removeClass();
				if (jQuery(v).attr('id') == '__dr_' + period) {
					jQuery(v).addClass('selected');
				}
			});
		}
	},
	// 加载综合形式任务列表, 默认形式
	loadTaskListMainData: function(period) {
		//alert(period);
		this.hideDateSelecter();
		LUK.cache.setCurrPeriod(period);
		jQuery('#__period').html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		for (i = 0; i < LUK.cache.task_id_list.length; ++i) {
			var id = LUK.cache.task_id_list[i];
			jQuery('#__task_up_rate_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_resp_time_avg_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		}
		var key = LUK.cache.task_list_page + period + LUK.cache.date_range + LUK.cache.page;
		if (LUK.cache.task_list_data[key]) {
			//alert(0);
			//alert(key);
			// key = http://www.webluker.com/ajax_wrapper/?command=get_task_list_data&ids=&period=today&range=
			// value = {"period":"2010-04-04","date_start":"2010-04-04","date_end":"2010-04-04","task_data":[]}
			fillData(LUK.cache.task_list_data[key]['task_data']);
			fillPeriod(LUK.cache.task_list_data[key]['period']);
			return;
		}
		//alert(1);
		ajax_url = getAjaxWrapper('get_task_list_data', {ids:LUK.cache.task_id_list, period: period, range: LUK.cache.date_range});
		//alert(ajax_url);
		//通过 HTTP GET 请求载入 JSON 数据
		jQuery.getJSON(getRandomUrl(ajax_url), function(json) {
			// (可选) 载入成功时回调函数
			//alert('回调');
			fillData(json['task_data']);
			fillPeriod(json['period']);
			LUK.loader.setDateRange(json['date_start'], json['date_end']);
			LUK.cache.task_list_data[key] = json;
		});
		//填充时间选择区域	
		function fillPeriod(str){
			//alert(str);
			jQuery('#__period').html(str).removeClass().addClass('time_period');
		}
		//填充监控项目任务数据
		function fillData(json) {
			for (id in json) {
				jQuery('#__task_up_rate_' + id).html(json[id]['up_rate_str']);
				jQuery('#__task_up_rate_' + id).removeClass();
				jQuery('#__task_up_rate_' + id).addClass('up_rate_' + json[id]['up_rate_level']);
				jQuery('#__task_resp_time_avg_' + id).html(json[id]['resp_time_avg_str']);
				jQuery('#__task_resp_time_avg_' + id).removeClass();
				jQuery('#__task_resp_time_avg_' + id).addClass('resp_time_' + json[id]['resp_time_avg_level']);
			}
		}
	},
	// 加载可用率形式任务列表
	loadTaskListAvailabilityData: function(period)
	{
		this.hideDateSelecter();
		LUK.cache.setCurrPeriod(period);
		jQuery('#__period').html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		for (i = 0; i < LUK.cache.task_id_list.length; ++i)
		{
			var id = LUK.cache.task_id_list[i];
			jQuery('#__task_up_rate_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_fault_rate_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_fault_time_min_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_check_sum_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_fault_sum_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		}
		var key = LUK.cache.task_list_page + period + LUK.cache.date_range + LUK.cache.page;
		if (LUK.cache.task_list_data[key])
		{
			fillData(LUK.cache.task_list_data[key]['task_data']);
			fillPeriod(LUK.cache.task_list_data[key]['period']);
			return;
		}
		
		ajax_url = getAjaxWrapper('get_task_list_data', {ids:LUK.cache.task_id_list, period: period, range: LUK.cache.date_range});
		jQuery.getJSON(getRandomUrl(ajax_url), function(json)
		{
			fillData(json['task_data']);
			fillPeriod(json['period']);
			LUK.loader.setDateRange(json['date_start'], json['date_end']);
			LUK.cache.task_list_data[key] = json;
		});
		
		function fillPeriod(str)
		{
			jQuery('#__period').html(str).removeClass().addClass('time_period');
		}
		function fillData(json)
		{
			for (id in json)
			{
				jQuery('#__task_up_rate_' + id).html(json[id]['up_rate_str']).removeClass().addClass('up_rate_' + json[id]['up_rate_level']);
				jQuery('#__task_fault_rate_' + id).html(json[id]['fault_rate_str']).removeClass();
				jQuery('#__task_fault_time_min_' + id).html(json[id]['fault_time_min']).removeClass();
				jQuery('#__task_check_sum_' + id).html(json[id]['total_check_sum']).removeClass();
				jQuery('#__task_fault_sum_' + id).html(json[id]['total_fault_sum']).removeClass();
			}
		}
	},
	loadTaskListRespTimeData: function(period)
	{
		this.hideDateSelecter();
		LUK.cache.setCurrPeriod(period);
		jQuery('#__period').html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		for (i = 0; i < LUK.cache.task_id_list.length; ++i)
		{
			var id = LUK.cache.task_id_list[i];
			jQuery('#__task_resp_time_avg_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_resp_time_min_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_resp_time_max_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		}
		var key = LUK.cache.task_list_page + period + LUK.cache.date_range + LUK.cache.page;
		if (LUK.cache.task_list_data[key])
		{
			fillData(LUK.cache.task_list_data[key]['task_data']);
			fillPeriod(LUK.cache.task_list_data[key]['period']);
			return;
		}
		
		ajax_url = getAjaxWrapper('get_task_list_data', {ids:LUK.cache.task_id_list, period: period, range: LUK.cache.date_range});
		jQuery.getJSON(getRandomUrl(ajax_url), function(json)
		{
			fillData(json['task_data']);
			fillPeriod(json['period']);
			LUK.loader.setDateRange(json['date_start'], json['date_end']);
			LUK.cache.task_list_data[key] = json;
		});
		
		function fillPeriod(str)
		{
			jQuery('#__period').html(str).removeClass().addClass('time_period');
		}
		function fillData(json)
		{
			for (id in json)
			{
				jQuery('#__task_resp_time_avg_' + id).html(json[id]['resp_time_avg_str']).removeClass().addClass('resp_time_' + json[id]['resp_time_avg_level']);
				jQuery('#__task_resp_time_max_' + id).html(json[id]['resp_time_max_str']).removeClass().addClass('resp_time_' + json[id]['resp_time_max_level']);
				jQuery('#__task_resp_time_min_' + id).html(json[id]['resp_time_min_str']).removeClass().addClass('resp_time_' + json[id]['resp_time_min_level']);
			}
		}
	},
	loadTaskListRespTimeIspData: function(period)
	{
		this.hideDateSelecter();
		LUK.cache.setCurrPeriod(period);
		jQuery('#__period').html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		for (i = 0; i < LUK.cache.task_id_list.length; ++i)
		{
			var id = LUK.cache.task_id_list[i];
			jQuery('#__task_resp_time_avg_telcom_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
			jQuery('#__task_resp_time_avg_cnc_' + id).html(LUK.loader.loading_str).removeClass().addClass('task_data_loading');
		}
		var key = LUK.cache.task_list_page + period + LUK.cache.date_range + LUK.cache.page;
		if (LUK.cache.task_list_data[key])
		{
			fillData(LUK.cache.task_list_data[key]['task_data']);
			fillPeriod(LUK.cache.task_list_data[key]['period']);
			return;
		}
		
		ajax_url = getAjaxWrapper('get_task_list_isp_data', {ids:LUK.cache.task_id_list, period: period, range: LUK.cache.date_range});
		jQuery.getJSON(getRandomUrl(ajax_url), function(json)
		{
			fillData(json['task_data']);
			fillPeriod(json['period']);
			LUK.loader.setDateRange(json['date_start'], json['date_end']);
			LUK.cache.task_list_data[key] = json;
		});
		
		function fillPeriod(str)
		{
			jQuery('#__period').html(str).removeClass().addClass('time_period');
		}
		function fillData(json)
		{
			for (id in json)
			{
				jQuery('#__task_resp_time_avg_telcom_' + id).html(json[id]['resp_time_avg_telcom_str']).removeClass().addClass('resp_time_' + json[id]['resp_time_avg_telcom_level']);
				jQuery('#__task_resp_time_avg_cnc_' + id).html(json[id]['resp_time_avg_cnc_str']).removeClass().addClass('resp_time_' + json[id]['resp_time_avg_cnc_level']);
			}
		}
	},
	loadTaskReportSummary: function(period)
	{
		url = '/task/' + LUK.cache.task_id + '/report/summary?period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadTaskReportAvaillability: function(period)
	{
		url = '/task_report_availability/?task_id=' + LUK.cache.task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadTaskReportResptimeLevel: function(period)
	{
		url = '/task_report_resptime_level/?task_id=' + LUK.cache.task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadTaskReportFaultCount: function(period)
	{
		url = '/task_report_fault/?task_id=' + LUK.cache.task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadTaskReportResptimeIsp: function(period)
	{
		url = '/task_report_resptime_isp/?task_id=' + LUK.cache.task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadTaskComp: function(period)
	{
		url = '/task_comp/?ids=' + LUK.cache.ids + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostReportProvince: function(period)
	{
		url = '/exp_host_report_province/?host_id=' + LUK.cache.host_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostReportIsp: function(period)
	{
		url = '/exp_host_report_isp/?host_id=' + LUK.cache.host_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostReportCity: function(period)
	{
		url = '/exp_host_report_city/?host_id=' + LUK.cache.host_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostListAvg: function(period)
	{
		url = '/exp_host_list_avg/?period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostListProvince: function(period)
	{
		url = '/exp_host_list_province/?period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostListCity: function(period)
	{
		url = '/exp_host_list_city/?period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadHostListIsp: function(period)
	{
		url = '/exp_host_list_isp/?period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerNetIO: function(period)
	{
		url = '/server_task_report_detail_netio/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range + '&unit=' + LUK.cache.unit;
		window.location = url;
	},
	loadServerNetIOPkt: function(period)
	{
		url = '/server_task_report_detail_netiopkt/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerDiskIO: function(period)
	{
		url = '/server_task_report_detail_diskio/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerDiskIOSum: function(period)
	{
		url = '/server_task_report_detail_diskiosum/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerLoad: function(period)
	{
		url = '/server_task_report_detail_load/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerMem: function(period)
	{
		url = '/server_task_report_detail_mem/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerMemWindows: function(period)
	{
		url = '/server_task_report_detail_mem_windows/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerCPU: function(period)
	{
		url = '/server_task_report_detail_cpu/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerCPUWindows: function(period)
	{
		url = '/server_task_report_detail_cpu_windows/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerProcsum: function(period)
	{
		url = '/server_task_report_detail_procsum/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServerDiskStore: function(period)
	{
		url = '/server_task_report_detail_diskstore/?task_id=' + LUK.cache.server_task_id + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	loadServiceTask: function(period)
	{
		url = '/service_task_report_summary/?task_id=' + LUK.cache.service_task_id + '&period=' + period + '&range=' + LUK.cache.date_range + '&mode=' + LUK.cache.service_task_mode;
		window.location = url;
	},
	loadAnalyseOverlay: function(period)
	{
		url = '/analyse_overlay/?overlay=' + LUK.cache.task_overlay + '&period=' + period + '&range=' + LUK.cache.date_range;
		window.location = url;
	},
	showDateSelecter: function()
	{
		jQuery('#date_selecter').fadeIn();
	},
	hideDateSelecter: function()
	{
		jQuery('#date_selecter').fadeOut();
	},
	submitDateRange: function(range)
	{
		tmp = range.split('|');
		LUK.loader.setDateRange(tmp[0], tmp[1]);
	},
	setDateRange: function(start, end)
	{
		jQuery('#__date_start').val(start);
		jQuery('#__date_end').val(end);
		LUK.cache.date_range = start + ',' + end;
	},
	switchDateTimeSelecter: function()
	{
		if (!datatime_display)
		{
			jQuery('#datetime_range').fadeIn();
		}
		else
		{
			jQuery('#datetime_range').fadeOut();
		}
		datatime_display = !datatime_display;
		return false;
	},
	submitDateTimeRange: function(start_id, end_id)
	{
		var datetime_s = document.getElementById(start_id).value;
		var datetime_e = document.getElementById(end_id).value;
		if (datetime_s == '' || datetime_e == '')
		{
			showSuccMsg('??????????????????', '', '', {});
			return;
		}
		var url = window.location.href;
		if (url.indexOf('range=') != -1)
		{
			url = url.replace(/range=[ %:0-9a-z\,\-]*/g, 'range=' + datetime_s + ',' + datetime_e);
		}
		else
		{
			if (url.indexOf('?') != -1)
			{
				url = url + "&";
			}
			else
			{
				url = url + "?";
			}
			url = url + 'range=' + datetime_s + ',' + datetime_e;
		}
		// ???????????????????????????? {p1:v1,p2:v2} ??????????4
		if (arguments.length==3)
		{
			var args_reset = arguments[2];
			for (key in args_reset)
			{
				if (url.indexOf(key+'=') != -1)
				{
					var patt=new RegExp(key+'=[^&]*', 'g');
					url = url.replace(patt, key + '=' + args_reset[key]);
				}
			}
		}
		submitLoading('btn_submit', 'loading_submit');
		window.location = url;
	},
	onChangeDateRange: function(period)
	{
		if (period == 'custom')
		{
			if (LUK.cache.date_range == '')
			{
				var start = jQuery('#__date_start').val();
				var end = jQuery('#__date_end').val();
				LUK.cache.date_range = start + ',' + end;
			}
		}
		var url = window.location.href;
		if (url.indexOf('period=') != -1)
		{
			url = url.replace(/period=[0-9a-z]+/g, 'period=' + period);
			url = url.replace(/range=[0-9a-z\,\-]*/g, 'range=' + LUK.cache.date_range);
		}
		else
		{
			if (url.indexOf('?') != -1)
			{
				url = url + "&";
			}
			else
			{
				url = url + "?";
			}
			url = url + "period=" + period + "&range=" + LUK.cache.date_range;
		}
		window.location = url;
	},
	onChangeTask: function(elem)
	{
		var task_id = elem.options[elem.selectedIndex].value;
		var task_type = elem.options[elem.selectedIndex].getAttribute('type');
		var url = window.location.href;
		if (url.search(/task\/[a-z]+\/[0-9]+/g) != -1)
		{
			url = url.replace(/task\/[a-z]+\/[0-9]+/g, 'task/' + task_type + '/' + task_id);
		}
		window.location = url;
	},
	onChangeExpHost: function(elem)
	{
		value = elem.options[elem.selectedIndex].value;
		var url = window.location.href;
		if (url.indexOf('host_id=') != -1)
		{
			url = url.replace(/host_id=[0-9]+/g, 'host_id=' + value);
		}
		window.location = url;
	},
	onChangeServer: function(elem)
	{
		var value = elem.options[elem.selectedIndex].value;
		var url = '/server/' + value;
		window.location = url;
	},
	onChangeServiceTask: function(elem)
	{
		var task_id = elem.options[elem.selectedIndex].value;
		var task_type = elem.options[elem.selectedIndex].getAttribute('type');
		var url = window.location.href;
		if (url.search(/task\/[a-z]+\/[0-9]+/g) != -1)
		{
			url = url.replace(/task\/[a-z]+\/[0-9]+/g, 'task/' + task_type + '/' + task_id);
		}
		window.location = url;
	},
	onChangeSTaskThres: function(elem)
	{
		var value = elem.options[elem.selectedIndex].value;
		var task_type = elem.options[elem.selectedIndex].getAttribute('type');
		var url = '/task/' + task_type + '/' + value + '/alert/threshold/settings';
		window.location = url;
	},
	onChangeHost: function(elem)
	{
		var value = elem.options[elem.selectedIndex].value;
		var url = window.location.href;
		if (url.indexOf('/host/') != -1)
		{
			url = url.replace(/\/host\/[0-9\.]+/g, '/host/' + value);
		}
		window.location = url;
	},
	onChangeDomain: function(elem)
	{
		var value = elem.options[elem.selectedIndex].value;
		var url = window.location.href;
		if (url.indexOf('/domain/') != -1)
		{
			url = url.replace(/\/domain\/[0-9a-z\-]+\.[0-9a-z\.\-]+/g, '/domain/' + value);
		}
		window.location = url;
	},
	onChangeSNMP: function(show, hidden)
	{
		jQuery('#' + show).fadeIn();
		jQuery('#' + hidden).fadeOut();
	},
	onClickIndexPic: function(id)
	{
		if (pictimer)
			clearInterval(pictimer);
		return this.onChangeIndexPic(id);
	},
	onChangeIndexPic: function(id)
	{
		curr_id = LUK.cache.index_pic;
		$('#__pic_' + curr_id).fadeOut('slow');
		$('#__item_' + curr_id).fadeOut('slow', function(){
			LUK.cache.index_pic = id;
			$('#__click_' + curr_id).removeClass();
			$('#__click_' + id).addClass('selected');
			$('#__item_' + curr_id).hide();
			$('#__item_' + id).fadeIn('slow');
			$('#__pic_' + id).fadeIn('slow');}
		);
		return false;
	},
	startTaskComp: function(obj)
	{
		var err = '???????????????2????????????б??';
		if (!obj)
		{
			alert(err);
			return;
		}
		var ids = '';
		var idcount = 0;
		if (obj.length)
		{
			for (var i = 0, length = obj.length; i < length; ++i)
			{
				if (obj[i].checked)
				{
					ids += obj[i].value + ',';
					idcount++;
				}
			}
			if (idcount < 2)
			{
				alert(err);
				return;
			}
			if (idcount > 5)
			{
				alert('?????????????????5????????????б??');
				return;
			}
			window.location = '/task_comp/?ids=' + ids;
		}
		else
		{
			alert(err);
			return;
		}
	},
	taskCompDelTask: function(id)
	{
		if (LUK.cache.task_comp_sum <= 1)
		{
			alert('???????????????????????????????????');
			return;
		}
		var url = window.location.href;
		url = url.replace(id + ",", '');
		window.location = url;
	},
	taskCompTasks: function()
	{
		jQuery('#__task_comp_new').html('<img src="/site_media/pic/seeM/gajax_loader2.gif" />');
		ajax_url = getAjaxWrapper('get_task_comp_list', {ids: LUK.cache.ids});
		jQuery('#__task_comp_new').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__task_comp_new').fadeIn();
		});
	},
	startTaskCompNew: function(obj)
	{
		var err = '?????????1???μ??????????????';
		if (!obj)
		{
			alert(err);
			return;
		}
		var ids = '';
		var idcount = 0;
		if (obj.length)
		{
			for (var i = 0, length = obj.length; i < length; ++i)
			{
				if (obj[i].checked)
				{
					ids += obj[i].value + ',';
					idcount++;
				}
			}	
		}
		else
		{
			if (!obj.checked)
			{
				alert(err);
				return;
			}
			ids += obj.value + ',';
			idcount++;
		}
		if (idcount + LUK.cache.task_comp_sum > 5)
		{
			alert('?????????????????5????????????б??');
			return;
		}		
		window.location = 'task_comp/?ids=' + LUK.cache.ids + ids;
	},
	hideTaskCompTasks: function()
	{
		jQuery('#__task_comp_new').fadeOut();
	},
	onSelectTaskHttpMethod: function(method)
	{
		if (method == '0')
		{
			jQuery('#__ctrl_param').fadeOut();
			jQuery('#__ctrl_pattern_str').fadeIn();
			jQuery('#__ctrl_pattern_type').fadeIn();
		}
		if (method == '1')
		{
			jQuery('#__ctrl_param').fadeIn();
			jQuery('#__ctrl_pattern_str').fadeIn();
			jQuery('#__ctrl_pattern_type').fadeIn();
		}
		if (method == '2')
		{
			jQuery('#__ctrl_param').fadeOut();
			jQuery('#__ctrl_pattern_str').fadeOut();
			jQuery('#__ctrl_pattern_type').fadeOut();
		}
	},
	onSelectTaskFtpAnon: function(method)
	{
		if (method == '0')
		{
			jQuery('#__ctrl_ftp_user').fadeIn();
			jQuery('#__ctrl_ftp_pwd').fadeIn();
		}
		if (method == '1')
		{
			jQuery('#__ctrl_ftp_user').fadeOut();
			jQuery('#__ctrl_ftp_pwd').fadeOut();
		}
	},
	loadSummaryView: function()
	{
		LUK.loader.showAjaxLoader();
		ajax_url = getAjaxWrapper('get_summary_view', {});
		//alert(ajax_url);
		jQuery('#__summary_frame').load(getRandomUrl(ajax_url), function()
		{
			//$('#__test').tooltip({delay: 0});
			LUK.loader.hideAjaxLoader();
			LUK.loader.reloadSummaryView();
		});
	},
	reloadSummaryView: function()
	{
		var t = 30;
		jQuery('#__reload').html(t + ' 秒后自动更新')
		var timer = setInterval(function(){
			if (t-- == 1)
			{
				jQuery('#__reload').html('正在自动更新')
				clearInterval(timer);
				LUK.loader.loadSummaryView();
			}
			else
			{
				jQuery('#__reload').html(t + ' 秒后自动更新')
			}
		}, 1000);
	},
	showTaskPriority: function(container, pri, task_id)
	{
		var priority = pri / 1;
		var html = '';
		for (var i = 0; i < 5; ++i)
		{
			var img = '';
			if (i < priority)
				img = 'favorite.gif';
			else
				img = 'star.gif';
			html += '<a href="" onclick="LUK.loader.modifyTaskPriority(\'' + container + '\', ' + (i + 1) + ', ' + task_id + ');return false;"><img src="/site_media/pic/seeM/' + img + '" /></a>';
		}
		jQuery('#' + container).html(html);
	},
	modifyTaskPriority: function(container, pri, task_id)
	{
		jQuery('#' + container).html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
		jQuery.post(getAjaxWrapper('modify_task_priority'), {task_id:task_id, pri:pri}, function()
		{
			LUK.cache.task_list_data = [];
			LUK.loader.showTaskPriority(container, pri, task_id);
		});
	},
	showPriority: function(container, pri)
	{
		var priority = pri / 1;
		var html = '';
		for (var i = 0; i < 5; ++i)
		{
			var img = '';
			if (i < priority)
				img = 'favorite.gif';
			else
				img = 'star.gif';
			html += '<img src="/site_media/pic/seeM/g' + img + '" />';
		}
		jQuery('#' + container).html(html);
	},
	loadThresholdNew: function(task_type, task_id, th_id, task_sort)
	{
		jQuery('#__threshold_new').html('<img src="/site_media/pic/seeM/gajax_loader2.gif" />');
		jQuery('#__threshold_new').show();
		var ajax_url = getAjaxWrapper('task_threshold_new', {task_type:task_type, task_id:task_id, th_id:th_id, task_sort:task_sort});
		//alert(ajax_url);
		jQuery('#__threshold_new').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__threshold_new').fadeIn();
		});
	},
	hideThCreator: function()
	{
		jQuery('#__threshold_new').fadeOut();
	},
	initThDefine: function()
	{
		eval("LUK.cache.th_define=" + LUK.cache.th_define);
		eval("LUK.cache.th_metric=" + LUK.cache.th_metric);
		eval("LUK.cache.th_cond=" + LUK.cache.th_cond);
		eval("LUK.cache.th_comp=" + LUK.cache.th_comp);
		eval("LUK.cache.th_unit=" + LUK.cache.th_unit);
	},
	loadThMetricSelect: function()
	{
		this.initThDefine();
		for (var metric in LUK.cache.th_define)
		{
			jQuery("<option value='" + metric + "'>" + LUK.cache.th_metric[metric] + "</option>").appendTo("#__th_metric_sel");
		}
		this.loadThCondSelect();
	},
	loadThCondSelect: function()
	{
		var metric = jQuery("#__th_metric_sel").val();
		var metric_info = LUK.cache.th_define[metric];
		jQuery("#__th_cond_sel").empty();
		for (var cond in metric_info)
		{
			jQuery("<option value='" + cond + "'>" + LUK.cache.th_cond[cond] + "</option>").appendTo("#__th_cond_sel");
		}
		this.loadThMetricCondSchema();
	},
	loadThMetricCondSchema: function()
	{
		var metric = jQuery("#__th_metric_sel").val();
		var cond = jQuery("#__th_cond_sel").val();
		var metric_info = LUK.cache.th_define[metric];
		var cond_info = metric_info[cond];
		if (cond_info['unit'])
		{
			var count = cond_info['unit'].length;
			if (count > 1)
			{
				jQuery("#__th_unit_sel").empty();
				for (var i = 0; i < count; ++i)
				{
					jQuery("<option value='" + cond_info['unit'][i] + "'>" + LUK.cache.th_unit[cond_info['unit'][i]][0] + "</option>").appendTo("#__th_unit_sel");
				}
				jQuery("#__th_unit_sel").show();
				jQuery("#__th_unit").hide();
			}
			else
			{
				jQuery("#__th_unit").html(LUK.cache.th_unit[cond_info['unit'][0]][0])
				jQuery("#__th_unit_sel").hide();
				jQuery("#__th_unit").show();
				jQuery("<option value='" + cond_info['unit'][0] + "'>" + LUK.cache.th_unit[cond_info['unit'][0]][0] + "</option>").appendTo("#__th_unit_sel");
				jQuery("#__th_unit_sel").val(cond_info['unit'][0]);
			}
		}
		else
		{
			jQuery("#__th_unit_sel").hide();
			jQuery("#__th_unit").hide();
		}
		
		if (cond_info['comp'])
		{
			var count = cond_info['comp'].length;
			jQuery("#__th_comp_sel").empty();
			for (var i = 0; i < count; ++i)
			{
				jQuery("<option value='" + cond_info['comp'][i] + "' title='" + LUK.cache.th_comp[cond_info['comp'][i]] + "'>" + LUK.cache.th_comp[cond_info['comp'][i]] + "</option>").appendTo("#__th_comp_sel");
			}
			jQuery("#__th_comp").show();
		}
		else
		{
			jQuery("#__th_comp").hide();
		}
		
		if (cond_info['max'])
		{
			var count = cond_info['max'];
			jQuery("#__th_max_sel").empty();
			for (var i = 1; i <= count; ++i)
			{
				jQuery("<option value='" + i + "'>" + i + "</option>").appendTo("#__th_max_sel");
			}
			jQuery("#__th_max").show();
		}
		else
		{
			jQuery("#__th_max").hide();
		}
		
		if (cond_info['dev_title'])
		{
			jQuery('#__th_dev_title').html(cond_info['dev_title']);
			jQuery("#__th_dev").show();
		}
		else
		{
			jQuery("#__th_dev").hide();
		}
		if (cond_info['dev'])
		{
			jQuery("#__th_dev_sel").empty();
			for (var devid in cond_info['dev'])
			{
				jQuery("<option value='" + devid + "'>" + cond_info['dev'][devid] + "</option>").appendTo("#__th_dev_sel");
			}
		}
	},
	showNewMsgSum: function()
	{
		var ajax_url = getAjaxWrapper('get_new_msg_sum', {});
		jQuery.getJSON(getRandomUrl(ajax_url), function(json)
		{
			var msg_sum = json['msg_sum'] / 1;
			if (msg_sum != 0)
			{
				jQuery('#__msg_newsum').html(msg_sum);
				LUK.loader.showAlertLayer();
			}
			else
			{
				LUK.loader.hideAlertLayer();
			}
		});
	},
	showAlertLayer: function()
	{
		var scrollTop = document.body.scrollTop;
		if (scrollTop == 0)
			scrollTop = document.documentElement.scrollTop;
		var top = (document.documentElement.clientHeight - 100 + scrollTop) + 'px';
		var clientWidth = document.documentElement.clientWidth;
		var pageWidth = 980;
		var left = (clientWidth - (clientWidth - 980) / 2 - 150) + 'px';
		jQuery('#msgAlert').css('top', top);
		jQuery('#msgAlert').css('left', left);
		jQuery('#msgAlert').fadeIn('slow');
		$(window).scroll(function(){
			var scrollTop = document.body.scrollTop;
			if (scrollTop == 0)
				scrollTop = document.documentElement.scrollTop;
			var top = (document.documentElement.clientHeight - 100 + scrollTop) + 'px';
			var clientWidth = document.documentElement.clientWidth;
			var pageWidth = 980;
			var left = (clientWidth - (clientWidth - 980) / 2 - 150) + 'px';
			jQuery('#msgAlert').css('top', top);
			jQuery('#msgAlert').css('left', left);
		});
	},
	hideAlertLayer: function()
	{
		jQuery('#msgAlert').fadeOut();
	},
	loadMsgStatusFilter: function(status)
	{
		this.showAjaxLoader();
		window.location = '/alert/message?status=' + status + '&range=' + LUK.cache.dt_range;
		return false;
	},
	loadAlertTypeFilter: function(type)
	{
		this.showAjaxLoader();
		window.location = '/alert/history?type=' + type + '&range=' + LUK.cache.dt_range;
		return false;
	},
	loadThStatusFilter: function(status)
	{
		this.showAjaxLoader();
		window.location = '/seeM/alert/threshold/list/?status=' + status;
		return false;
	},
	showNetIODevInfo: function(elem)
	{
		if (jQuery('#' + elem).css('display') == 'none')
		{
			jQuery('#' + elem).fadeIn();
		}
		else
		{
			jQuery('#' + elem).fadeOut();
		}
	},
	showHelper: function(elem)
	{
		if (jQuery('#' + elem).css('display') == 'none')
		{
			jQuery('#' + elem).fadeIn();
		}
		else
		{
			jQuery('#' + elem).fadeOut();
		}
	},
	showSubMenu: function(elem)
	{
		if (jQuery('#' + elem).css('display') == 'none')
		{
			jQuery('#' + elem).show('fast');
			if (elem == '__submenu_list_class')
			{
				LUK.loader.loadTaskClassList();
			}
		}
		else
		{
			jQuery('#' + elem).hide('fast');
		}
		return false;
	},
	loadTaskClassList: function(class_id)
	{
		jQuery('#__class_list').html('<div class="menu_title_task2"><img src="/site_media/pic/seeM/gajax_loader4.gif" /></div>');
		var ajax_url = getAjaxWrapper('get_task_class_list', {class_id:class_id});
		jQuery('#__class_list').load(getRandomUrl(ajax_url), function()
		{
			
		});
		return true;
	},
	delTaskClass: function(class_id)
	{
		if (!confirm('???????????????????\r\n\r\n???????????????????е?????????'))
		{
			return false;
		}
		__hidden_call.window.location = '/dispose/?__action=task_class_del&class_id=' + class_id;
		return true;
	},
	showTaskClassSel: function(tmp)
	{
		LUK.loader.hideShareUserSel();
		jQuery('#__task_class_sel').html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
		var ajax_url = getAjaxWrapper('get_task_class_sel', {tmp:tmp});
		jQuery('#__task_class_sel').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__task_class_sel').fadeIn();
		});
		return true;
	},
	hideTaskClassSel: function()
	{
		jQuery('#__task_class_sel').fadeOut();
	},
	addMultiTaskClass: function()
	{
		var elem = document.__form.task_class_sel;
		var class_id = elem.options[elem.selectedIndex].value;
		var ids  = LUK.loader.getCheckedTasks();
		if (ids == '')
		{
			return;
		}
		jQuery('#__task_class_sel').html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
		jQuery.post(getAjaxWrapper('add_multi_task_to_class'), {ids:ids, class_id:class_id}, function()
		{
			jQuery('#__task_class_sel').html('');
			showSuccMsg('????????????????????????飡', '', '', {});
		});
	},
	showShareUserSel: function()
	{
		LUK.loader.hideTaskClassSel();
		jQuery('#__share_user_sel').html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
		var ajax_url = getAjaxWrapper('get_share_user_sel', {});
		jQuery('#__share_user_sel').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__share_user_sel').fadeIn();
		});
		return true;
	},
	hideShareUserSel: function()
	{
		jQuery('#__share_user_sel').fadeOut();
	},
	addMultiTaskShareUser: function()
	{
		var elem = document.__form.share_user_sel;
		var user_id = elem.options[elem.selectedIndex].value;
		var ids  = LUK.loader.getCheckedTasks();
		if (ids == '')
		{
			return;
		}
		jQuery('#__share_user_sel').html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
		jQuery.post(getAjaxWrapper('add_multi_task_share_user'), {ids:ids, user_id:user_id}, function()
		{
			jQuery('#__share_user_sel').html('');
			showSuccMsg('??????????????????????? <em>' + elem.options[elem.selectedIndex].getAttribute('data') + '</em>', '', '', {});
		});
	},
	addTaskClass: function(task_id, class_id)
	{
		jQuery('#__task_class_sel').html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
		jQuery.post(getAjaxWrapper('add_task_to_class'), {task_id:task_id, class_id:class_id}, function()
		{
			jQuery('#__task_class_sel').html('');
			showSuccMsg('???????????飡???????????4???????????', '', '', {});
			LUK.loader.closeAllDropMenu();
		});
	},
	getCheckedTasks: function()
	{
		var err = '???????????????1?????????';
		var obj = document.__form.task_comp;
		if (!obj)
		{
			alert(err);
			return '';
		}
		var ids = '';
		var idcount = 0;
		if (obj.length)
		{
			for (var i = 0, length = obj.length; i < length; ++i)
			{
				if (obj[i].checked)
				{
					ids += obj[i].value + ',';
					idcount++;
				}
			}
			if (idcount < 1)
			{
				alert(err);
				return '';
			}
		}
		else
		{
			ids += obj.value + ',';
		}
		return ids;
	},
	showTaskMediumBindIcon: function(medium, stat, task_id)
	{
		if (stat == '1')
		{
			jQuery('#__' + medium + '_' + task_id).html('<a href="" onclick="return LUK.loader.changeTaskMediumSettings(\'' + medium + '\', \'' + task_id + '\');" title="禁用通知"><img src="/site_media/pic/seeM/gtick.png" /></a>');
		}
		else
		{
			jQuery('#__' + medium + '_' + task_id).html('<a href="" onclick="return LUK.loader.changeTaskMediumSettings(\'' + medium + '\', \'' + task_id + '\');" title="开通通知"><img src="/site_media/pic/seeM/gtick_disable.gif" /></a>');
		}
	},
	changeTaskMediumSettings: function(medium, task_id)
	{
		jQuery('#__' + medium + '_' + task_id).html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('task_medium_settings', {task_id:task_id,medium:medium});
		alert(ajax_url);
		jQuery.getJSON(getRandomUrl(ajax_url), function(json)
		{
			stat = json['stat'];
			LUK.loader.showTaskMediumBindIcon(medium, stat, task_id);
		});
		return false;
	},
	showMediumBindIcon: function(medium, stat)
	{
		if (stat == '1')
		{
			jQuery('#__' + medium).html('<a href="" onclick="return LUK.loader.changeMediumSettings(\'' + medium + '\');" title="禁用通知"><img src="/site_media/pic/seeM/gtick.png" /></a>');
		}
		else
		{
			jQuery('#__' + medium).html('<a href="" onclick="return LUK.loader.changeMediumSettings(\'' + medium + '\');" title="开通通知"><img src="/site_media/pic/seeM/gtick_disable.gif" /></a>');
		}
	},
	changeMediumSettings: function(medium)
	{
		jQuery('#__' + medium).html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('medium_settings', {medium:medium});
		alert(ajax_url);
		jQuery.getJSON(getRandomUrl(ajax_url), function(json)
		{
			stat = json['stat'];
			LUK.loader.showMediumBindIcon(medium, stat);
		});
		return false;
	},
	loadServerTaskLastMsgs: function(task_id)
	{
		ajax_url = getAjaxWrapper('get_server_task_last_msg', {task_id:task_id});
		jQuery('#__alert_msg').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadServerLastMsgs: function(server_id)
	{
		ajax_url = getAjaxWrapper('get_server_task_last_msg', {server_id:server_id});
		jQuery('#__alert_msg').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	showProgress: function(width, percent)
	{
		var pb_dis = width / 2 - 18;
		var pb_used = width * percent / 100;
		var pb_empty = width - pb_used;
		var html = '<div class="pb_box"><p class="left"></p><p class="green" style="width:' + pb_used + 'px;"></p><p class="empty" style="width:' + pb_empty + 'px;"></p><p class="right"></p><div class="dis" style="left:' + pb_dis + 'px">' + percent + '%</div></div>';
		document.write(html);
	},
	hideTask: function(task_id)
	{
		jQuery('#__task_' + task_id).fadeOut('slow');
		jQuery('#__task_' + task_id + '_extend').fadeOut('slow');
	},
	setMetricSelectorTab: function(tab)
	{
		if (LUK.cache.curr_metric_tab)
		{
			jQuery('#' + LUK.cache.curr_metric_tab).removeClass();
		}
		jQuery('#' + tab).addClass('selected');
		LUK.cache.curr_metric_tab = tab;
	},
	loadMetricSelector: function(elem)
	{
		LUK.cache.curr_overlay_container = elem;
		jQuery('#metric_selector').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_selector', {});
		jQuery('#metric_selector').load(getRandomUrl(ajax_url), function()
		{
			LUK.loader.loadMetricSiteTask('__metric_tab_site');
		});
	},
	loadMetricSiteTask: function(tab)
	{
		LUK.loader.setMetricSelectorTab(tab);
		jQuery('#metric_task_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_site_task', {});
		jQuery('#metric_task_list').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadMetricSiteTaskMetric: function(task_type, task_id, task_name)
	{
		LUK.cache.metric_task_name = task_name;
		jQuery('#__task_' + task_id + '_metric_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_site_task_metric', {task_type:task_type, task_id:task_id});
		jQuery('#__task_' + task_id + '_metric_list').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__task_' + task_id + '_metric_list').fadeIn();
		});
	},
	loadMetricServer: function(tab)
	{
		LUK.loader.setMetricSelectorTab(tab);
		jQuery('#metric_task_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_server', {});
		jQuery('#metric_task_list').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadMetricServerTask: function(server_id, server_name)
	{
		LUK.cache.metric_task_name = server_name;
		jQuery('#metric_task_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_server_task', {server_id:server_id,server_name:escape(server_name)});
		jQuery('#metric_task_list').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadMetricServerTaskMetric: function(task_type, task_id, task_name)
	{
		jQuery('#__task_' + task_id + '_metric_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_server_task_metric', {task_type:task_type, task_id:task_id});
		jQuery('#__task_' + task_id + '_metric_list').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__task_' + task_id + '_metric_list').fadeIn();
		});
	},
	loadMetricServiceTask: function(tab)
	{
		LUK.loader.setMetricSelectorTab(tab);
		jQuery('#metric_task_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_service_task', {});
		jQuery('#metric_task_list').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadMetricServiceTaskMetric: function(task_type, task_id, task_name)
	{
		LUK.cache.metric_task_name = task_name;
		jQuery('#__task_' + task_id + '_metric_list').html('<img src="/site_media/pic/seeM/gloading.gif" />');
		var ajax_url = getAjaxWrapper('get_metric_service_task_metric', {task_type:task_type, task_id:task_id});
		jQuery('#__task_' + task_id + '_metric_list').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__task_' + task_id + '_metric_list').fadeIn();
		});
	},
	onSelectMetric: function(metric, title, task_id, task_sort, dev)
	{
		var metric_elem = '#' + LUK.cache.curr_overlay_container;
		jQuery(metric_elem).html(LUK.cache.metric_task_name + "<br />" + title);
		jQuery(metric_elem).removeClass();
		jQuery(metric_elem).addClass('metric_box_filled');
		jQuery(metric_elem).fadeOut('fast');
		jQuery(metric_elem).fadeIn('fast');
		LUK.loader.setOverlayMetricCache(LUK.cache.curr_overlay_container,metric,task_id,task_sort,dev);
	},
	setOverlayMetricCache: function(elem, metric, task_id, task_sort, dev)
	{
		LUK.cache[elem] = [metric,task_id,task_sort,dev];
	},
	startOverlayAnalyse: function()
	{
		if (LUK.cache.overlay_left_metric && LUK.cache.overlay_right_metric)
		{
			LUK.cache.task_overlay = LUK.cache.overlay_left_metric[0] + ',' + LUK.cache.overlay_left_metric[1] + ',' + LUK.cache.overlay_left_metric[2] + ',' + LUK.cache.overlay_left_metric[3]
				+ '|' + LUK.cache.overlay_right_metric[0] + ',' + LUK.cache.overlay_right_metric[1] + ',' + LUK.cache.overlay_right_metric[2] + ',' + LUK.cache.overlay_right_metric[3];
		}
		else
		{
			alert('??????????????????');
		}
	},
	onCartItemSumChange: function(item_name, item_sum)
	{
		jQuery('span.item_total_fee').html('<img src="/site_media/pic/seeM/gloading.gif">');
		jQuery('#total_fee').html('<img src="/site_media/pic/seeM/gloading.gif">');
		ajax_url = getAjaxWrapper('update_cart_fee', {item_name:item_name,item_sum: item_sum});
		jQuery.getJSON(getRandomUrl(ajax_url), function(json) {
			var total_fee = json.total_fee;
			var items = json.items;
			jQuery('#total_fee').html('??' + total_fee);
			for (name in items)
			{
				jQuery('#item_total_fee_' + name).html('??' + items[name]);
			}
		});
	},
	gotoPaygate: function(pur_id, type)
	{
		jQuery('#__select_paygate').fadeOut('fast');
		var ajax_url = getAjaxWrapper('goto_paygate', {pur_id:pur_id,type:type});
		jQuery('#__goto_paygate').load(getRandomUrl(ajax_url), function()
		{
			setTimeout(function(){
				if (type == '1')
				{
					document.__pay_form.submit();
				}
				else if (type == '2')
				{
					document.__pay_form.submit();
				}
			}, 1000);
		});
	},
	onChangeMaster: function(elem)
	{
		value = elem.options[elem.selectedIndex].value;
		var url = "/dashboard?mid=" + value;
		window.location = url;
	},
	loadDropMenu: function(elem, param)
	{
		//alert("loadDropMenu");
		if (LUK.cache.display_cache[elem])
		{
			jQuery('#' + elem).fadeOut('fast');
			LUK.cache.display_cache[elem] = false;
		}
		else
		{
			LUK.loader.closeAllDropMenu();
			jQuery('#' + elem).fadeIn('fast');
			LUK.cache.display_cache[elem] = true;
			switch (elem)
			{
				case '__dropmenu_task_selector':
					LUK.loader.loadDropTaskSelector(param);
					break;
				case '__dropmenu_addclass':
					LUK.loader.loadDropSiteClassList(param);
					break;
				case '__dropmenu_server_selector':
					LUK.loader.loadDropServerSelector(param);
					break;
				case '__dropmenu_server_task_selector':
					LUK.loader.loadDropServerTaskSelector(param);
					break;
				case '__dropmenu_service_task_selector':
					LUK.loader.loadDropServiceTaskSelector(param);
					break;
				case '__dropmenu_exp_host_selector':
					LUK.loader.loadDropExpHostSelector(param);
					break;
				case '__dropmenu_domain_selector':
					LUK.loader.loadDropDomainSelector(param);
					break;
				case '__dropmenu_host_selector':
					LUK.loader.loadDropHostSelector(param);
					break;
			}
		}
	},
	closeAllDropMenu: function()
	{
		for (menu_elem in LUK.cache.display_cache)
		{
			jQuery('#' + menu_elem).fadeOut();
			LUK.cache.display_cache[menu_elem] = false;
		}
	},
	onMouseOverDropMenu: function()
	{
		LUK.cache.dropmenu_inside = true;
	},
	onMouseOutDropMenu: function()
	{
		LUK.cache.dropmenu_inside = false;
	},
	onClickDropMenuOutside: function()
	{
		if (!LUK.cache.dropmenu_inside)
		{
			LUK.loader.closeAllDropMenu();
		}
	},
	loadDomainHostNew: function(domain_id)
	{
		jQuery('#__domain_host_new').html('<img src="/site_media/pic/seeM/gajax_loader2.gif" />');
		jQuery('#__domain_host_new').show();
		var ajax_url = getAjaxWrapper('domain_host_new', {domain_id:domain_id});
		jQuery('#__domain_host_new').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__domain_host_new').fadeIn();
		});
	},
	hideDomainHostNew: function()
	{
		jQuery('#__domain_host_new').fadeOut();
	},
	loadHostDomainNew: function(host_id)
	{
		jQuery('#__host_domain_new').html('<img src="/site_media/pic/seeM/gajax_loader2.gif" />');
		jQuery('#__host_domain_new').show();
		var ajax_url = getAjaxWrapper('host_domain_new', {host_id:host_id});
		jQuery('#__host_domain_new').load(getRandomUrl(ajax_url), function()
		{
			jQuery('#__host_domain_new').fadeIn();
		});
	},
	hideHostDomainNew: function()
	{
		jQuery('#__host_domain_new').fadeOut();
	},
	loadDomainHostStatus: function(className)
	{
		if (LUK.cache.display_cache[className])
		{
			jQuery(className).fadeOut('fast');
			LUK.cache.display_cache[className] = false;
		}
		else
		{
			jQuery(className).fadeIn();
			LUK.cache.display_cache[className] = true;
		}
	},
	showMsgAlertDetail: function(msg_id)
	{
		if (jQuery('#__msg_' + msg_id).css('display') != 'none')
		{
			jQuery('#__msg_' + msg_id).fadeOut();
			jQuery('#__msg_alert_' + msg_id).fadeOut();
		}
		else
		{
			jQuery('#__msg_' + msg_id).fadeIn();
			jQuery('#__msg_alert_' + msg_id).fadeIn();
			jQuery('#__msg_alert_' + msg_id).html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
			var ajax_url = getAjaxWrapper('get_msg_alert_list', {msg_id:msg_id});
			jQuery('#__msg_alert_' + msg_id).load(getRandomUrl(ajax_url), function()
			{
				
			});
		}
	},
	showAlertMsgDetail: function(alert_id, msg_id)
	{
		if (jQuery('#__alert_' + alert_id).css('display') != 'none')
		{
			jQuery('#__alert_' + alert_id).fadeOut();
			jQuery('#__alert_msg_' + alert_id).fadeOut();
		}
		else
		{
			jQuery('#__alert_' + alert_id).fadeIn();
			jQuery('#__alert_msg_' + alert_id).fadeIn();
			jQuery('#__alert_msg_' + alert_id).html('<img src="/site_media/pic/seeM/gajax_loader4.gif" />');
			var ajax_url = getAjaxWrapper('get_alert_msg_list', {msg_id:msg_id});
			jQuery('#__alert_msg_' + alert_id).load(getRandomUrl(ajax_url), function()
			{
				
			});
		}
	},
	loadDropTaskSelector: function(param)
	{
		var task_id = param['task_id'];
		jQuery('#__dropmenu_task_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_task_nav_selector', {task_id:task_id});
		jQuery('#__dropmenu_task_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropServerSelector: function(param)
	{
		var server_id = param['server_id'];
		jQuery('#__dropmenu_server_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_server_nav_selector', {server_id:server_id});
		jQuery('#__dropmenu_server_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropServerTaskSelector: function(param)
	{
		var server_id = param['server_id'];
		var task_id = param['task_id'];
		jQuery('#__dropmenu_server_task_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_server_task_nav_selector', {server_id:server_id,task_id:task_id});
		jQuery('#__dropmenu_server_task_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropServiceTaskSelector: function(param)
	{
		var task_id = param['task_id'];
		jQuery('#__dropmenu_service_task_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_service_task_nav_selector', {task_id:task_id});
		jQuery('#__dropmenu_service_task_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropExpHostSelector: function(param)
	{
		var host_id = param['host_id'];
		jQuery('#__dropmenu_exp_host_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_exp_host_nav_selector', {host_id:host_id});
		jQuery('#__dropmenu_exp_host_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropDomainSelector: function(param)
	{
		var domain_id = param['domain_id'];
		jQuery('#__dropmenu_domain_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_domain_nav_selector', {domain_id:domain_id});
		jQuery('#__dropmenu_domain_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropHostSelector: function(param)
	{
		var host_id = param['host_id'];
		jQuery('#__dropmenu_host_selector').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_host_nav_selector', {host_id:host_id});
		jQuery('#__dropmenu_host_selector').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadDropSiteClassList: function(param)
	{
		var task_id = param['task_id'];
		jQuery('#__drop_class_list').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/ggg"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_task_class_sel', {tmp:'summary', task_id:task_id});
		jQuery('#__drop_class_list').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	loadServerViewTaskSelector: function(server_id)
	{
		jQuery('#__view_task_add').show();
		jQuery('#__view_task_add').html('<span><img style="margin:0 10px;" src="/site_media/pic/seeM/gajax_loader4.gif"></span> ???????...');
		var ajax_url = getAjaxWrapper('get_server_view_task_selector', {server_id:server_id});
		jQuery('#__view_task_add').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	hideServerViewTaskSelector: function()
	{
		jQuery('#__view_task_add').fadeOut();
	},
	example: function(period)
	{
		var ajax_url = getAjaxWrapper('get_marker_group_list', {marker_id:marker_id});
		jQuery('#marker_groups').load(getRandomUrl(ajax_url), function()
		{
			
		});
	},
	index_left_menu: function()
    {
		lastItemObj = null;
		jQuery('#dashboard_menu_1').hide();
		//jQuery('#dashboard_menu_2_3').hide();
		//jQuery('#dashboard_menu_2_4').hide();
		jQuery('#dashboard_menu_2_5').hide();
		jQuery('#dashboard_menu_2_3').removeClass().addClass('last');
		jQuery('#dashboard_menu_2_1').removeClass().addClass('selected');
		jQuery('#dashboard_menu_2_2').hide();
		jQuery('#dashboard_menu_2_4').hide();
		jQuery('#device_menu_1').html('<a href="/seeM/site/task/list/" class="link">设备监控</a>');
		/*
		width:142px;
		height:25px;
		*/
		//jQuery('device_menu_1').css('background', 'url(/site_media/pic/seeM/gbg-left-link.gif)');
		/*
		margin:0 0 4px 0;
		font-weight:bold;
		padding:0 0 0 9px;
		line-height:25px;
		color:#60635A;);*/
		/*
		   jQuery('#exp_host_menu_1').html('<h3>用户体验跟踪</h3><ul class="nav">' + 
		   '<li id="exp_host_menu_2_1"><a href="/seeM/exp/host/list/">服务访问速度跟踪</a></li>' + 
		   '<ul class="sub_nav">' + 
		   '<li id="exp_host_menu_2_2"><a href="/seeM/exp/host/list/">服务器列表</a></li>' + 
		   '<li id="exp_host_menu_2_3"><a href="/seeM/exp/host/list/avg/">平均访问速度</a></li>' + 
		   '<li id="exp_host_menu_2_4"><a href="/seeM/exp/host/list/province">省份访问速度</a></li>' + 
		   '<li id="exp_host_menu_2_5"><a href="/seeM/exp/host/list/city">城市访问速度</a></li>' + 
		   '<li id="exp_host_menu_2_6"><a href="/seeM/exp/host/list/isp">运营商访问速度</a></li>' + 
		   '</ul></ul>');
		   jQuery('#exp_host_menu_2_6').removeClass().addClass('last');
		*/
		jQuery('#exp_host_menu_1').hide();
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		jQuery('#service_menu_1').hide();
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		jQuery('#history_menu_1').hide();
		jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + LUK.cache.curr_taskObj_id + '" class="link">监控历史</a>');
		jQuery('#alert_menu_1').hide();
		jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' +  LUK.cache.curr_taskObj_id +'" class="link">告警通知</a>');
		jQuery('#report_menu_1').hide();
		jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>');
		jQuery('#other_menu_1').hide();
	},
	seeM_device_task_list_left_menu: function()
	{
		lastItemObj = null; 
		jQuery('#dashboard_menu_1').hide();
		jQuery('#dashboard_menu_1').html('<a href="/seeM/index/" class="link">概述</a>');
		if(LUK.cache.curr_show.indexOf('seeM_device_task_create_step') != -1) {
			jQuery('#device_menu_2_1').removeClass().addClass('selected');
			jQuery('#device_menu_2_2').removeClass();
		} else if (LUK.cache.curr_show.indexOf('seeM_device_task_list') != -1) {
			jQuery('#device_menu_2_1').removeClass();
			jQuery('#device_menu_2_2').removeClass().addClass('selected');
		}
		jQuery('#device_menu_2_3').hide()
		jQuery('#device_menu_2_4').hide()
		jQuery('#device_menu_2_5').hide()
		jQuery('#device_menu_2_6').hide()
		jQuery('#device_menu_2_7').hide()
		lastItemObj = jQuery('#device_menu_2_2');
		if(lastItemObj.attr('class') == "selected") {
			lastItemObj.removeClass().addClass('selected_last');
		} else {
			lastItemObj.removeClass().addClass('last');
		}
		jQuery('#device_list_menu_1').html('<a href="/seeM/device/list/" class="link">设备</a>')	
		jQuery('#exp_host_menu_1').hide()
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		jQuery('#server_menu_1').hide();
		jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		jQuery('#service_menu_1').hide()
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		var taskId='111';
		jQuery('#history_menu_1').hide();
		jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + taskId + '" class="link">监控历史</a>');
		jQuery('#alert_menu_1').hide();
		jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' + taskId + '" class="link">告警通知</a>');
		jQuery('#report_menu_1').hide();
		jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>');	
	},
	seeM_site_task_list_left_menu: function()
	{
		lastItemObj = null; 
		jQuery('#dashboard_menu_1').hide();
		jQuery('#dashboard_menu_1').html('<a href="/seeM/index/" class="link">概述</a>');
		/*
		   jQuery('#dashboard_menu_2_3').hide();
		   jQuery('#deshhoard_menu_2_4').hide();
		   jQuery('#dashboard_menu_2_5').hide();
		*/
		if(LUK.cache.curr_show.indexOf('seeM_site_task_create_step') != -1) {
			jQuery('#device_menu_2_1').removeClass().addClass('selected');
			jQuery('#device_menu_2_2').removeClass();
		} else if (LUK.cache.curr_show.indexOf('seeM_site_task_list') != -1) {
			jQuery('#device_menu_2_1').removeClass();
			jQuery('#device_menu_2_2').removeClass().addClass('selected');
		}
		jQuery('#device_menu_2_3').hide()
		jQuery('#device_menu_2_4').hide()
		jQuery('#device_menu_2_5').hide()
		jQuery('#device_menu_2_6').hide()
		jQuery('#device_menu_2_7').hide()
		lastItemObj = jQuery('#device_menu_2_2');
		if(lastItemObj.attr('class') == "selected") {
			lastItemObj.removeClass().addClass('selected_last');
		} else {
			lastItemObj.removeClass().addClass('last');
		}
		
		jQuery('#exp_host_menu_1').hide()
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		jQuery('#service_menu_1').hide()
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		var taskId='111';
		jQuery('#history_menu_1').hide();
		jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + taskId + '" class="link">监控历史</a>');
		jQuery('#alert_menu_1').hide();
		jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' + taskId + '" class="link">告警通知</a>');
		jQuery('#report_menu_1').hide();
		jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>');	
	},
	seeM_device_list_left_menu: function()
	{
		lastItemObj = null;
		jQuery('#dashboard_menu_1').hide();
		jQuery('#device_menu_1').html('<a href="/seeM/device/task/list/" class="link">设备监控</a>');
		jQuery('#exp_host_menu_1').hide();
		if(LUK.cache.curr_show.indexOf('seeM_device_list') != -1) {
			jQuery('#device_list_menu_2_1').removeClass().addClass('selected');
		} else if(LUK.cache.curr_show.indexOf('seeM_device_status') != -1) {
			jQuery('#device_list_menu_2_2').removeClass().addClass('selected');
		}
		lastItemObj = jQuery('#device_list_menu_2_2');
		if(lastItemObj.attr('class') == "selected") {
			lastItemObj.removeClass().addClass('selected_last');
		} else {
			lastItemObj.removeClass().addClass('last');
		}
		jQuery('#server_menu_1').hide();
		jQuery('#service_menu_1').hide();
		jQuery('#history_menu_1').hide();
		jQuery('#alert_menu_1').hide();
		jQuery('#report_menu_1').hide();
	},
	seeM_server_left_menu: function()
	{
		lastItemObj = null;
		//alert('seeM_server_left_menu');
		jQuery('#dashboard_menu_1').hide();
		jQuery('#dashboard_menu_1').html('<a href="/seeM/index/" class="link">概述</a>');
		/*
		   jQuery('#dashboard_menu_2_3').hide();
		   jQuery('#deshhoard_menu_2_4').hide();
		   jQuery('#dashboard_menu_2_5').hide();
		   */
		jQuery('#device_menu_1').html('<a href="/seeM/site/task/list/" class="link">设备监控</a>');
		jQuery('#exp_host_menu_1').hide();
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		//jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		if(LUK.cache.curr_show.indexOf('seeM_server_create') != -1) {
			jQuery('#server_menu_2_1').removeClass().addClass('selected');
		} else if(LUK.cache.curr_show.indexOf('seeM_server_list') != -1) {
			jQuery('#server_menu_2_2').removeClass().addClass('selected');
		} else if(LUK.cache.curr_show.indexOf('seeM_server_status') != -1) {
			jQuery('#server_menu_2_3').removeClass().addClass('selected');
		}
		lastItemObj = jQuery('#server_menu_2_3');
		if(lastItemObj.attr('class') == "selected") {
			lastItemObj.removeClass().addClass('selected_last');
		} else {
			lastItemObj.removeClass().addClass('last');
		}
		jQuery('#service_menu_1').hide();
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		var taskId='111';
		jQuery('#history_menu_1').hide();
		jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + taskId + '" class="link">监控历史</a>');
		jQuery('#alert_menu_1').hide();
		jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' + taskId + '" class="link">告警通知</a>');
		jQuery('#report_menu_1').hide();
		jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>');
	},
	seeM_alert_left_menu: function()
	{
		jQuery('#dashboard_menu_1').html('<a href="/seeM/index/" class="link">概述</a>');
		/*
		   jQuery('#dashboard_menu_2_3').hide();
		   jQuery('#deshhoard_menu_2_4').hide();
		   jQuery('#dashboard_menu_2_5').hide();
		   */
		jQuery('#device_menu_1').html('<a href="/seeM/site/task/list/" class="link">设备监控</a>');
		jQuery('#exp_host_menu_1').hide();
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		jQuery('#service_menu_1').hide();
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		var taskId='111';
		jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + taskId + '" class="link">监控历史</a>');
		//jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' + taskId + '" class="link">告警通知</a>');
		jQuery('#alert_menu_2_5').removeClass().addClass('last');
		jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>');
	},
	seeM_report_left_menu: function() 
	{
		jQuery('#dashboard_menu_1').html('<a href="/seeM/index/" class="link">概述</a>');
		/*
		   jQuery('#dashboard_menu_2_3').hide();
		   jQuery('#deshhoard_menu_2_4').hide();
		   jQuery('#dashboard_menu_2_5').hide();
		   */
		jQuery('#device_menu_1').html('<a href="/seeM/site/task/list/" class="link">设备监控</a>');
		jQuery('#exp_host_menu_1').hide();
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		jQuery('#service_menu_1').hide();
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		var taskId='111';
		jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + taskId + '" class="link">监控历史</a>');
		jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' + taskId + '" class="link">告警通知</a>');
		//jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>')
		jQuery('#report_menu_2_1').removeClass().addClass('selected_last');
		//jQuery('#report_menu_2_1').removeClass().addClass('last');
	},
	seeM_history_left_menu: function() 
	{
		lastItemObj = null;
		jQuery('#dashboard_menu_1').html('<a href="/seeM/index/" class="link">概述</a>');
		/*
		   jQuery('#dashboard_menu_2_3').hide();
		   jQuery('#deshhoard_menu_2_4').hide();
		   jQuery('#dashboard_menu_2_5').hide();
		   */
		jQuery('#device_menu_1').html('<a href="/seeM/site/task/list/" class="link">设备监控</a>');
		jQuery('#exp_host_menu_1').hide();
		jQuery('#exp_host_menu_1').html('<a href="/seeM/exp/host/list/" class="link">用户体验跟踪</a>');
		jQuery('#server_menu_1').html('<a href="/seeM/server/list/" class="link">服务器</a>');
		jQuery('#service_menu_1').hide();
		jQuery('#service_menu_1').html('<a href="/seeQ/" class="link">服务监控</a>');
		var taskId='111';
		//jQuery('#history_menu_1').html('<a href="/seeM/site/task/snapshot/?task_id=' + taskId + '" class="link">监控历史</a>');
		lastItemObj = jQuery('#history_menu_2_2');
		if(lastItemObj.attr('class') == "selected") {
			lastItemObj.removeClass().addClass('selected_last');
		} else {
			lastItemObj.removeClass().addClass('last');
		}
		jQuery('#alert_menu_1').html('<a href="/seeM/alert/message/?task_id=' + taskId + '" class="link">告警通知</a>');
		jQuery('#report_menu_1').html('<a href="/seeM/report/settings/" class="link">报告</a>');
	},
	doServerMenu: function() 
	{
		//alert(LUK.cache.curr_show);
		if(LUK.cache.curr_show == 'index') {
			LUK.loader.index_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_device_task') != -1) {
			LUK.loader.seeM_device_task_list_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_device') != -1) {
			LUK.loader.seeM_device_list_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_site_task') != -1) {
			LUK.loader.seeM_site_task_list_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_server') != -1) {
			LUK.loader.seeM_server_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_alert') != -1) {
			LUK.loader.seeM_alert_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_report') != -1) {
			LUK.loader.seeM_report_left_menu();
		} else if (LUK.cache.curr_show.indexOf('seeM_task_snapshot') != -1) {
			LUK.loader.seeM_history_left_menu();
		}

		jQuery('#other_menu_1').hide();
	}
};

jQuery(window).click(function()
		{
		LUK.loader.onClickDropMenuOutside();
		});

// 返回一个随机
function getRandomUrl(url) {
	return url + '&cache=' + Math.floor(100000*Math.random());
}

function getAjaxWrapper(command, options) {
	var url = '/seeM/site/task/list/ajax_wrapper/?command=' + command;
	for (name in options) {
		url += '&' + name + '=' + options[name];
	}
	alert(url);
	return url;
}

function getDomDataById(id)
{
	return getDomData(document.getElementById(id));
}
function getDomData(object)
{
	eval("var data = {" + object.getAttribute('data[]') + "};");
	return data;
}
function hashEncode(data)
{
	var hash = '#';
	for (name in data)
	{
		hash += name + ':#' + data[name] + '#,';
	}
	if (hash.substr(hash.length - 1, 1) == ',')
	{
		hash = hash.substr(0, hash.length - 1);
	}
	return hash;
}
function hashDecode(hash)
{
	while (hash.indexOf('#') != -1)
	{
		hash = hash.replace('#', '"');
	}
	eval("var data = {" + hash + "};");
	return data;
}

function showErrorMsg(msg, action, msgcontainer_id, json)
{
	if (msgcontainer_id == '')
		msgcontainer_id = 'msg_container';
	var msg_container = document.getElementById(msgcontainer_id);
	if (msg_container)
	{
		msg_container.className = 'error_msg';
		msg_container.innerHTML = msg;
		jQuery('#msg_container').show("slow");
	}
	resetSubmitBtn();
	if (typeof error_callback != 'undefined')
	{
		error_callback(msg, action, msgcontainer_id, json);
	}
}
function showControllerErrorMsg(msg, action, msgcontainer_id, json)
{
	for (name in msg)
	{
		if (jQuery('#__err_' + name))
		{
			jQuery('#__err_' + name).html(msg[name]).show();
			jQuery('#' + name).attr('normal_class', jQuery('#' + name).attr('class'));
			jQuery('#' + name).addClass('input_err');
			jQuery('#' + name).focus(function(){
					this.setAttribute('class', this.getAttribute('normal_class'));
					jQuery('#__err_' + this.id).hide();
					});
		}
	}
	resetSubmitBtn();
	if (typeof error_callback != 'undefined')
	{
		error_callback(msg, action, msgcontainer_id, json);
	}
}

function showSuccMsg(msg, action, msgcontainer_id, json)
{
	if (msgcontainer_id == '')
		msgcontainer_id = 'msg_container';
	var msg_container = document.getElementById(msgcontainer_id);
	if (msg_container)
	{
		msg_container.className = 'succ_msg';
		msg_container.innerHTML = msg;
		jQuery('#msg_container').show("slow");
	}
	resetSubmitBtn();
	scroll(0,0);
	if (typeof succ_callback != 'undefined')
	{
		succ_callback(msg, action, msgcontainer_id, json);
	}
	setTimeout(function(){jQuery('#msg_container').hide("slow");}, 3000);
}

function onSubmitSucc(msg, msg_id, btn_id, form_id)
{
	jQuery('#' + btn_id).hide();
	jQuery('#' + form_id).fadeOut('normal', function(){
			jQuery('#' + msg_id).html(msg);
			jQuery('#' + msg_id).show('fast');
			});
	if (typeof succ_callback != 'undefined')
	{
		succ_callback(form_id);
	}
}

var cache_btn_id = null;
var cache_loading_id = null;
function submitLoading(btn_id, loading_id) {
	cache_btn_id = btn_id;
	cache_loading_id = loading_id;
	jQuery('#' + btn_id).hide();
	jQuery('#' + loading_id).show();


}
function resetSubmitBtn()
{
	jQuery('#' + cache_btn_id).show();
	jQuery('#' + cache_loading_id).hide();
}
function resetMsgContainer()
{
	jQuery('#msg_container').hide();
}
function showAlertMsg(msg)
{
	alert(msg);
	return false;
}
function source2url(url)
{
	url += '&source=' + escape(window.location.href);
	window.location = url;
	return false;
}

function showConfirm(msg)
{
	if (confirm(msg))
	{
		return true;
	}
	return false;
}
function selectAllCheckboxByName(obj, switch_elem)
{
	var ret = switch_elem.checked;
	if (obj.length)
	{
		for (var i = 0, length = obj.length; i < length; ++i)
		{
			obj[i].checked = ret;
		}
	}
	else
	{
		obj.checked = ret;
	}
}
function selectCheckbox(obj, selected_array)
{
	if (selected_array == '')
	{
		//return;
	}
	if (!obj)
	{
		return;
	}
	if (obj.length)
	{
		for (var i = 0, length = obj.length; i < length; ++i)
		{
			if (selected_array.indexOf(obj[i].value) != -1)
			{
				obj[i].checked = true;
			}
			else
			{
				obj[i].checked = false;
			}
		}
	}
	else
	{
		if (selected_array.indexOf(obj.value) != -1)
		{
			obj.checked = true;
		}
		else
		{
			obj.checked = false;
		}
	}
}
function checkRadio(obj, value)
{
	if (!obj)
	{
		return;
	}
	if (obj.length)
	{
		for (var i = 0, length = obj.length; i < length; ++i)
		{
			if (obj[i].value == value)
			{
				obj[i].checked = true;
			}
		}
	}
	else
	{
		if (obj.value == value)
		{
			obj.checked = true;
		}
	}
}
function switchAttr(cond, result)
{
	result = cond;
}
function goPage(page)
{
	var url = window.location.href;
	if (url.indexOf('page=') != -1)
	{
		url = url.replace(/page=[0-9]+/g, 'page=' + page);
	}
	else
	{
		if (url.indexOf('#') != -1)
		{
			url = url.substr(0, url.indexOf('#'));
		}
		url += (url.indexOf('?') == -1 ? '?' : '&') + 'page=' + page;
	}
	window.location = url;
}
function goStart(start,curr,dir)
{
	var url = window.location.href;
	if (url.indexOf('start=') != -1)
	{
		url = url.replace(/start=[0-9]+/g, 'start=' + start);
	}
	else
	{
		if (url.indexOf('#') != -1)
		{
			url = url.substr(0, url.indexOf('#'));
		}
		url += (url.indexOf('?') == -1 ? '?' : '&') + 'start=' + start;
	}
	if (url.indexOf('curr=') != -1)
	{
		url = url.replace(/curr=[0-9]+/g, 'curr=' + curr);
	}
	else
	{
		if (url.indexOf('#') != -1)
		{
			url = url.substr(0, url.indexOf('#'));
		}
		url += (url.indexOf('?') == -1 ? '?' : '&') + 'curr=' + curr;
	}
	if (url.indexOf('dir=') != -1)
	{
		url = url.replace(/dir=[0-9]+/g, 'dir=' + dir);
	}
	else
	{
		if (url.indexOf('#') != -1)
		{
			url = url.substr(0, url.indexOf('#'));
		}
		url += (url.indexOf('?') == -1 ? '?' : '&') + 'dir=' + dir;
	}
	window.location = url;
}

function getAjaxWrapper(command, options) {
	var url = '/seeM/site/task/list/ajax_wrapper/?command=' + command;
	for (name in options) {
		url += '&' + name + '=' + options[name];
	}
	return url;
}

function task_detail_display(task_id)
{
	var task_tr = jQuery('#__task_' + task_id);
	var task_tr_extend = jQuery('#__task_' + task_id + '_extend');
	task_tr.css('background', '0');
	task_tr_extend.css('display', '');
}

//-------------
	function onlyNum() {
		if(!((event.keyCode>=48&&event.keyCode<=57)||(event.keyCode>=96&&event.keyCode<=105)))
			//考虑小键盘上的数字键
			event.returnvalue=false;
	}

function checkDatasubmitLoading() {
	//alert("test");
	var task_type = document.getElementById("task_type");
	if(task_type.value == "port") {
		//alert("check Data port task");
		//return false;
	} else if (task_type.value == "ping") {
		//alert("check Data ping task");
		//document.__form.submit();
	} else if (task_type.value == "snmp") {
		//alert("check Data snmp task");
		var snmp_port = document.getElementById("snmp_port");
		if(snmp_port.value.length <= 0 ) {
			alert("snmp端口不能为空");
			return false;
		}
		var snmp_comm = document.getElementById("snmp_comm");
		if(snmp_comm.value.length <=0 ) {
			alert("Community字符串不能为空");
			return false;
		}
	}

	var task_name = document.getElementById("task_name");
	if(task_name.value.length <=0 ) {
		alert("监控项目名称不能为空");
		return false;
	}

	var server_ip = document.getElementById("server_ip");
	if(server_ip != null && server_ip.value.length <= 0 ) {
		alert("请选择服务器主机或IP");
		return false;
	}
	if(!isIP(server_ip.value)){
		alert("IP地址格式不正确") ;
		return false;
	}
	
	//cache_btn_id = btn_id;
	//cache_loading_id = loading_id;
	//jQuery('#' + btn_id).hide();
	//jQuery('#' + loading_id).show();
	document.__form.submit();
	return true;
}
function isIP(ip){
	//var reNum = /^\d*$/ ;
	var re=/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/g
	return (re.test(ip)) ;
}
function deviceCheckData() {
	var device_ip =  document.getElementById("device_ip");
	if(device_ip != null && device_ip.value.length <= 0 ) {
		alert("请填写设备IP");
		return false;
	}

	var device_name =  document.getElementById("device_name");
	if(device_name != null && device_name.value.length <= 0 ) {
		alert("请填写设备名称");
		return false;
	}

	document.__form.submit();
	return true;
}

function checkData(){
	var sel_server = document.getElementById("sel_server");
	//alert(sel_server.options[sel_server.selectedIndex].text);
	if(sel_server.options[sel_server.selectedIndex].value < 0 ) {

		var device_ip =  document.getElementById("device_ip");
		if(device_ip != null && device_ip.value.length <= 0 ) {
			alert("请填写设备IP或选择设备");
			return false;
		}

		var device_name =  document.getElementById("device_name");
		if(device_name != null && device_name.value.length <= 0 ) {
			alert("请填写设备名称或选择设备");
			return false;
		} else {
			document.form1.submit();
			return true;
		}

		alert("请选择设备");
		return false;
	}

	/*
	   var exitFor = false;
	   var ary = document.getElementsByTagName("input");
	//alert(ary.length);
	for(i=0; i<ary.length; i++) {
	var obj = ary(i);
	if(obj.type == "text" && !obj.readonly) {   
	dType = obj.dataType;   
	if(dType == "1") {
	if (!IsNumeric(obj))   
	return false;
	}   
	}
	}*/
	document.form1.submit();
	return true;
}

function IsNumeric(obj){ 
	return true;
}

/* Modeline for vim {{{
 * vim: ts=4 shiftwidth=4:
 * vim: set nu:
 * vim600: fdm=marker fdl=0 fdc=3:
 * }}}*/

try{
    document.write("<div id='"+_wlkRptID+"'></div>");
    loadJs("http://www.webluker.com/site_media/js/stat/rpt.js");
    var url='http://my.webluker.com/seeS/reporting/ReadySiteReport?id='+_wlkRptID+'&.rnd='+Math.random();
    loadJs(url);
}catch(e){
}
function loadJs(js){
    var d=document.createElement("script");
    d.type="text/javascript";
    d.src=js;
    var e=document.getElementsByTagName("head")[0];
    if(e){
        window.setTimeout(function(){e.appendChild(d)},0);
    }
}


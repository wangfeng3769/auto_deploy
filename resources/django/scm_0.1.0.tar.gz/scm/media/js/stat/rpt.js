try{
    function _wlkOnSuccess(data){
        var div = document.getElementById(_wlkRptID);
        div.innerHTML='<a href="http://my.webluker.com" target="_blank" style="text-decoration:none;" alt="Powered by Webluker" title="Powered by Webluker"><div style="font-family:Verdana;line-height:14px;background:url(http://www.webluker.com/site_media/images/stat_logo.gif) 0 0 no-repeat;width:109px;height:22px;"><span style="float:left;margin:5px 0 0 72px;font-size:10px;color:#28AB17;">'+data.wlkRptVal+'</span></div></a>';
    }
    function _wlkOnFail(data){
        var div = document.getElementById(_wlkRptID);
        div.innerHTML='<strong>By Webluker</strong>';
    }
}catch(e){
}

#/bin/sh
/FlexiDNS/application/sbin/rndc -k /FlexiDNS/conf/rndc.key flush 

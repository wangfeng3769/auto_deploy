# -*- coding: utf-8 -*-

from django.db import models
from django.core.exceptions import ValidationError

# Create your models here.

CONFIG_TYPE = (
        (0, 'zone'),
    )

class Backup(models.Model):
    name = models.CharField(max_length=128, unique=True)
    detail = models.TextField()
    type = models.IntegerField(max_length=1, default=0, choices=CONFIG_TYPE)
    time = models.DateTimeField(auto_now_add=True)

class Zone(models.Model):
    backup = models.ForeignKey(Backup)
    name = models.CharField(max_length=128)
    head_file = models.CharField(max_length=256)
    record_file = models.CharField(max_length=256)
    userzone_file = models.CharField(max_length=256)
    time = models.DateTimeField(auto_now_add=True)

class Task(models.Model):
    name = models.CharField(max_length=128, unique=True)
    detail = models.CharField(max_length=128)
    type = models.IntegerField(max_length=1, default=0, choices=CONFIG_TYPE)
    time = models.DateTimeField(auto_now_add=True)


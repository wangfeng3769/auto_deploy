# -*- coding: utf8 -*-

from django.db import connection, transaction
from scm.backup.models import Zone
from scm.config.models import zone_head
from scm.config.models import zone_data

def clean_current_zone(zone_id):
    cursor = connection.cursor()

    zone = Zone.objects.get(id=zone_id)
    zone_name = zone.name
    try:
        zone_head_id = zone_head.objects.get(zone_name=zone_name).id
        cursor.execute('delete from config_zone_record where zone_head_id=%s' % zone_head_id)
        cursor.execute('delete from config_zone_head where zone_name="%s"' % zone_name)
        cursor.execute('delete from user_userzone where zone_id="%s"' % zone_head_id)
    except:
        pass

    transaction.commit_unless_managed()

def clean_current_all_zone():
    cursor = connection.cursor()

    cursor.execute('delete from config_zone_head')
    cursor.execute('delete from config_zone_record')
    cursor.execute('delete from config_zone_data')
    cursor.execute('delete from user_userzone')

    transaction.commit_unless_managed()

def reduction(zone_id, run_restore, single=True):

    zone = Zone.objects.get(id=zone_id)
    head_file = zone.head_file
    record_file = zone.record_file
    userzone_file = zone.userzone_file
    name = zone.name
    backup_id = zone.backup.id

    if single:
        clean_current_zone(zone_id)

    if run_restore(head_file) and run_restore(record_file) and run_restore(userzone_file):
        zone_head_id = zone_head.objects.get(zone_name=name).id
        zone_data.updateDataByZoneHead(zone_head_id)

        return backup_id
    else:
        return None


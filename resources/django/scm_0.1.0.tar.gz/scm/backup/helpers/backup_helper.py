# -*- coding:utf8 -*-

import os
from scm.settings import DATABASES

def run_zone_backup(table, condition, backup_file):
    database = DATABASES['default']

    if database['PASSWORD'] == '':
        cmd = "mysqldump -u%(username)s \
--add-drop-table=FALSE \
--no-create-info=TRUE \
%(databasename)s %(table)s \
'-w%(condition)s' > \
%(backup_file)s" % {
            'username':database['USER'],
            'databasename': database['NAME'],
            'table': table,
            'condition': condition,
            'backup_file': backup_file,
    }
    else:
        cmd = "mysqldump -u%(username)s -p%(password)s \
--add-drop-table=FALSE \
--no-create-info=TRUE \
%(databasename)s %(table)s \
'-w%(condition)s' > \
%(backup_file)s" % {
            'username':database['USER'],
            'password':database['PASSWORD'],
            'databasename': database['NAME'],
            'table': table,
            'condition': condition,
            'backup_file': backup_file,
    }

    result = False
    if os.system(cmd) == 0 and os.path.exists(backup_file): result = True

    return result

def run_restore(backup_file):

    database = DATABASES['default']

    if database['PASSWORD'] == '':
        cmd = "mysql -u%(username)s \
%(databasename)s < \
%(backup_file)s" % {
            'username':database['USER'],
            'databasename': database['NAME'],
            'backup_file': backup_file,
        }
    else:
        cmd = "mysql -u%(username)s -p%(password)s \
    %(databasename)s < \
    %(backup_file)s" % {
                'username':database['USER'],
                'password':database['PASSWORD'],
                'databasename': database['NAME'],
                'backup_file': backup_file,
        }

    result = False
    if os.path.exists(backup_file) and os.system(cmd) == 0: return True

    return result


from django.conf.urls.defaults import *

urlpatterns = patterns('scm.backup.views.zone_view',
    (r'^$', 'index'),
    (r'^zone$', 'index'),
    (r'^zone/show?', 'show'),
    (r'^zone/new?', 'new'),
    (r'^zone/create?', 'create'),
    (r'^zone/delete?', 'delete'),
    (r'^zone/restore?', 'restore'),
)

urlpatterns += patterns('scm.backup.views.task_view',
    (r'^task/zone$', 'index'),
    (r'^task/zone/new?', 'new'),
    (r'^task/zone/create?', 'create'),
    (r'^task/zone/delete?', 'delete'),
)

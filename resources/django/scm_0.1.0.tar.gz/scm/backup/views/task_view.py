# -*- coding: utf8 -*-

import os
from django.db import IntegrityError
from crontab import CronTab
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from scm.backup.models import Task
from scm.util.lukWeb import writeLog
from scm.util.decorators import authority_required
from scm.settings import BACKUP_DIR
from scm.settings import ROOT_DIR

@authority_required(1000)
def index(request):
    info = request.REQUEST.get('ret_info', '')

    tasks = Task.objects.all()

    return render_to_response(
            'backup/task/index.html',
            {'tasks':tasks, 'ret_info':info},
            context_instance = RequestContext(request)
    )

@authority_required(1000)
def new(request):
    ret_info = request.REQUEST.get('ret_info', '')
    return render_to_response('backup/task/new.html', {'ret_info':ret_info}, context_instance=RequestContext(request))

@authority_required(1000)
def create(request):
    name = request.REQUEST.get('task_name', '')

    minute = request.REQUEST.get('minute', '*')
    hour = request.REQUEST.get('hour', '*')
    dom = request.REQUEST.get('dom', '*')
    month = request.REQUEST.get('month', '*')

    detail = '%s %s %s %s ' % (minute, hour, dom, month)

    try:
        Task.objects.create(name=name, detail=detail)
    except IntegrityError, e:
        return HttpResponseRedirect('/backup/task/zone/new?ret_info=%s' % '任务名称重复，请更换!')

    tab = CronTab()
    cmd = 'python %s/util/auto_backup.py --version >> /tmp/scm_auto_%s' % (ROOT_DIR, name)
    cron = tab.new(command=cmd)
    if minute and minute != '*': cron.minute().on(minute)
    if hour and hour != '*': cron.hour().on(hour)
    if dom and dom != '*': cron.dom().on(dom)
    if month and month != '*': cron.month().on(month)
    tab.write()

    return HttpResponseRedirect('/backup/task/zone?ret_info=%s' % '自动备份定制成功!')

@authority_required(1000)
def delete(request):
    task_id = request.REQUEST.get('task_id', '')

    task = Task.objects.get(id=task_id)
    name= task.name

    tab = CronTab()
    tab.remove_all('>> /tmp/scm_auto_%s' % name)
    tab.write()

    task.delete()
    os.system('rm -f /tmp/scm_auto_%s' % name)

    return HttpResponseRedirect('/backup/task/zone?ret_info=%s' % '删除成功!')


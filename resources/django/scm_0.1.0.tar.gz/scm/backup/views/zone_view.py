# -*- coding: utf8 -*-

import urlparse
from django.db import IntegrityError
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from scm.config.models import zone_head
from scm.config.models import zone_record
from scm.config.models import zone_data
from scm.backup.models import Backup
from scm.backup.models import Zone
from scm.backup.helpers import backup_helper
from scm.backup.helpers.zone_view_helper import clean_current_all_zone
from scm.backup.helpers.zone_view_helper import reduction
from scm.util.lukWeb import writeLog
from scm.util.paginator_wrapper import paginate
from scm.util.decorators import authority_required
from scm.settings import BACKUP_DIR

CONFIG_TYPE = {
        'zone': 0,
}

@authority_required(1000)
def index(request):
    info = request.REQUEST.get('ret_info', '')
    page = request.REQUEST.get('page', 1)

    backups = Backup.objects.all()
    content, pagination = paginate(backups, page)

    return render_to_response(
            'backup/zone/index.html',
            {'backups':content, 'pagination':pagination, 'ret_info':info},
            context_instance = RequestContext(request)
    )

@authority_required(1000)
def new(request):
    return render_to_response('backup/zone/new.html', context_instance=RequestContext(request))

@authority_required(1000)
def create(request):
    name = request.POST.get('name')
    detail = request.POST.get('detail')
    user_id = request.user.id

    try:
        backup = Backup.objects.create(name=name, detail=detail)

        zone_name_list = zone_head.objects.values_list('id', 'zone_name')

        for zone_id, zone_name in zone_name_list:

            head_file = '%s/head_%s_%s.sql' % (BACKUP_DIR, zone_name, name)
            head_condition = 'zone_name="%s"' % zone_name
            record_file = '%s/record_%s_%s.sql' % (BACKUP_DIR, zone_name, name)
            record_condition = 'zone_head_id=%s' % zone_id
            userzone_file = '%s/userzone_%s_%s.sql' % (BACKUP_DIR, zone_name, name)
            userzone_condition = 'zone_id=%s' % zone_id


            if backup_helper.run_zone_backup('config_zone_head', head_condition, head_file) and \
                backup_helper.run_zone_backup('config_zone_record', record_condition, record_file) and \
                backup_helper.run_zone_backup('user_userzone', userzone_condition, userzone_file):

                Zone.objects.create(
                            backup=backup,
                            name=zone_name,
                            head_file=head_file,
                            record_file=record_file,
                            userzone_file=userzone_file
                        )

                writeLog(user_id, 'black', '添加域名备份:%s' % name)
            else:
                return HttpResponse('create backup fail')
    except IntegrityError, e:
        return HttpResponse("has same name")

    return HttpResponseRedirect('/backup/zone')

@authority_required(1000)
def show(request):
    ret_info = request.REQUEST.get('ret_info', '')
    backup_id = request.REQUEST.get('backup_id', '')
    backup_name = Backup.objects.get(id=backup_id).name
    zones = Zone.objects.filter(backup__id=backup_id)
    return render_to_response('backup/zone/show.html', {'zones':zones, 'backup_name':backup_name, 'ret_info':ret_info}, context_instance=RequestContext(request))

@authority_required(1000)
def delete(request):
    backup_id = request.REQUEST.get('backup_id', '')
    name = request.REQUEST.get('name', '')
    user_id = request.user.id

    try:
        Backup.objects.get(id=backup_id).delete()

        writeLog(user_id, 'black', '删除域名备份:%s' % name)
    except:
        return HttpResponse('fail')

    return HttpResponseRedirect('/backup/zone')

@authority_required(1000)
def restore(request):
    referer = urlparse.urlparse(request.META.get('HTTP_REFERER'))
    user_id = request.user.id

    if 'show' in referer.path:
        zone_id = request.REQUEST.get('zone_id', '')
        backup_id = reduction(zone_id, backup_helper.run_restore)
        if backup_id:
            info = u'还原成功!'
            writeLog(user_id, 'zone', '恢复域名备份')
            return HttpResponseRedirect('/backup/zone/show?backup_id=%s&ret_info=%s' % (backup_id, info))
        else:
            return HttpResponse("fail")
    else:
        backup_id = request.REQUEST.get('backup_id', '')
        zone_ids = list(Zone.objects.filter(backup__id=backup_id).values_list('id', flat=True))

        clean_current_all_zone()

        for zone_id in zone_ids:
            if reduction(zone_id, backup_helper.run_restore, single=False):
                pass
            else:
                return HttpResponse("fail")

        info = u'还原成功!'
        writeLog(user_id, 'zone', '恢复域名备份')
        return HttpResponseRedirect('/backup/zone?ret_info=%s' % info)


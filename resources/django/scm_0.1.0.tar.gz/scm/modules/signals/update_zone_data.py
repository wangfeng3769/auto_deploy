# -*- coding:utf8 -*-

from django.db.models import signals
from scm.config.models import zone_head
from scm.config.models import zone_record
from scm.config.models import zone_data
from scm.config.models import zone_version

def create_or_updata_or_delete_record(sender, instance, signal, *args, **kwargs):
    zone_head_ins = instance.zone_head
    record_count = zone_record.objects.filter(zone_head=zone_head_ins).count()
    enable_record_count = zone_record.objects.filter(zone_head=zone_head_ins, status=1).count()

    zone_head_ins.record_count = record_count
    zone_head_ins.enable_record_count = enable_record_count
    zone_head_ins.save()

    if record_count > 0:
        zone_data.updateDataByZoneHead(zone_head_ins.id)
    else:
        zone_data.updateDataByNull(zone_head_ins.id)

    #if enable_record_count > 0:
        #zone_data.updateDataByZoneHead(zone_head_ins.id)
    #else:
        #zone_data.updateDataByNull(zone_head_ins.id)

def create_or_updata_or_delete_head(sender, instance, signal, *args, **kwargs):
    zone_head_ins = instance
    record_count = zone_record.objects.filter(zone_head=zone_head_ins).count()
    #enable_record_count = zone_record.objects.filter(zone_head=zone_head_ins, status=1).count()

    if record_count > 0:
        zone_data.updateDataByZoneHead(zone_head_ins.id)
    else:
        zone_data.updateDataByNull(zone_head_ins.id)

signals.post_save.connect(create_or_updata_or_delete_record, sender=zone_record)
signals.post_delete.connect(create_or_updata_or_delete_record, sender=zone_record)

signals.post_save.connect(create_or_updata_or_delete_head, sender=zone_head)
signals.post_delete.connect(create_or_updata_or_delete_head, sender=zone_head)


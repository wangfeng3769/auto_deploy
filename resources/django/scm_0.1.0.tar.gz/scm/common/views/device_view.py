# -*- coding:utf8 -*-

from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from scm.util.decorators import authority_required
from scm.common.models import group
from scm.common.models import device
from scm.common.models import application
from scm.util.paginator_wrapper import paginate
from scm.util.lukWeb import getUser
from scm.util.lukWeb import writeLog

@authority_required(1000)
def index(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')
    rip = request.REQUEST.get('rip', '')
    rhost = request.REQUEST.get('rhost', '')
    page = int(request.REQUEST.get('page', 1))

    device_list = _query(rapp, rgroup, rip, rhost)
    content, pagination = paginate(device_list, page)

    group_list = group.objects.all()
    app_list = application.objects.all()

    return render_to_response(
                'common/device/index.html',
                {
                    'rapp':rapp,
                    'rip':rip,
                    'rhost':rhost,
                    'rgroup':rgroup,
                    'ret_info':ret_info,
                    'group_list':group_list,
                    'app_list':app_list,
                    'device_list':content,
                    'pagination':pagination,
                },
                context_instance = RequestContext(request)
            )

def _query(rapp, rgroup, rip, rhost):
    condition = Q()

    if rapp:
        condition &= Q(app__id=rapp)

    if rgroup:
        condition &= Q(group__id=rgroup)

    if rip:
        condition &= Q(mip__contains=rip)

    if rhost:
        condition &= Q(hostname__contains=rhost)

    device_list = device.objects.filter(condition)

    return device_list

@authority_required(1000)
def show(request):
    device_id = request.REQUEST.get('device_id', '')
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')
    try:
        device_data = device.objects.get(id=device_id)
    except:
        return HttpResponseRedirect('/common/device')

    return render_to_response('common/device/show.html', {'rapp':rapp,'rgroup':rgroup,'device_data':device_data}, context_instance = RequestContext(request))

@authority_required(1000)
def new(request):
    group_list = group.objects.all()
    app_list = application.objects.all()

    return render_to_response(
                'common/device/new.html',
                {
                    'group_list':group_list,
                    'app_list':app_list
                },
                context_instance = RequestContext(request)
            )

@authority_required(1000)
def create(request):
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')

    ip = request.REQUEST.get('ip', '')
    name = request.REQUEST.get('name', '')
    info = request.REQUEST.get('info', '')
    sn = request.REQUEST.get('sn', '')

    try:
        dvc = device.objects.get(sn=sn, app__id=rapp)

        info = "同解析组同类型设备SN[ %s ]已经存在，不能重复添加！" % name
        return HttpResponseRedirect('/common/device?ret_info=%s' % info)
    except:
        dvc = device()
        dvc.mip=ip
        dvc.hostname=name
        dvc.note=info
        dvc.sn=sn
        dvc.group_id = rgroup
        dvc.app_id = rapp
        dvc.save()

    writeLog(getUser(request).id, 'device', "添加设备%s" % name)
    info = "设备[ %s ]添加成功！" % name
    return HttpResponseRedirect('/common/device?ret_info=%s' % info)

@authority_required(1000)
def update(request):
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')

    device_id = request.REQUEST.get('device_id', '')
    ip = request.REQUEST.get('ip', '')
    name = request.REQUEST.get('name', '')
    sn = request.REQUEST.get('sn', '')
    info = request.REQUEST.get('info', '')

    try:
        dvc = device.objects.get(id=device_id) 
        device_list = device.objects.filter(sn=sn,app__id=rapp).exclude(id=device_id)
        if device_list.count() !=0 :
            info = "设备SN[ %s ]已经被其他同类型设备占用，不能修改！" % name
            return render_to_response(
                        'common/device/show.html',
                        {
                            'ret_info': info,
                            'device_data':device,
                            'rapp':rapp,
                            'rgroup':rgroup
                        },
                        context_instance = RequestContext(request)
                    )

        old_ip = dvc.mip
        dvc.mip=ip
        dvc.hostname=name
        dvc.sn=sn
        dvc.note=info
        dvc.save()
    except:
        return render_to_response(
                    'common/device/show.html',
                    {'ret_info':'找不到设备！'},
                    context_instance = RequestContext(request)
                )

    writeLog(getUser(request).id, 'device', "修改%s设备信息" % name)
    info = "设备[ %s ]保存成功！" % name
    return HttpResponseRedirect('/common/device?&ret_info=%s' % info)

@authority_required(1000)
def delete(request):
    device_id = request.REQUEST.get('device_id', '')
    device_name = request.REQUEST.get('device_name', '')
    try:
        device.objects.get(id=device_id).delete()
    except:
        info = "设备[ %s ]删除失败！" % device_name

        return HttpResponseRedirect('/common/device?ret_info=%s' % info)

    writeLog(getUser(request).id, 'device', "删除设备%s" % device_name)
    info = "设备[ %s ]删除成功！" % device_name

    return HttpResponseRedirect('/common/device?ret_info=%s' % info)


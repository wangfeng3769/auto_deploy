# -*- coding:utf-8 -*-

from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.decorators import authority_required
from scm.common.models import group
#from scm.alarm.models import base_threshold
#from scm.alarm.models import dns_threshold
from scm.util.lukWeb import getUser
from scm.util.lukWeb import writeLog

@authority_required(1000)
def index(request):
    ret_info = request.REQUEST.get('ret_info', '')

    group_list = group.objects.all()

    return render_to_response(
                'common/group/index.html',
                {'ret_info':ret_info, 'group_list':group_list},
                context_instance = RequestContext(request)
            )

@authority_required(1000)
def show(request):
    group_id = request.REQUEST.get('group_id', '')

    try:
        group_data = group.objects.get(id=group_id)

    except:
        return HttpResponseRedirect('/common')

    return render_to_response(
                'common/group/show.html',
                {'group_data':group_data},
                context_instance = RequestContext(request)
            )

@authority_required(1000)
def new(request):
    return render_to_response('common/group/new.html', {}, context_instance = RequestContext(request))

@authority_required(1000)
def create(request):
    name = request.REQUEST.get('name', '')
    info = request.REQUEST.get('info', '')
    try:
        gp = group.objects.get(name=name) 
        info = "解析组[ %s ]已经存在，不能重复添加！" % name
        return HttpResponseRedirect('/common/group?ret_info=%s' % info)
    except:
        gp = group()
        gp.name=name
        gp.note=info
        gp.can_modify = True
        gp.save()

        #bt = base_threshold()
        #bt.group_id = gp.id
        #bt.save()

        #dt = dns_threshold()
        #dt.group_id = gp.id
        #dt.save()

    writeLog(getUser(request).id, 'group', "添加解析组%s" % name)
    info = "解析组[ %s ]添加成功！" % name
    return HttpResponseRedirect('/common/group?ret_info=%s' % info)

@authority_required(1000)
def update(request):
    group_id = request.REQUEST.get('group_id', '')
    name = request.REQUEST.get('name', '')
    info = request.REQUEST.get('info', '')

    try:
        gp = group.objects.get(id=group_id)

        group_list = group.objects.filter(name=name).exclude(id=group_id)
        if group_list.count() !=0 :
            ret_info = "解析组[%s]已经被存在，不能修改！" % name.encode('utf8')

            return render_to_response(
                        'common/group/show.html',
                        {'group_data':gp,'ret_info': ret_info},
                        context_instance = RequestContext(request)
                    )

        oldname = gp.name
        gp.name = name
        gp.note = info
        gp.save()
    except:
        return render_to_response('common/group/show.html', {'ret_info':'找不到解析组！'}, context_instance = RequestContext(request))

    writeLog(getUser(request).id, 'group', "修改%s解析组为%s" % (oldname.encode('utf8'),name.encode('utf8') ))
    ret_info = "解析组[ %s ]保存成功！" % name.encode('utf8')
    return HttpResponseRedirect('/common/group?ret_info=%s' % ret_info)

@authority_required(1000)
def delete(request):
    group_id = request.REQUEST.get('group_id', '')
    group_name = request.REQUEST.get('group_name', '')

    try:
        gp = group.objects.get(id=group_id).delete()
    except:
        info = "解析组[%s]删除失败！" % group_name
        return HttpResponseRedirect('/common/group?ret_info=%s' % info)

    writeLog(getUser(request).id, 'group', "删除解析组%s" % group_name)

    info = "解析组[%s]删除成功！" % group_name

    return HttpResponseRedirect('/common/group?ret_info=%s' % info)


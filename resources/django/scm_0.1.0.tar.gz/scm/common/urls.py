from django.conf.urls.defaults import *

urlpatterns = patterns('scm.common.views.group_view',
     (r'^$','index'),

     (r'^group$','index'),
     (r'^group/show?','show'),
     (r'^group/update?','update'),
     (r'^group/new?','new'),
     (r'^group/create?','create'),
     (r'^group/delete?','delete'),
)

urlpatterns += patterns('scm.common.views.device_view',
     (r'^device$','index'),
     (r'^device/show','show'),
     (r'^device/new','new'),
     (r'^device/create','create'),
     (r'^device/update','update'),
     (r'^device/delete','delete'),
)

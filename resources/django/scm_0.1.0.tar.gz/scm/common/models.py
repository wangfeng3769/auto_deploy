# -*- coding:utf-8 -*-

from django.db import models

class group(models.Model):
    name = models.CharField(max_length=16,verbose_name=u'解析组名称')
    can_modify = models.IntegerField(max_length=1, default=1)
    note = models.TextField(blank=True,verbose_name=u'备注')
    add_time = models.DateField(auto_now_add=True,verbose_name=u'添加时间')

    def __unicode__(self):
        return u'解析组%s'%self.name

    class Meta:
        verbose_name = u'解析组'
        verbose_name_plural = u'解析组库'

class application(models.Model):
    id = models.CharField(max_length=16,primary_key=True,verbose_name=u'应用ID')
    name = models.CharField(max_length=50,verbose_name=u'应用名称')
    cn_name = models.CharField(max_length=30,verbose_name=u'中文名称')
    short_name = models.CharField(max_length=30,verbose_name=u'应用简称')
    note = models.TextField(blank=True,verbose_name=u'备注')
    add_time = models.DateField(auto_now_add=True,verbose_name=u'添加时间')

    def __unicode__(self):
        return u'应用%s'%self.short_name

    class Meta:
        ordering = ['short_name']
        verbose_name = u'应用'
        verbose_name_plural = u'应用库'

class device(models.Model):
    Status_Type = (
            (0, u'停用'),
            (1, u'启用'),
    )

    group = models.ForeignKey(group)
    app = models.ForeignKey(application)
    hostname = models.CharField(max_length=32,verbose_name=u'设备名称')
    mip = models.CharField(max_length=15,verbose_name=u'管理IP')
    sn = models.CharField(max_length=16,verbose_name=u'SN号',default='0')
    card_num = models.IntegerField(default=1,verbose_name=u'网卡个数')
    iplist = models.TextField(blank=True,verbose_name=u'其它IP列表',default='')
    status = models.IntegerField(choices=Status_Type,verbose_name=u'设备状态',default=1)
    mac = models.CharField(max_length=17,blank=True,verbose_name=u'MAC地址',default='')
    os = models.CharField(max_length=17,blank=True,verbose_name=u'操作系统',default='')
    note = models.TextField(blank=True,verbose_name=u'备注',default='')
    add_time = models.DateField(auto_now_add=True,verbose_name=u'添加时间')
    #apps = models.ManyToManyField(application, through="device_application")

    def __unicode__(self):
        return u'设备%s'%self.hostname

    class Meta:
        ordering = ['hostname']
        verbose_name = u'设备'
        verbose_name_plural = u'设备库'

class ipset_location(models.Model):
    ipset = models.CharField(max_length=16, unique=True)
    location = models.CharField(max_length=16, unique=True)

class ipset_head(models.Model):
    name =models.CharField(max_length=32, unique=True)
    group=models.CharField(max_length=32, default='')
    grade=models.CharField(max_length=32, default='')
    country=models.CharField(max_length=32, default='')
    isp=models.CharField(max_length=32, default='')
    region=models.CharField(max_length=32, default='')
    province=models.CharField(max_length=32, default='')
    city=models.CharField(max_length=32, default='')
    info=models.CharField(max_length=32, default='')

class ipset_body(models.Model):
    ipset_head = models.ForeignKey(ipset_head)
    cidr =models.CharField(max_length=20)
    ipbegin=models.PositiveIntegerField(max_length=11)
    ipend=models.PositiveIntegerField(max_length=11)    


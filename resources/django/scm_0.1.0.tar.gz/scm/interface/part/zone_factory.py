# -*- coding:utf8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response

from scm.config.zone_models import zone_version,zone_data
from scm.common.models import device
from scm.settings import ROOT_PATH

#----------------------------------------------------------------------
def getZone(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not fdns device
    """  
    
    get_id = request.REQUEST.get('id', 10003)
    get_teid = request.REQUEST.get('teid')
    get_type = request.REQUEST.get('type')
    get_version = request.REQUEST.get('version', 0)
    
    #if not get_id or get_id!='10003':
    #    response = HttpResponse(content='#id error', mimetype='text/plain')
    #    response['status'] = 101
    #    return response
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    if not get_type or (get_type!='0' and get_type!='1'):
        response = HttpResponse(content='#type error', mimetype='text/plain')
        response['status'] = 103
        return response
    group_id = __getGroupID(get_teid)
    if -1 == group_id:
        response = HttpResponse(content='#teid is not fdns device', mimetype='text/plain')
        response['status'] = 105
        return response
    
    data = ''
    try:
        if get_type=='1':
            data = __getModifyZoneData(get_version, group_id)
        else:
            data = __getAllZoneData(group_id)
    except:
        response = HttpResponse(content='#db error', mimetype='text/plain')
        response['status'] = 110
        return response
    
    response = HttpResponse(content=data, mimetype='text/plain')
    response['status'] = 100
    return response

#----------------------------------------------------------------------
def __getGroupID(get_teid):
    getsn = str(get_teid).replace("-002", '')
    try:
        dv = device.objects.get(sn=getsn, app__id='200301020003')
        return dv.group_id
    except:
        #can't get device by teid.
        return -1
    
    return -1


#----------------------------------------------------------------------
def __getModifyZoneData(get_version, g_id):
    version = zone_version.objects.latest().version
    data = "#version=%s\n" % version
    
    zone_data_list = zone_data.getDataByVersion(get_version, g_id)
    for item in zone_data_list:
        data = data + item[1] + "\n"
        
    data = data + '#zone end.'
    return data

#----------------------------------------------------------------------
def __getAllZoneData(g_id):
    version = zone_version.objects.latest().version
    data = "#version=%s\n" % version
    
    zone_data_list = zone_data.objects.filter(group_id=g_id, is_delete=False)
    for item in zone_data_list:
        data = data + item.zone_data + "\n"
        
    data = data + '#zone end.'
    return data


#----------------------------------------------------------------------
def getIpset(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not fdns device
    """  
    
    get_id = request.REQUEST.get('id', 10001)
    get_teid = request.REQUEST.get('teid')
    get_type = request.REQUEST.get('type')
    get_version = request.REQUEST.get('version', 0)
    
    #if not get_id or get_id!='10001':
    #    response = HttpResponse(content='#id error', mimetype='text/plain')
    #    response['status'] = 101
    #    return response
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    
    data = ''
    file_object = open(ROOT_PATH+'ipset', 'r')
    try:
        data = file_object.read(20971520)
    finally:
        file_object.close()
    
    response = HttpResponse(content=data, mimetype='text/plain')
    response['status'] = 200
    return response


#----------------------------------------------------------------------
def getTerritory(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not fdns device
    """  
    
    get_id = request.REQUEST.get('id', 10002)
    get_teid = request.REQUEST.get('teid')
    get_type = request.REQUEST.get('type')
    get_version = request.REQUEST.get('version', 0)
    
    #if not get_id or get_id!='10002':
    #    response = HttpResponse(content='#id error', mimetype='text/plain')
    #    response['status'] = 101
    #    return response
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response

    
    data = ''
    file_object = open(ROOT_PATH+'territory', 'r')
    try:
        data = file_object.read(20971520)
    finally:
        file_object.close()
    
    response = HttpResponse(content=data, mimetype='text/plain')
    response['status'] = 200
    return response
    
    


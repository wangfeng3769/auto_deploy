# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
import os,sys,time,string
from  xml.dom import minidom
from scm.common.models import device
from scm.log.models import login,history
from scm.monitor.models import base_state,dns_state,base_state_history,dns_state_history

#----------------------------------------------------------------------
def __checkTeid(get_teid):
    try:
        dv = device.objects.get(sn=get_teid)
        return True
    except:
        #can't get device by teid.
        return False
    
    return False

#----------------------------------------------------------------------
def recvDnsPostData(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not fdns device
    """
    
    get_teid = request.REQUEST.get('teid')
    
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    try:
        dns_data = dns_state.objects.get(device_sn=get_teid)
    except:
        dns_data = dns_state()
        dns_data.device_sn = get_teid
    
    dns_data.run_state = request.REQUEST.get('run_state', 0)
    dns_data.server_state = request.REQUEST.get('server_state', 0)
    dns_data.total_query = request.REQUEST.get('total_query', 0)
    dns_data.ip_max_query = request.REQUEST.get('ip_max_query', 0)
    dns_data.domain_max_query = request.REQUEST.get('domain_max_query', 0) 
    dns_data.hit_query = request.REQUEST.get('hit_query', 0)
    dns_data.recursion_query = request.REQUEST.get('recursion_query', 0)
    dns_data.recursion_time = request.REQUEST.get('recursion_time', 0)
    dns_data.poison_count = request.REQUEST.get('poison_count', 0)
    dns_data.save()
    
    dns_data_history = dns_state_history()
    dns_data_history.device_sn = dns_data.device_sn
    dns_data_history.run_state = dns_data.run_state
    dns_data_history.server_state = dns_data.server_state
    dns_data_history.total_query = dns_data.total_query
    dns_data_history.ip_max_query = dns_data.ip_max_query
    dns_data_history.domain_max_query = dns_data.domain_max_query
    dns_data_history.hit_query = dns_data.hit_query
    dns_data_history.recursion_query = dns_data.recursion_query
    dns_data_history.recursion_time = dns_data.recursion_time
    dns_data_history.poison_count = dns_data.poison_count
    dns_data_history.save()
    
    response = HttpResponse(content="#ok", mimetype='text/plain')
    response['status'] = 100
    return response


#----------------------------------------------------------------------
def recvBasePostData(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not fdns device
    """
    
    get_teid = request.REQUEST.get('teid')
    
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    try:
        base_data = base_state.objects.get(device_sn=get_teid)
    except:
        base_data = base_state()
        base_data.device_sn = get_teid
        
    base_data.cpu = request.REQUEST.get('cpu', 0)
    base_data.mem_total = request.REQUEST.get('mem_total', 0)
    base_data.mem_used = request.REQUEST.get('mem_used', 0)
    base_data.load = request.REQUEST.get('load', 0)
    base_data.out_put = request.REQUEST.get('out_put', 0)
    base_data.in_put = request.REQUEST.get('in_put', 0)
    base_data.connects = request.REQUEST.get('connects', 0)
    base_data.tasks = request.REQUEST.get('tasks', 0)
    base_data.df_use = request.REQUEST.get('df_use', 0)
    base_data.run_time = request.REQUEST.get('run_time', '-')
    base_data.save()

    base_data_history = base_state_history()
    base_data_history.device_sn = base_data.device_sn
    base_data_history.cpu = base_data.cpu
    base_data_history.mem_total = base_data.mem_total
    base_data_history.mem_used = base_data.mem_used
    base_data_history.load = base_data.load
    base_data_history.out_put = base_data.out_put
    base_data_history.in_put = base_data.in_put
    base_data_history.connects = base_data.connects
    base_data_history.tasks = base_data.tasks
    base_data_history.df_use = base_data.df_use
    base_data_history.run_time = base_data.run_time
    base_data_history.save()
    
    response = HttpResponse(content="#ok", mimetype='text/plain')
    response['status'] = 100
    return response


#----------------------------------------------------------------------
def recvLogPostHistory(request):
    test = """
    <?xml version="1.0" encoding="UTF-8"?>
<history>
	<item>
		<command>vi history1.py</command>
		<user>root</user>
		<ip>192.168.2.115</ip>
		<time>2010-11-12 16:55:19</time>
	</item>
	<item>
		<command>ls</command>
		<user>root</user>
		<ip>192.168.2.115</ip>
		<time>2010-11-12 16:55:24</time>
	</item>
	<item>
		<command>vi logagent.py</command>
		<user>root</user>
		<ip>192.168.2.115</ip>
		<time>2010-11-12 16:55:27</time>
	</item>
	<item>
		<command>exit</command>
		<user>root</user>
		<ip>192.168.2.115</ip>
		<time>2010-11-12 16:55:38</time>
	</item>
</history>
            
    """
    
    get_teid = request.REQUEST.get('teid')
    
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    
    if not __checkTeid(get_teid):
        response = HttpResponse(content='#teid is not our device', mimetype='text/plain')
        response['status'] = 103
        return response
    
    history.objects.filter(device_sn=get_teid).delete()    
    mdoc = minidom.parseString(request.raw_post_data.strip())
    #mdoc = minidom.parseString(test.strip())
    mroot = mdoc.childNodes[0]
    for item in mroot.getElementsByTagName("item"):
        history_item = history()
        history_item.device_sn=get_teid
        if item.getElementsByTagName("user")[0].hasChildNodes():
            history_item.username=item.getElementsByTagName("user")[0].childNodes[0].nodeValue
        if item.getElementsByTagName("command")[0].hasChildNodes():    
            history_item.command=item.getElementsByTagName("command")[0].childNodes[0].nodeValue
        if item.getElementsByTagName("time")[0].hasChildNodes():       
            history_item.exec_time=item.getElementsByTagName("time")[0].childNodes[0].nodeValue
        if item.getElementsByTagName("ip")[0].hasChildNodes():       
            history_item.ip=item.getElementsByTagName("ip")[0].childNodes[0].nodeValue
        history_item.save()

    xml="""
         <?xml version="1.0" encoding="UTF-8"?>
           <response>
	    <result>ok</result>
	    <description>ok</description>
           </response>
    """
    return HttpResponse(xml,mimetype="text/xml")


#----------------------------------------------------------------------
def recvLogPostLogin(request):
    test = """
    <?xml version="1.0" encoding="UTF-8"?>
     <login>
        <item>
           <user>root</user>
           <ip>2.2.2.2</ip>
           <port>60</port>
           <time></time>
        </item>
        <item>
           <user>root1</user>
           <ip>2.2.2.2</ip>
           <port>60</port>
           <time></time>
        </item>
        <item>
           <user>root2</user>
           <ip>2.2.2.2</ip>
           <port>60</port>
           <time></time>
        </item>

     </login>
            
    """    
    get_teid = request.REQUEST.get('teid')
    
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response

    if not __checkTeid(get_teid):
        response = HttpResponse(content='#teid is not our device', mimetype='text/plain')
        response['status'] = 103
        return response
    
    #mdoc = minidom.parseString( test.strip() )
    mdoc = minidom.parseString(request.raw_post_data.strip())
    mroot = mdoc.childNodes[0]
    for item in mroot.getElementsByTagName("item"):
        login_item = login()
        login_item.device_sn=get_teid
        if item.getElementsByTagName("user")[0].hasChildNodes():
            login_item.username=item.getElementsByTagName("user")[0].childNodes[0].nodeValue
        if item.getElementsByTagName("ip")[0].hasChildNodes():
            login_item.login_ip=item.getElementsByTagName("ip")[0].childNodes[0].nodeValue
        if item.getElementsByTagName("port")[0].hasChildNodes():
            login_item.login_port=item.getElementsByTagName("port")[0].childNodes[0].nodeValue
        if item.getElementsByTagName("time")[0].hasChildNodes():
            login_item.login_time=item.getElementsByTagName("time")[0].childNodes[0].nodeValue
        login_item.save()

    xml="""
         <?xml version="1.0" encoding="UTF-8"?>
           <response>
	    <result>ok</result>
	    <description>ok</description>
           </response>
    """
    return HttpResponse(xml,mimetype="text/xml")

# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response

from scm.config.blacklist_models import blacklist,blacklist_version,blacklist_data
from scm.common.models import device

#----------------------------------------------------------------------
def getBlacklist(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not fdns device
    """  
    
    get_teid = request.REQUEST.get('teid')
    get_type = request.REQUEST.get('type')
    get_version = request.REQUEST.get('version', 0)
    
    if not get_teid:
        response = HttpResponse(content='#teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    if not get_type or (get_type!='0' and get_type!='1'):
        response = HttpResponse(content='#type error', mimetype='text/plain')
        response['status'] = 103
        return response
    group_id = __getGroupID(get_teid)
    if -1 == group_id:
        response = HttpResponse(content='#teid is not fdns device', mimetype='text/plain')
        response['status'] = 105
        return response
    
    data = ''
    try:
        if get_type=='1':
            data = __getModifyData(get_version, group_id)
        else:
            data = __getAllData(group_id)
    except:
        response = HttpResponse(content='#db error', mimetype='text/plain')
        response['status'] = 110
        return response
    
    response = HttpResponse(content=data, mimetype='text/plain')
    response['status'] = 100
    return response

#----------------------------------------------------------------------
def __getGroupID(get_teid):
    try:
        dv = device.objects.get(sn=get_teid, app__id='200301020003')
        return dv.group_id
    except:
        #can't get device by teid.
        return -1
    
    return -1

#----------------------------------------------------------------------
def __getModifyData(get_version, g_id):
    version = blacklist_version.objects.latest().version
    data = "#version=%s\n" % version
    
    blacklist_data_list = blacklist_data.getDataByVersion(get_version, g_id)
    for item in blacklist_data_list:
        data = data + item[1] + "\n"
        
    data = data + '#blacklist end.'
    return data

#----------------------------------------------------------------------
def __getAllData(g_id):
    version = blacklist_version.objects.latest().version
    data = "#version=%s\n" % version
    
    blacklist_data_list = blacklist_data.getLastData(g_id)
    for item in blacklist_data_list:
        data = data + item[1] + "\n"
        
    data = data + '#blacklist end.'
    return data


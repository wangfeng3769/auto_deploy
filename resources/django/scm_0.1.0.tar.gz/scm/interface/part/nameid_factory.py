# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response

from scm.config.nameid_models import nameid_version,nameid_data
from scm.common.models import device

#----------------------------------------------------------------------
def getNameid(request):
    """
    retrun error code.   in header status:
    101 : id error
    102 : teid error
    103 : type error
    104 : version error
    105 : teid is not dlc device
    """  
    
    get_id = request.REQUEST.get('id', 10001)
    get_teid = request.REQUEST.get('teid')
    get_type = request.REQUEST.get('type')
    get_version = request.REQUEST.get('version', 0)
    get_format = request.REQUEST.get('format', 'dlc')
    
    #if not get_id or get_id!='10001':
    #    response = HttpResponse(content='//id error', mimetype='text/plain')
    #    response['status'] = 101
    #    return response
    if not get_teid:
        response = HttpResponse(content='//teid error', mimetype='text/plain')
        response['status'] = 102
        return response
    if not get_type or (get_type!='0' and get_type!='1'):
        response = HttpResponse(content='//type error', mimetype='text/plain')
        response['status'] = 103
        return response
    
    group_id = __getGroupID(get_teid, get_format)
    if -1 == group_id:
        response = HttpResponse(content='//teid is not dlc or fdns device', mimetype='text/plain')
        response['status'] = 105
        return response
    
    data = ''
    try:
        if get_type=='1':
            data = __getModifyNameidData(get_version, group_id, get_format)
        else:
            data = __getAllNameidData(group_id, get_format)  
    except:
        response = HttpResponse(content='//db error', mimetype='text/plain')
        response['status'] = 110
        return response
        
    response = HttpResponse(content=data, mimetype='text/plain')
    response['status'] = 200
    return response

#----------------------------------------------------------------------
def __getGroupID(get_teid, get_format):
    getsn = get_teid
    appid = 200301020002
    if get_format=='fdns':
        appid=200301020003
        getsn = str(get_teid).replace("-002", '')
    try:
        dv = device.objects.get(sn=getsn, app__id=appid)
        return  dv.group_id
    except:
        #can't get device by teid.
        return -1
    
    return -1

#----------------------------------------------------------------------
def __getModifyNameidData(get_version, g_id, get_format):
    version = nameid_version.objects.latest().version
    if get_format=='fdns':
        data = "#version=%s\n" % version
    else:
        data = "//version=%s\n" % version
        
    nameid_data_list = nameid_data.getDataByVersion(get_version, g_id)
    for item in nameid_data_list:
        if get_format=='fdns':
            data = data + item[2] + "\n"
        else:
            data = data + item[1] + "\n"
        
    if get_format=='fdns':
        data = data + '#nameid end.'
    else:
        data = data + '//nameid end.'
    return data

#----------------------------------------------------------------------
def __getAllNameidData(g_id, get_format):
    version = nameid_version.objects.latest().version
    if get_format=='fdns':
        data = "#version=%s\n" % version
    else:
        data = "//version=%s\n" % version
    
    nameid_data_list = nameid_data.objects.filter(group_id=g_id, is_delete=False)
    for item in nameid_data_list:
        if get_format=='fdns':
            data = data + item.dns_data + "\n"
        else:
            data = data + item.dlc_data + "\n"
        
    if get_format=='fdns':
        data = data + '#nameid end.'
    else:
        data = data + '//nameid end.'
    return data
    
    


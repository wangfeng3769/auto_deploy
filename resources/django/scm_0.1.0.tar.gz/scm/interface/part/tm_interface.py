# Create your views here.
# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.db import connection
import os,sys,time,string
from  xml.dom import minidom
from scm.util.TCSendTask import TCSendTask
from scm.settings import TM_IP

def testTask(request):
    tc = TCSendTask('dns','',0)
    fp = tc.open("dns.conf")
    fp.write("nameid{\n")
    fp.write("}\n")
    
    fp = tc.open("dns.sh")
    fp.write("#/bin/sh\n")
    fp.write("uptime")
    
    # no compress
    
    tc.makeTar()
    tc.send('7777789', TCSendTask.DNS_APP_ID,'test')
    tc.send('xxxx', TCSendTask.DNS_APP_ID,'test')
    
def queryTask(request):
    #testTask(request)
    deviceSn = request.REQUEST.get("teid","")
    appId = request.REQUEST.get("app_id","")
    xmlBegin = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<taskList>"        
    xmlEnd="</taskList>"
    xmlBody = ""
    cursor = connection.cursor()
    if appId!="":
        cursor.execute("select  `id`,app_id,uri_file,file_md5 from common_task_queue where device_sn='%s' and app_id='%s' and status<2"%(deviceSn,appId))
    else:
        cursor.execute("select  `id`,app_id,uri_file,file_md5 from common_task_queue where device_sn='%s' and status<2"%(deviceSn))
        
    row = cursor.fetchone()
    
    """
            <task  id="%s" app_id="%s">
                <attachment md5sum="%s">
                   http://aaa.com/attach/1.tar.gz
                </attachment>
            </task>
            
    """
    taskList = []
    while row:
        xmlBody ="""%s\n
                    <task  id="%s" app_id="%s">
                <attachment md5sum="%s">
                   http://%s/site_media/task_files/%s
                </attachment>
            </task>
            """%(xmlBody,row[0],row[1],row[3],TM_IP,row[2])
        taskList.append(row[0])
        row = cursor.fetchone()
    for taskId in taskList:
        cursor.execute("update common_task_queue set status=%d where `id`=%s"%(1,taskId))
    connection.connection.commit()
    cursor.close()
    return HttpResponse("%s%s%s"%(xmlBegin,xmlBody,xmlEnd),mimetype="text/xml")


def reportTask(request):
    """
    <?xml version="1.0" encoding="UTF-8"?>
     <request>
        <task id="123" teid="06001095C5" result="success" status="finished">
           <progress></progress>
           <returnmessage>0</returnmessage>
           <reporttime>1273047802</reporttime>
        </task>
     </request>
    """
    cur = connection.cursor()
    mdoc = minidom.parseString(request.raw_post_data.strip())
    mroot = mdoc.childNodes[0]
    taskList = mroot.getElementsByTagName("task")
    for task in taskList:
        cur.execute("insert into  common_task_report(task_id,status,result,ta_ip,add_time) values(%s,'%s','%s','%s',now())" 
                    % (task.getAttribute("id"),task.getAttribute("status"),task.getAttribute("result"),request.META['REMOTE_ADDR']) )

        sts = 2 
        if task.getAttribute("result") != "success":
            sts = 3
        cur.execute("update common_task_queue set status=%d where `id`=%s" 
                       % (sts, task.getAttribute("id")))
        
    xml="""
         <?xml version="1.0" encoding="UTF-8"?>
           <response>
	    <result>ok</result>
	    <description>ok</description>
           </response>
    """
    connection.connection.commit()
    cur.close()
    return HttpResponse(xml,mimetype="text/xml")


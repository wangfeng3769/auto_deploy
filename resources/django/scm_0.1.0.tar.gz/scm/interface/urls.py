from django.conf.urls.defaults import *

urlpatterns = patterns('scm.interface.views.zone_view',
     (r'^get/zone/?','index'),
     #(r'^get/nameid/?','scm.interface.nameid_factory.getNameid'),
     #(r'^get/ipset/?','scm.interface.zone_factory.getIpset'),
     #(r'^get/territory/?','scm.interface.zone_factory.getTerritory'),
     #(r'^get/acl/?','scm.interface.acl_factory.getAcl'),
     #(r'^get/blacklist/?','scm.interface.blacklist_factory.getBlacklist'),
     #(r'^post/monitor/base/?','scm.interface.monitor_recver.recvBasePostData'),
     #(r'^post/monitor/dns/?','scm.interface.monitor_recver.recvDnsPostData'),
     #(r'^post/log/history/?','scm.interface.monitor_recver.recvLogPostHistory'),
     #(r'^post/log/login/?','scm.interface.monitor_recver.recvLogPostLogin'),
     #(r'^task/get/?','scm.interface.tm_interface.queryTask'),
     #(r'^task/post/?','scm.interface.tm_interface.reportTask'),
     #(r'^task/test/?','scm.interface.tm_interface.testTask'),
)

urlpatterns += patterns('scm.interface.views.nameid_view',
     (r'^get/nameid/?','index'),
)



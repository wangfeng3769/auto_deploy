# -*- coding:utf8 -*-

from django.http import HttpResponse
from scm.config.zone_models import zone_data
from scm.config.zone_models import zone_version
from scm.common.models import device

def index(request):
    #get_id = request.REQUEST.get('id', 10003)
    #get_teid = request.REQUEST.get('teid')
    #get_type = request.REQUEST.get('type')
    #get_version = request.REQUEST.get('version', 0)

    #if not get_teid:
        #return HttpResponse(content='#teid error', mimetype='text/plain', status=102)

    #if not get_type in ('0', '1'):
        #return HttpResponse(content='#type error', mimetype='text/plain', status=103)

    #group_id = _get_group_id(get_teid)
    #if group_id == -1:
        #return HttpResponse(content='#teid is not fdns device', mimetype='text/plain', status=105)

    #try:
        #if get_type=='1':
            #data = _get_modify_zone_data(get_version, group_id)
            #print data
        #else:
            #data = _get_all_zone_data(group_id)
            #print data
    #except:
        #return HttpResponse(content='#db error', mimetype='text/plain', status=110)

    data = "#version=1\n#nameid end."
    http_response =  HttpResponse(content=data, mimetype='text/plain')
    http_response['status'] = 100
    return http_response
    #return HttpResponse(content=data, mimetype='text/plain')


# -*- coding:utf8 -*-

from django.http import HttpResponse
from scm.config.zone_models import zone_data
from scm.config.zone_models import zone_version
from scm.common.models import device

def index(request):
    get_id = request.REQUEST.get('id', 10003)
    get_teid = request.REQUEST.get('teid')
    get_type = request.REQUEST.get('type')
    get_version = request.REQUEST.get('version', 0)

    if not get_teid:
        return HttpResponse(content='#teid error', mimetype='text/plain', status=102)

    if not get_type in ('0', '1'):
        return HttpResponse(content='#type error', mimetype='text/plain', status=103)

    group_id = _get_group_id(get_teid)
    if group_id == -1:
        return HttpResponse(content='#teid is not fdns device', mimetype='text/plain', status=105)

    try:
        if get_type=='1':
            data = _get_modify_zone_data(get_version, group_id)
            print data
        else:
            data = _get_all_zone_data(group_id)
            print data
    except:
        return HttpResponse(content='#db error', mimetype='text/plain', status=110)

    http_response =  HttpResponse(content=data, mimetype='text/plain')
    http_response['status'] = 100
    return http_response
    #return HttpResponse(content=data, mimetype='text/plain')

def _get_group_id(get_teid):
    getsn = str(get_teid).replace("-002", '')
    try:
        dv = device.objects.get(sn=getsn, app__id='200301020003')
        return dv.group_id
    except:
        pass
    return -1

def _get_modify_zone_data(get_version, g_id):
    version = zone_version.objects.latest().version
    data = "#version=%s\n" % version
    zone_data_list = zone_data.getDataByVersion(get_version, g_id)
    for item in zone_data_list:
        data = data + item[1] + "\n"
    data = data + '#zone end.'
    return data

def _get_all_zone_data(g_id):
    version = zone_version.objects.latest().version
    data = "#version=%s\n" % version
    zone_data_list = zone_data.objects.filter(group_id=g_id, is_delete=False)
    for item in zone_data_list:
        data = data + item.zone_data + "\n"
    data = data + '#zone end.'
    return data


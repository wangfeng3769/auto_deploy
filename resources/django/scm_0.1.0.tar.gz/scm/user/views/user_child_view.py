# -*- coding:utf8 -*-

from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.models import User
from scm.user.models import UserInfo
from scm.user.models import ChildUser
from scm.user.models import User_Power
from scm.util.lukWeb import getUser
from scm.util.decorators import authority_required
from scm.util.json_wrapper import render_to_json
from scm.util.paginator_wrapper import paginate
from scm.util.lukWeb import writeLog
from scm.util import message
from scm.user.helpers.user_child_helper import build_child

@authority_required(100)
def index(request):
    child_name = request.REQUEST.get('username', '')
    ret_info = request.REQUEST.get('ret_info', '')
    page = int(request.REQUEST.get('page', 1))

    user = getUser(request)
    user_power_lst = _query(user, child_name)

    content, pagination = paginate(user_power_lst, page)

    return render_to_response(
                'user/child/index.html',
                {
                    'children':content,
                    'pagination':pagination,
                    'childname':child_name,
                    'ret_info':ret_info
                },
                context_instance = RequestContext(request)
            )

def _query(user, child_name=None):
    power = User_Power.objects.get(user=user).power

    if power == 1000:
        user_power_lst = User_Power.objects.exclude(user=user)
    else:
        child_ids = list(ChildUser.objects.filter(puser=user).values_list('cuser', flat=True))
        user_power_lst = User_Power.objects.filter(user__in=child_ids)

    if child_name:
        try:
            user = User.objects.get(username=child_name)
            user_power_lst = user_power_lst.filter(user=user)
        except:
            return []

    return user_power_lst

@authority_required(100)
@render_to_json()
def show(request):
    child_name = request.REQUEST.get('child_name', '')

    try:
        User.objects.get(username=child_name)
        return {'result':'1'}
    except:
        return {'result':'0'}

@authority_required(100)
def create(request):
    user = getUser(request)
    username = request.REQUEST.get('username','')
    password = request.REQUEST.get('newpwd1','')
    password_2 = request.REQUEST.get('newpwd2','')
    rgroup = request.REQUEST.get('group', '')
    is_email_account = request.REQUEST.get('is_email_account')

    if (username and password and password == password_2) or (username and is_email_account):
        if build_child(username, password, rgroup, user):
            writeLog(user.id, 'user', message.LOG_ADD_USER(username))

            info = message.INFO_ADD_USER_S(username)
        else:
            info = message.INFO_ADD_USER_F(username)
        return HttpResponseRedirect('/user/child/?ret_info=%s' % info)
    return render_to_response('user/child/new.html', context_instance = RequestContext(request))

@authority_required(100)
def delete(request):
    user = getUser(request)
    user_id = request.REQUEST.get('user_id', '')

    try:
        child = User.objects.get(id=user_id)
        child_name = child.username
        child.delete()
    except:
        pass
    writeLog(user.id, 'user', message.LOG_DEL_USER(child_name))

    info = message.INFO_DEL_USER_S(child_name)
    return HttpResponseRedirect('/user/child/?ret_info=%s' % info)


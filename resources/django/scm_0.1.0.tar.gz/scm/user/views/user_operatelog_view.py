# -*- coding:utf8 -*-

from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib.auth.models import User
from scm.user.models import OperateLog
from scm.user.models import User_Power
from scm.util.decorators import authority_required
from scm.user.models import ChildUser
from scm.util.lukWeb import getUser
from scm.util.paginator_wrapper import paginate

@authority_required(10)
def index(request):
    start_time = request.REQUEST.get('start_time', '')
    end_time = request.REQUEST.get('end_time', '')
    operate = request.REQUEST.get('operate', '')
    user_name = request.REQUEST.get('user_name', '')
    page = int(request.REQUEST.get('page', 1))
    user = getUser(request)

    operate_logs = _query(user, start_time, end_time, operate, user_name)
    content, pagination = paginate(operate_logs, page)

    return render_to_response(
                'user/operatelog/index.html',
                {
                    'logs':content,
                    'pagination':pagination,
                    'start_time':start_time,
                    'end_time':end_time,
                    'operate':operate,
                    'user_name':user_name,
                    'condition':'&start_time=%s&end_time=%s&operate=%s&user_name=%s' % (start_time, end_time, operate, user_name)
                },
                context_instance = RequestContext(request)
            )

def _query(user, start_time=None, end_time=None, operate=None, user_name=None):
    power = User_Power.objects.get(user=user).power

    condition = Q()

    if start_time:
        condition &= Q(add_time__gte=start_time)
    if end_time:
        condition &= Q(add_time__lte=end_time)
    if operate:
        condition &= Q(info__contains=operate)
    if user_name:
        try:
            user_name = User.objects.get(username=user_name)
            condition &= Q(user=user_name)
        except:
            return []
            pass

    if power == 1000:
        operate_logs = OperateLog.objects.filter(condition).order_by('-add_time')
    if power == 100:
        child_ids = list(ChildUser.objects.filter(puser=user).values_list('cuser', flat=True))
        child_ids.append(user.id)
        condition &= Q(user__in=child_ids)
        operate_logs = OperateLog.objects.filter(condition).order_by('-add_time')
    if power == 10:
        condition &= Q(user=user)
        operate_logs = OperateLog.objects.filter(condition).order_by('-add_time')

    return operate_logs


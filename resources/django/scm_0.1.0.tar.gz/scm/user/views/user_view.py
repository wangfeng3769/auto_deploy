# -*- coding:utf8 -*-

import os
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from scm.user.models import UserInfo
from scm.util.lukWeb import getUser
from scm.util.lukWeb import writeLog
from scm.util import message
from scm.util.decorators import authority_required
from scm.settings import ROOT_DIR
from shutil import copyfile

@authority_required(100)
def index(request):
    user = getUser(request)
    try:
        userinfo = UserInfo.objects.get(user=user)
    except:
        return HttpResponseRedirect("/user/info/modify")
    return render_to_response('user/user_info.html', {'userinfo':userinfo}, context_instance = RequestContext(request))

@authority_required(100)
def modify(request):
    user = getUser(request)
    try:
        userinfo = UserInfo.objects.get(user=user)
    except:
        userinfo = []
    return render_to_response('user/user_info_modify.html', {'userinfo':userinfo}, context_instance = RequestContext(request))

@authority_required(100)
def update(request):
    contact = request.REQUEST.get('contact','')
    company = request.REQUEST.get('company','')
    url = request.REQUEST.get('url','')
    position = request.REQUEST.get('position','')
    email = request.REQUEST.get('email','')
    telphone = request.REQUEST.get('telphone','')
    cellphone = request.REQUEST.get('cellphone','')
    msn = request.REQUEST.get('msn','')
    gtalk = request.REQUEST.get('gtalk','')
    qq = request.REQUEST.get('qq','')
    address = request.REQUEST.get('address','')
    zipcode = request.REQUEST.get('zipcode','')
    username = request.REQUEST.get('username','')

    user = getUser(request)

    if email:
        user.email = email
        user.save()
    try:
        userinfo = UserInfo.objects.get(user=user)
    except:
        userinfo = UserInfo(user=user)

    userinfo.contact = contact
    userinfo.company = company
    userinfo.url = url
    userinfo.position = position
    userinfo.telphone = telphone
    userinfo.cellphone = cellphone
    userinfo.email = email
    userinfo.msn = msn
    userinfo.gtalk = gtalk
    userinfo.qq = qq
    userinfo.address = address
    userinfo.zipcode = zipcode
    userinfo.save()

    #writeLog(getUser(request).id, 'user', "修改个人信息" )
    return HttpResponseRedirect('/user/info')

@authority_required(100)
def changepwd(request):
    info = request.REQUEST.get('ret_info', '')
    newpwd1 = request.REQUEST.get('newpwd1')
    newpwd2 = request.REQUEST.get('newpwd2')
    oldpwd = request.REQUEST.get('oldpwd','')
    user = getUser(request)

    if request.method.lower() == 'get':
        return render_to_response( 'user/user_password.html', {'ret_info':info}, context_instance = RequestContext(request))

    if not user.check_password(oldpwd):
        info = message.INFO_OLD_PWD_ERROR
        return render_to_response( 'user/user_password.html', {'ret_info':info}, context_instance = RequestContext(request))

    user.set_password(newpwd1)
    user.save()
    #writeLog(getUser(request).id, 'user', "修改密码" )

    return HttpResponseRedirect('/user/info')

### kkk ###
@authority_required(1000)
def logo(request):
    return render_to_response('user/logo.html', context_instance = RequestContext(request))

@authority_required(1000)
def replaceLogo(request):
    fileObj = request.FILES.get('logo', None)
    if fileObj:
        logo_file = os.path.join(ROOT_DIR, 'media/blur_img/top_logo.jpg')

        #logoFile = open('media/blur_img/top_logo.jpg', 'wb')
        logoFile = open(logo_file, 'wb')

        for chunk in fileObj.chunks():
            logoFile.write(chunk)
        logoFile.close()
    else:
        return render_to_response('user/logo.html', {'ret_info':'没有上传LOGO'}, context_instance = RequestContext(request))
    return render_to_response('user/logo.html', {'ret_info':'LOGO更新成功!'}, context_instance = RequestContext(request))

@authority_required(1000)
def recoverDefault(request):
    try:
        copyfile('media/blur_img/top_logo.jpg.bak', 'media/blur_img/top_logo.jpg')
        info = 'LOGO更新成功，请刷新页面!'
    except:
        info = '默认LOGO不存在，请联系管理员'

    return render_to_response('user/logo.html', {'ret_info':info}, context_instance = RequestContext(request))
### kkk ###


from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.db.models import Q
from django.contrib.auth.models import User
from scm.config.models import zone_head
from scm.user.models import User_Power
from scm.util.decorators import authority_required
from scm.user.models import UserZone
from scm.util.json_wrapper import render_to_json
from scm.util.lukWeb import getUser

@authority_required(100)
def index(request):
    child_id = request.REQUEST.get('child_id')
    zone_name = request.REQUEST.get('zone_name')

    zone_head_lst = _query(getUser(request), zone_name)


    child = User.objects.get(id=child_id)
    user_zone_lst = UserZone.objects.filter(user=child).values_list('zone_id', flat=True)

    return render_to_response(
                'user/zone/index.html',
                {'zone_head_lst':zone_head_lst, 'user_zone_lst':user_zone_lst, 'child':child},
                context_instance = RequestContext(request)
            )

def _query(user, zone_name):
    power = User_Power.objects.get(user=user).power

    condition = Q()

    if power != 1000:
        zone_head_ids = list(UserZone.objects.filter(user=user).values_list('zone_id', flat=True))
        condition &= Q(id__in=zone_head_ids)

    if zone_name:
        condition &= Q(zone_name__contains=zone_name)

    zone_head_lst = zone_head.objects.filter(condition).values('id', 'zone_name')

    return zone_head_lst

@authority_required(100)
@render_to_json()
def add(request):
    child_id = request.REQUEST.get('child_id')
    zone_id = request.REQUEST.get('zone_id')

    user = User.objects.get(id=child_id)
    zone = zone_head.objects.get(id=zone_id)
    UserZone.objects.get_or_create(user=user, zone=zone)

    return {'result':'success'}

@authority_required(100)
@render_to_json()
def remove(request):
    child_id = request.REQUEST.get('child_id')
    zone_id = request.REQUEST.get('zone_id')

    try:
        user = User.objects.get(id=child_id)
        zone = zone_head.objects.get(id=zone_id)
        UserZone.objects.get(user=user, zone=zone).delete()
    except:
        pass

    return {'result':'success'}

@authority_required(100)
def add_select(request):
    child_id = request.REQUEST.get('child_id')
    zone_ids = request.REQUEST.get('zone_ids')
    zone_ids = zone_ids.split('|')

    for zone_id in zone_ids:
        user = User.objects.get(id=child_id)
        zone = zone_head.objects.get(id=zone_id)
        UserZone.objects.get_or_create(user=user, zone=zone)

    return HttpResponseRedirect('/user/zone/index?child_id=%s' % child_id)

@authority_required(100)
def remove_select(request):
    zone_ids = request.REQUEST.get('zone_ids')
    child_id = request.REQUEST.get('child_id')
    zone_ids = zone_ids.split('|')


    for zone_id in zone_ids:
        try:
            user = User.objects.get(id=child_id)
            zone = zone_head.objects.get(id=zone_id)
            UserZone.objects.get(user=user, zone=zone).delete()
        except:
            pass

    return HttpResponseRedirect('/user/zone/index?child_id=%s' % child_id)


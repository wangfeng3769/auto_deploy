﻿from django.db import models
from django.contrib.auth.models import User
from scm.config.models import zone_head
# Create your models here.

class UserInfo(models.Model):
    user = models.ForeignKey(User)
    contact = models.CharField(max_length=50, default='', null=True)
    company = models.CharField(max_length=100, default='', null=True)
    url = models.CharField(max_length=200, default='', null=True)
    position = models.CharField(max_length=50, default='', null=True)
    telphone = models.CharField(max_length=20, default='', null=True)
    cellphone = models.CharField(max_length=15, default='', null=True)
    email = models.EmailField(max_length=30, default='', null=True)
    msn = models.CharField(max_length=30, default='', null=True)
    gtalk = models.CharField(max_length=30, default='', null=True)
    qq = models.CharField(max_length=30, default='', null=True)
    address = models.CharField(max_length=200, default='', null=True)
    zipcode = models.CharField(max_length=6, default='', null=True)
    smslimit = models.IntegerField(default=5)

class User_Power(models.Model):
    GROUP = (
            (0, u'系统管理员'),
            (1, u'组织管理员'),
            (2, u'域管理员'),
        )
    POWER = (
        (0, 1000),
        (1, 100),
        (2, 10),
        )

    user = models.ForeignKey(User)
    group = models.CharField(max_length=16, choices=GROUP, default='域管理员')
    power = models.IntegerField(choices=POWER, default=10)

class ChildUser(models.Model):
    puser = models.ForeignKey(User, related_name='puser')
    cuser = models.ForeignKey(User, related_name='cuser')
    add_time = models.DateTimeField(auto_now_add=True)

class DeviceInfo(models.Model):
    user=models.ForeignKey(User)
    name = models.CharField(max_length=25,blank=True,default='')
    sn=models.CharField(max_length=15,blank=True,default='')
    ip=models.IPAddressField(blank=True)
    ipset=models.CharField(max_length=16,blank=True,default='')
    add_time=models.DateTimeField(auto_now=True)

class OperateLog(models.Model):
    Service_Type = (
            (0, u'解析组管理'),
            (1, u'设备管理'),
            (2, u'智能解析'),
            (3, u'域名管理'),
            (4, u'访问控制'),
            (5, u'白名单'),
            (6, u'黑名单'),
            (7, u'DNS设备操作'),
            (8, u'告警配置'),
            (9, u'用户操作'),
    )

    user=models.ForeignKey(User)
    service=models.IntegerField(default=0, choices=Service_Type)
    info = models.CharField(max_length=128, default='')
    add_time = models.DateTimeField(auto_now_add=True)

class UserZone(models.Model):
    user = models.ForeignKey(User)
    zone = models.ForeignKey(zone_head)


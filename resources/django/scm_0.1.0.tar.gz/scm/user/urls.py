from django.conf.urls.defaults import *

urlpatterns = patterns('scm.user.views.user_view',
     (r'^$', 'index'),
     (r'^info/$','index'),
     (r'^info/update','update'),
     (r'^info/modify','modify'),
     (r'^changepwd','changepwd'),
     (r'^logo/$','logo'),
     (r'^logo_replace/$','replaceLogo'),
     (r'^logo_default/$','recoverDefault'),
)

urlpatterns += patterns('scm.user.views.user_child_view',
     (r'^child/$', 'index'),
     (r'^child/query?','index'),
     (r'^child/show?','show'),
     (r'^child/add/$', 'create'),
     (r'^child/delete/?', 'delete'),
)

urlpatterns += patterns('scm.user.views.user_zone_view',
     (r'^zone/index','index'),
     (r'^zone/add/$','add'),
     (r'^zone/del','remove'),
     (r'^zone/removeSelect','remove_select'),
     (r'^zone/addSelect','add_select'),
)


# -*- coding:utf8 -*-

from django.contrib.auth.models import User
from scm.user.models import ChildUser
from scm.user.models import User_Power

def build_child(username, password, group, p_user):
    try:
        child = User.objects.get(username=username)
        result = False
    except User.DoesNotExist:
        child = User(username=username)
        if password:
            child.set_password(password)
        else:
            child.set_unusable_password()
        child.save()

        User_Power.objects.create(
            user_id=child.id,
            group=User_Power.GROUP[int(group)][1],
            power=User_Power.POWER[int(group)][1]
        )

        ChildUser.objects.create(cuser=child, puser=p_user)
        result = True

    return result


from django.conf.urls.defaults import *

urlpatterns = patterns('scm.user.views.user_operatelog_view',
     (r'^$','index'),
     (r'^query/$','index'),
)

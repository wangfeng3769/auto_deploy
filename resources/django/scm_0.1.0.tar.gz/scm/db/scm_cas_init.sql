-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: scm_cas
-- ------------------------------------------------------
-- Server version	5.1.49-1ubuntu8.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_425ae3c4` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_message`
--

DROP TABLE IF EXISTS `auth_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_message_403f60f` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_message`
--

LOCK TABLES `auth_message` WRITE;
/*!40000 ALTER TABLE `auth_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add message',4,'add_message'),(11,'Can change message',4,'change_message'),(12,'Can delete message',4,'delete_message'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add base_state',8,'add_base_state'),(23,'Can change base_state',8,'change_base_state'),(24,'Can delete base_state',8,'delete_base_state'),(25,'Can add dns_state',9,'add_dns_state'),(26,'Can change dns_state',9,'change_dns_state'),(27,'Can delete dns_state',9,'delete_dns_state'),(28,'Can add dlc_state',10,'add_dlc_state'),(29,'Can change dlc_state',10,'change_dlc_state'),(30,'Can delete dlc_state',10,'delete_dlc_state'),(31,'Can add base_state_history',11,'add_base_state_history'),(32,'Can change base_state_history',11,'change_base_state_history'),(33,'Can delete base_state_history',11,'delete_base_state_history'),(34,'Can add dns_state_history',12,'add_dns_state_history'),(35,'Can change dns_state_history',12,'change_dns_state_history'),(36,'Can delete dns_state_history',12,'delete_dns_state_history'),(37,'Can add zone_head',13,'add_zone_head'),(38,'Can change zone_head',13,'change_zone_head'),(39,'Can delete zone_head',13,'delete_zone_head'),(40,'Can add zone_record',14,'add_zone_record'),(41,'Can change zone_record',14,'change_zone_record'),(42,'Can delete zone_record',14,'delete_zone_record'),(43,'Can add zone_template',15,'add_zone_template'),(44,'Can change zone_template',15,'change_zone_template'),(45,'Can delete zone_template',15,'delete_zone_template'),(46,'Can add zone_version',16,'add_zone_version'),(47,'Can change zone_version',16,'change_zone_version'),(48,'Can delete zone_version',16,'delete_zone_version'),(49,'Can add zone_data',17,'add_zone_data'),(50,'Can change zone_data',17,'change_zone_data'),(51,'Can delete zone_data',17,'delete_zone_data'),(52,'Can add zone_file',18,'add_zone_file'),(53,'Can change zone_file',18,'change_zone_file'),(54,'Can delete zone_file',18,'delete_zone_file'),(55,'Can add 解析组',19,'add_group'),(56,'Can change 解析组',19,'change_group'),(57,'Can delete 解析组',19,'delete_group'),(58,'Can add 应用',20,'add_application'),(59,'Can change 应用',20,'change_application'),(60,'Can delete 应用',20,'delete_application'),(61,'Can add 设备',21,'add_device'),(62,'Can change 设备',21,'change_device'),(63,'Can delete 设备',21,'delete_device'),(64,'Can add ipset_location',22,'add_ipset_location'),(65,'Can change ipset_location',22,'change_ipset_location'),(66,'Can delete ipset_location',22,'delete_ipset_location'),(67,'Can add ipset_head',23,'add_ipset_head'),(68,'Can change ipset_head',23,'change_ipset_head'),(69,'Can delete ipset_head',23,'delete_ipset_head'),(70,'Can add ipset_body',24,'add_ipset_body'),(71,'Can change ipset_body',24,'change_ipset_body'),(72,'Can delete ipset_body',24,'delete_ipset_body'),(73,'Can add backup',25,'add_backup'),(74,'Can change backup',25,'change_backup'),(75,'Can delete backup',25,'delete_backup'),(76,'Can add zone',26,'add_zone'),(77,'Can change zone',26,'change_zone'),(78,'Can delete zone',26,'delete_zone'),(79,'Can add task',27,'add_task'),(80,'Can change task',27,'change_task'),(81,'Can delete task',27,'delete_task'),(82,'Can add user info',28,'add_userinfo'),(83,'Can change user info',28,'change_userinfo'),(84,'Can delete user info',28,'delete_userinfo'),(85,'Can add user_ power',29,'add_user_power'),(86,'Can change user_ power',29,'change_user_power'),(87,'Can delete user_ power',29,'delete_user_power'),(88,'Can add child user',30,'add_childuser'),(89,'Can change child user',30,'change_childuser'),(90,'Can delete child user',30,'delete_childuser'),(91,'Can add device info',31,'add_deviceinfo'),(92,'Can change device info',31,'change_deviceinfo'),(93,'Can delete device info',31,'delete_deviceinfo'),(94,'Can add operate log',32,'add_operatelog'),(95,'Can change operate log',32,'change_operatelog'),(96,'Can delete operate log',32,'delete_operatelog'),(97,'Can add user zone',33,'add_userzone'),(98,'Can change user zone',33,'change_userzone'),(99,'Can delete user zone',33,'delete_userzone');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'admin','','','admin@chinacache.com','sha1$e349d$b0429e3198695f964a24b7cbc63eccf3b6c8de78',1,1,1,'2011-12-27 15:55:16','2011-12-27 14:56:44');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_403f60f` (`user_id`),
  KEY `auth_user_groups_425ae3c4` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_403f60f` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_backup`
--

DROP TABLE IF EXISTS `backup_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `detail` longtext NOT NULL,
  `type` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_backup`
--

LOCK TABLES `backup_backup` WRITE;
/*!40000 ALTER TABLE `backup_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_task`
--

DROP TABLE IF EXISTS `backup_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `detail` varchar(128) NOT NULL,
  `type` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_task`
--

LOCK TABLES `backup_task` WRITE;
/*!40000 ALTER TABLE `backup_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_zone`
--

DROP TABLE IF EXISTS `backup_zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_zone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `head_file` varchar(256) NOT NULL,
  `record_file` varchar(256) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_zone_694f4314` (`backup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_zone`
--

LOCK TABLES `backup_zone` WRITE;
/*!40000 ALTER TABLE `backup_zone` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_zone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_application`
--

DROP TABLE IF EXISTS `common_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_application` (
  `id` varchar(16) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cn_name` varchar(30) NOT NULL,
  `short_name` varchar(30) NOT NULL,
  `note` longtext NOT NULL,
  `add_time` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_application`
--

LOCK TABLES `common_application` WRITE;
/*!40000 ALTER TABLE `common_application` DISABLE KEYS */;
INSERT INTO `common_application` VALUES ('200301020003','FlexiDNS','DNS','FDNS','','0000-00-00');
/*!40000 ALTER TABLE `common_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_device`
--

DROP TABLE IF EXISTS `common_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `app_id` varchar(16) NOT NULL,
  `hostname` varchar(32) NOT NULL,
  `mip` varchar(15) NOT NULL,
  `sn` varchar(16) NOT NULL,
  `card_num` int(11) NOT NULL,
  `iplist` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `mac` varchar(17) NOT NULL,
  `os` varchar(17) NOT NULL,
  `note` longtext NOT NULL,
  `add_time` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `common_device_425ae3c4` (`group_id`),
  KEY `common_device_269da59a` (`app_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_device`
--

LOCK TABLES `common_device` WRITE;
/*!40000 ALTER TABLE `common_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_group`
--

DROP TABLE IF EXISTS `common_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `can_modify` int(11) NOT NULL,
  `note` longtext NOT NULL,
  `add_time` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_group`
--

LOCK TABLES `common_group` WRITE;
/*!40000 ALTER TABLE `common_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_ipset_body`
--

DROP TABLE IF EXISTS `common_ipset_body`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_ipset_body` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipset_head_id` int(11) NOT NULL,
  `cidr` varchar(20) NOT NULL,
  `ipbegin` int(10) unsigned NOT NULL,
  `ipend` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `common_ipset_body_766677ac` (`ipset_head_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_ipset_body`
--

LOCK TABLES `common_ipset_body` WRITE;
/*!40000 ALTER TABLE `common_ipset_body` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_ipset_body` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_ipset_head`
--

DROP TABLE IF EXISTS `common_ipset_head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_ipset_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `group` varchar(32) NOT NULL,
  `grade` varchar(32) NOT NULL,
  `country` varchar(32) NOT NULL,
  `isp` varchar(32) NOT NULL,
  `region` varchar(32) NOT NULL,
  `province` varchar(32) NOT NULL,
  `city` varchar(32) NOT NULL,
  `info` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_ipset_head`
--

LOCK TABLES `common_ipset_head` WRITE;
/*!40000 ALTER TABLE `common_ipset_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_ipset_head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `common_ipset_location`
--

DROP TABLE IF EXISTS `common_ipset_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_ipset_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipset` varchar(16) NOT NULL,
  `location` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ipset` (`ipset`),
  UNIQUE KEY `location` (`location`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_ipset_location`
--

LOCK TABLES `common_ipset_location` WRITE;
/*!40000 ALTER TABLE `common_ipset_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_ipset_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_zone_data`
--

DROP TABLE IF EXISTS `config_zone_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_zone_data` (
  `zone_head_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `zone_name` varchar(64) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  `zone_data` longtext NOT NULL,
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`zone_head_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_zone_data`
--

LOCK TABLES `config_zone_data` WRITE;
/*!40000 ALTER TABLE `config_zone_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_zone_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_zone_file`
--

DROP TABLE IF EXISTS `config_zone_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_zone_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `config_zone_file_403f60f` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_zone_file`
--

LOCK TABLES `config_zone_file` WRITE;
/*!40000 ALTER TABLE `config_zone_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_zone_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_zone_head`
--

DROP TABLE IF EXISTS `config_zone_head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_zone_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `zone_name` varchar(128) NOT NULL,
  `ttl` varchar(16) NOT NULL,
  `master_host` varchar(32) NOT NULL,
  `master_email` varchar(32) NOT NULL,
  `sn` varchar(32) NOT NULL,
  `ttl_refresh` varchar(8) NOT NULL,
  `ttl_retry` varchar(8) NOT NULL,
  `ttl_expire` varchar(8) NOT NULL,
  `mix_ttl` varchar(8) NOT NULL,
  `record_count` int(11) NOT NULL,
  `enable_record_count` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `add_time` datetime NOT NULL,
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`zone_name`),
  KEY `config_zone_head_425ae3c4` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_zone_head`
--

LOCK TABLES `config_zone_head` WRITE;
/*!40000 ALTER TABLE `config_zone_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_zone_head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_zone_record`
--

DROP TABLE IF EXISTS `config_zone_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_zone_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_head_id` int(11) NOT NULL,
  `record_name` varchar(128) NOT NULL,
  `record_type` int(11) NOT NULL,
  `mx_preced` int(11) NOT NULL,
  `ttl` varchar(16) NOT NULL,
  `value` varchar(128) NOT NULL,
  `status` int(11) NOT NULL,
  `can_modify` int(11) NOT NULL,
  `add_time` datetime NOT NULL,
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `config_zone_record_65abd54a` (`zone_head_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_zone_record`
--

LOCK TABLES `config_zone_record` WRITE;
/*!40000 ALTER TABLE `config_zone_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_zone_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_zone_template`
--

DROP TABLE IF EXISTS `config_zone_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_zone_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_name` varchar(128) NOT NULL,
  `record_type` int(11) NOT NULL,
  `mx_preced` int(11) NOT NULL,
  `ttl` varchar(16) NOT NULL,
  `value` varchar(128) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_zone_template`
--

LOCK TABLES `config_zone_template` WRITE;
/*!40000 ALTER TABLE `config_zone_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_zone_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_zone_version`
--

DROP TABLE IF EXISTS `config_zone_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config_zone_version` (
  `version` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `zone_head_id` int(11) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_zone_version`
--

LOCK TABLES `config_zone_version` WRITE;
/*!40000 ALTER TABLE `config_zone_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_zone_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'permission','auth','permission'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'message','auth','message'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(7,'site','sites','site'),(8,'base_state','monitor','base_state'),(9,'dns_state','monitor','dns_state'),(10,'dlc_state','monitor','dlc_state'),(11,'base_state_history','monitor','base_state_history'),(12,'dns_state_history','monitor','dns_state_history'),(13,'zone_head','config','zone_head'),(14,'zone_record','config','zone_record'),(15,'zone_template','config','zone_template'),(16,'zone_version','config','zone_version'),(17,'zone_data','config','zone_data'),(18,'zone_file','config','zone_file'),(19,'解析组','common','group'),(20,'应用','common','application'),(21,'设备','common','device'),(22,'ipset_location','common','ipset_location'),(23,'ipset_head','common','ipset_head'),(24,'ipset_body','common','ipset_body'),(25,'backup','backup','backup'),(26,'zone','backup','zone'),(27,'task','backup','task'),(28,'user info','user','userinfo'),(29,'user_ power','user','user_power'),(30,'child user','user','childuser'),(31,'device info','user','deviceinfo'),(32,'operate log','user','operatelog'),(33,'user zone','user','userzone');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('af38e2dd61a5e36eb7160e97c06df642','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5k\ncy5Nb2RlbEJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEBdS4xNDBkMmM0NGQ2YTY3ZmJhODc2\nNzE0Zjk0NDczMTcwOQ==\n','2012-01-10 15:55:16');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_base_state`
--

DROP TABLE IF EXISTS `monitor_base_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_base_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_sn` varchar(16) NOT NULL,
  `cpu` int(11) NOT NULL,
  `mem_total` int(11) NOT NULL,
  `mem_used` int(11) NOT NULL,
  `load` double NOT NULL,
  `out_put` int(11) NOT NULL,
  `in_put` int(11) NOT NULL,
  `connects` int(11) NOT NULL,
  `tasks` int(11) NOT NULL,
  `df_use` int(11) NOT NULL,
  `run_time` varchar(32) NOT NULL,
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_sn` (`device_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_base_state`
--

LOCK TABLES `monitor_base_state` WRITE;
/*!40000 ALTER TABLE `monitor_base_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor_base_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_base_state_history`
--

DROP TABLE IF EXISTS `monitor_base_state_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_base_state_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_sn` varchar(16) NOT NULL,
  `cpu` int(11) NOT NULL,
  `mem_total` int(11) NOT NULL,
  `mem_used` int(11) NOT NULL,
  `load` double NOT NULL,
  `out_put` int(11) NOT NULL,
  `in_put` int(11) NOT NULL,
  `connects` int(11) NOT NULL,
  `tasks` int(11) NOT NULL,
  `df_use` int(11) NOT NULL,
  `run_time` varchar(32) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_base_state_history`
--

LOCK TABLES `monitor_base_state_history` WRITE;
/*!40000 ALTER TABLE `monitor_base_state_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor_base_state_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_dlc_state`
--

DROP TABLE IF EXISTS `monitor_dlc_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_dlc_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_sn` varchar(16) NOT NULL,
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_sn` (`device_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_dlc_state`
--

LOCK TABLES `monitor_dlc_state` WRITE;
/*!40000 ALTER TABLE `monitor_dlc_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor_dlc_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_dns_state`
--

DROP TABLE IF EXISTS `monitor_dns_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_dns_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_sn` varchar(16) NOT NULL,
  `run_state` int(11) NOT NULL,
  `server_state` int(11) NOT NULL,
  `total_query` int(11) NOT NULL,
  `ip_max_query` int(11) NOT NULL,
  `domain_max_query` int(11) NOT NULL,
  `hit_query` int(11) NOT NULL,
  `recursion_query` int(11) NOT NULL,
  `recursion_time` int(11) NOT NULL,
  `poison_count` int(11) NOT NULL,
  `modify_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_sn` (`device_sn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_dns_state`
--

LOCK TABLES `monitor_dns_state` WRITE;
/*!40000 ALTER TABLE `monitor_dns_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor_dns_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_dns_state_history`
--

DROP TABLE IF EXISTS `monitor_dns_state_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_dns_state_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_sn` varchar(16) NOT NULL,
  `run_state` int(11) NOT NULL,
  `server_state` int(11) NOT NULL,
  `total_query` int(11) NOT NULL,
  `ip_max_query` int(11) NOT NULL,
  `domain_max_query` int(11) NOT NULL,
  `hit_query` int(11) NOT NULL,
  `recursion_query` int(11) NOT NULL,
  `recursion_time` int(11) NOT NULL,
  `poison_count` int(11) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_dns_state_history`
--

LOCK TABLES `monitor_dns_state_history` WRITE;
/*!40000 ALTER TABLE `monitor_dns_state_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `monitor_dns_state_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_childuser`
--

DROP TABLE IF EXISTS `user_childuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_childuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puser_id` int(11) NOT NULL,
  `cuser_id` int(11) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_childuser_421758fc` (`puser_id`),
  KEY `user_childuser_21f60f51` (`cuser_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_childuser`
--

LOCK TABLES `user_childuser` WRITE;
/*!40000 ALTER TABLE `user_childuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_childuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_deviceinfo`
--

DROP TABLE IF EXISTS `user_deviceinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_deviceinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `sn` varchar(15) NOT NULL,
  `ip` char(15) NOT NULL,
  `ipset` varchar(16) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_deviceinfo_403f60f` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_deviceinfo`
--

LOCK TABLES `user_deviceinfo` WRITE;
/*!40000 ALTER TABLE `user_deviceinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_deviceinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_operatelog`
--

DROP TABLE IF EXISTS `user_operatelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_operatelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `service` int(11) NOT NULL,
  `info` varchar(128) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_operatelog_403f60f` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_operatelog`
--

LOCK TABLES `user_operatelog` WRITE;
/*!40000 ALTER TABLE `user_operatelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_operatelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_user_power`
--

DROP TABLE IF EXISTS `user_user_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_user_power` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group` varchar(16) NOT NULL,
  `power` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_user_power_403f60f` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_user_power`
--

LOCK TABLES `user_user_power` WRITE;
/*!40000 ALTER TABLE `user_user_power` DISABLE KEYS */;
INSERT INTO `user_user_power` VALUES (1,1,'系统管理员',1000);
/*!40000 ALTER TABLE `user_user_power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_userinfo`
--

DROP TABLE IF EXISTS `user_userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `telphone` varchar(20) DEFAULT NULL,
  `cellphone` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `msn` varchar(30) DEFAULT NULL,
  `gtalk` varchar(30) DEFAULT NULL,
  `qq` varchar(30) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `zipcode` varchar(6) DEFAULT NULL,
  `smslimit` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_userinfo_403f60f` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_userinfo`
--

LOCK TABLES `user_userinfo` WRITE;
/*!40000 ALTER TABLE `user_userinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_userzone`
--

DROP TABLE IF EXISTS `user_userzone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_userzone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_userzone_403f60f` (`user_id`),
  KEY `user_userzone_2957a812` (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_userzone`
--

LOCK TABLES `user_userzone` WRITE;
/*!40000 ALTER TABLE `user_userzone` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_userzone` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-12-27 15:59:33

from django.conf.urls.defaults import *
from scm.modules.signals import update_zone_data
from scm import settings

# Uncomment the next two lines to enable the admin:
#from django.contrib import admin
#admin.autodiscover()

urlpatterns = patterns('',
    # Example:
    # (r'^scm/', include('scm.foo.urls')),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs' 
    # to INSTALLED_APPS to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    #(r'^admin/', include(admin.site.urls)),
    #(r'^admin/(.*)', admin.site.root),

    (r'^site_media/(?P<path>.*)$', 'django.views.static.serve',{'document_root': settings.STATIC_PATH}),

    (r'^$', 'django.contrib.auth.views.login'),
    (r'^accounts/login/$', 'django.contrib.auth.views.login'),
    (r'^accounts/logout/$', 'django.contrib.auth.views.logout_then_login'),
    (r'^accounts/profile/$', 'scm.config.views.zone.zone_head_view.index'),

    #(r'^monitor/', include('scm.monitor.urls')),
    #(r'^config/', include('scm.config.urls')),
    #(r'^alarm/', include('scm.alarm.urls')),
    #(r'^log/', include('scm.log.urls')),

    (r'^common/', include('scm.common.urls')),
    (r'^zone/', include('scm.config.urls_zone')),
    (r'^backup/', include('scm.backup.urls')),
    (r'^user/', include('scm.user.urls')),
    (r'^operatelog/', include('scm.user.urls_operatelog')),

    (r'^interface/', include('scm.interface.urls')),
    (r'^auth', 'scm.auth.views.check_user'),
)


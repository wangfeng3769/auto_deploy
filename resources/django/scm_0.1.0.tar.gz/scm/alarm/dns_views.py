# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage
from scm.common.models import group,device,application
from scm.alarm.models import dns_threshold
import simplejson
import urllib2
from scm.util.decorators import authority_required

# webluker login main page
@login_required
def index(request):
    return listDns(request)

@authority_required(100)
def listDns(request):
    ret_info = request.REQUEST.get('ret_info', '')
    dns_list = dns_threshold.objects.all()
    
    return render_to_response('alarm/dns/dns_list.html', {'ret_info':ret_info, 'dns_list':dns_list}, context_instance = RequestContext(request))

@authority_required(100)
def editDnsPage(request):
    dns_id = request.REQUEST.get('dns_id', '')
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')
    try:
        dns_data = dns_threshold.objects.get(id=dns_id)
        # error , zone is exist.
    except:
        return listDns(request)
    
    return render_to_response('alarm/dns/dns_edit.html', {'rapp':rapp,'rgroup':rgroup,'ret_info':'','dns_data':dns_data}, context_instance = RequestContext(request))

@authority_required(100)
def saveDns(request):
    dns_id = request.REQUEST.get('dns_id', '')
    
    try:
        dvc = dns_threshold.objects.get(id=dns_id)
        dvc.total_query = request.REQUEST.get('total_query', '0')
	dvc.ip_max_query = request.REQUEST.get('ip_max_query', '0')
	dvc.domain_max_query = request.REQUEST.get('domain_max_query', '0')
	dvc.recursion_query = request.REQUEST.get('recursion_query', '0')
	dvc.recursion_time = request.REQUEST.get('recursion_time', '0')
	dvc.poison_count = request.REQUEST.get('poison_count', '0')

        dvc.save()
    except:
        return render_to_response('alarm/dns/dns_edit.html', {'ret_info':'找不到解析组！'}, context_instance = RequestContext(request))
    
    #writeLog(getUser(request).id, 22, "修改解析组[ %s ] %s" % ip.encode('utf8'), inf)
    info = "解析组[ %s ]保存成功！" % dvc.group.name.encode('utf8')
    return HttpResponseRedirect('/alarm/dns/list_dns/?&ret_info=%s' % (urllib2.quote( info )))

# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.db import models
from scm.common.models import *
from scm.monitor.models import *

class smtp(models.Model):
    host = models.CharField(max_length=255, unique=True)
    user = models.CharField(max_length=255)
    passwd = models.CharField(max_length=255)
    alias = models.CharField(max_length=255)
    titel = models.CharField(max_length=255)
    modify_time = models.DateTimeField(auto_now=True)

class recver(models.Model):
    name = models.CharField(max_length=16, unique=True)
    group_list = models.CharField(max_length=255)
    app_list = models.CharField(max_length=255)
    email = models.CharField(max_length=32)
    phone = models.CharField(max_length=32)
    msn = models.CharField(max_length=32)
    qq = models.CharField(max_length=32)
    modify_time = models.DateTimeField(auto_now=True)

class base_threshold(models.Model):
    group = models.ForeignKey(group)
    cpu = models.IntegerField(default=100)
    mem_left = models.IntegerField(default=100)
    load = models.IntegerField(default=4)
    out_put = models.IntegerField(default=1000)
    in_put = models.IntegerField(default=1000)
    connects = models.IntegerField(default=1000)
    tasks = models.IntegerField(default=100)
    df_use = models.IntegerField(default=95)

class dns_threshold(models.Model):
    group = models.ForeignKey(group)
    total_query = models.IntegerField(default=100000,verbose_name=u'总解析数')
    ip_max_query = models.IntegerField(default=10000,verbose_name=u'IP最大解析数')
    domain_max_query = models.IntegerField(default=10000,verbose_name=u'域名最大解析数')
    hit_query = models.IntegerField(default=1000,verbose_name=u'命中查询')
    recursion_query = models.IntegerField(default=1000,verbose_name=u'递归次数')
    recursion_time = models.IntegerField(default=6000,verbose_name=u'递归延时')
    poison_count = models.IntegerField(default=100,verbose_name=u'投毒数')

from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

from scm import settings

urlpatterns = patterns('',
     (r'^$','scm.alarm.recver_views.listRecver'),
     (r'^index/$','scm.alarm.recver_views.listRecver'),
     
     (r'^smtp/index$','scm.alarm.recver_views.editSmtp'),
     (r'^smtp/save/$','scm.alarm.recver_views.saveSmtp'),
     (r'^smtp/test/$','scm.alarm.recver_views.testSmtp'),
     (r'^smtp/detect/$','scm.alarm.recver_views.runDetect'),
     
     (r'^recver/index$','scm.alarm.recver_views.listRecver'),
     (r'^recver/add_recver_page/$','scm.alarm.recver_views.addRecverPage'),
     (r'^recver/edit_recver_page/?','scm.alarm.recver_views.editRecverPage'),
     (r'^recver/save_recver/?','scm.alarm.recver_views.saveRecver'),
     (r'^recver/del_recver/?','scm.alarm.recver_views.delRecver'),
     (r'^recver/add_recver/?','scm.alarm.recver_views.addRecver'),
     (r'^recver/list_recver/?','scm.alarm.recver_views.listRecver'),
     
     (r'^base/index$','scm.alarm.base_views.listBase'),
     (r'^base/edit_base_page/?','scm.alarm.base_views.editBasePage'),
     (r'^base/save_base/?','scm.alarm.base_views.saveBase'),
     (r'^base/list_base/?','scm.alarm.base_views.listBase'),
     
     (r'^dns/index$','scm.alarm.dns_views.listDns'),
     (r'^dns/edit_dns_page/?','scm.alarm.dns_views.editDnsPage'),
     (r'^dns/save_dns/?','scm.alarm.dns_views.saveDns'),
     (r'^dns/list_dns/?','scm.alarm.dns_views.listDns'),
)



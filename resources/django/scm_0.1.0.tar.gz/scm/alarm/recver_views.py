# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.template import RequestContext
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage
from scm.util.sendmail import CCSendMail
from scm.alarm.models import recver,smtp
from scm.common.models import group,device,application
import simplejson
import urllib2
from scm.util.decorators import authority_required

@authority_required(100)
def index(request):
    return render_to_response('alarm/index.html', {}, context_instance = RequestContext(request))

@authority_required(100)
def editSmtp(request):
    smtp_list = smtp.objects.all()
    
    return render_to_response('alarm/smtp_edit.html', {'ret_info':'','smtp':smtp_list[0]}, context_instance = RequestContext(request))

@authority_required(1000)
def saveSmtp(request):
    rhost = request.REQUEST.get('host', '')
    ruser = request.REQUEST.get('user', '')
    rpasswd = request.REQUEST.get('password', '')
    ralias = request.REQUEST.get('alias', '')
    rtitel = request.REQUEST.get('titel', '')
    
    smtp_list = smtp.objects.all()
    for item in smtp_list:
        item.host = rhost
        item.user = ruser
        item.passwd = rpasswd
        item.alias = ralias
        item.titel = rtitel
        item.save()
    
    writeLog(getUser(request).id, 'alarm', "修改smtp服务器为%s" % rhost.encode('utf8') )
    return render_to_response('alarm/smtp_edit.html', {'ret_info':u'保存成功','smtp':smtp_list[0]}, context_instance = RequestContext(request))

@authority_required(1000)
def runDetect(request):
    from scm.alarm_detector import runDetector,clearMonitorHistory

    clearMonitorHistory()
    #runDetector()
    
    data = {}
    data['ret_josn']='ok'
            
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def testSmtp(request):
    email = request.REQUEST.get('email', '')
        
    smtp_list = smtp.objects.all()
    
    send=CCSendMail(smtp_list[0].host, smtp_list[0].user, smtp_list[0].passwd)
    send.setFromAlias(u"邮件告警模块")
    send.sendHtml(email, u'ChinaCache-SSR测试邮件', u'如果您收到这封邮件，说明您配置的邮件服务器没有问题。')
    
    data = {}
    data['ret_josn']='ok'
            
    return HttpResponse(simplejson.dumps(data))

@authority_required(100)
def listRecver(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rname = request.REQUEST.get('rname', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
    
    recvers = recver.objects.all()
    if len(rapp)!=0:
        recvers = recvers.filter(app_list__contains=rapp)
    if len(rgroup)!=0:
        recvers = recvers.filter(group_list__contains=rgroup)
    if len(rname)!=0:
        recvers = recvers.filter(name__contains=rname)
        
    group_list = group.objects.all()
    app_list = application.objects.all()    
        
    if hits:
        pagination = split_page(hits, '/alarm/recver/list_recver/?rapp=%s&rname=%s&rgroup=%s&'% \
                                (rapp, rname, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(recvers.count(), '/alarm/recver/list_recver/?rapp=%s&rname=%s&rgroup=%s&'% \
                                (rapp, rname, rgroup), \
                                results_per_page, page)
        
    return render_to_response('alarm/recver/recver_list.html', {'rapp':rapp, 'rname':rname,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'app_list':app_list,'recver_list':recvers[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))


@authority_required(100)
def addRecverPage(request):
    group_list = group.objects.all()
    app_list = application.objects.all()  
    
    return render_to_response('alarm/recver/recver_add.html', {'ret_info':'','group_list':group_list,'app_list':app_list}, context_instance = RequestContext(request))

@authority_required(100)
def editRecverPage(request):
    recver_id = request.REQUEST.get('recver_id', '')
    try:
        recver_data = recver.objects.get(id=recver_id)
        # error , zone is exist.
    except:
        return listrecver(request)
    
    group_list = group.objects.all()
    app_list = application.objects.all() 
    
    return render_to_response('alarm/recver/recver_edit.html', {'group_list':group_list,'app_list':app_list,'ret_info':'','recver_data':recver_data}, context_instance = RequestContext(request))

@authority_required(100)
def saveRecver(request):
    recver_id = request.REQUEST.get('recver_id', '')
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    phone = request.REQUEST.get('phone', '')
    name = request.REQUEST.get('name', '')
    email = request.REQUEST.get('email', '')
    msn = request.REQUEST.get('msn', '')
    
    try:
        rcv = recver.objects.get(id=recver_id) 
        
        recver_list = recver.objects.filter(name=name).exclude(id=recver_id)
        if recver_list.count() !=0 :
            # error , recver is exist.
            info = "接收人[ %s ]已经被其他同类型接收人占用，不能修改！" % name.encode('utf8')
            return render_to_response('alarm/recver/recver_edit.html', {'ret_info': info,'recver_data':recver,'rapp':rapp,'rgroup':rgroup}, context_instance = RequestContext(request))
        
        rcv.name=name
        rcv.phone=phone
        rcv.email=email
        rcv.msn=msn
        rcv.group_list = rgroup
        rcv.app_list = rapp
        rcv.save()

    except:
        return render_to_response('alarm/recver/recver_edit.html', {'ret_info':'找不到接收人！'}, context_instance = RequestContext(request))
    
    writeLog(getUser(request).id, 'alarm', "修改接收人%s信息" %  name.encode('utf8') )
    #writeLog(getUser(request).id, 22, "修改接收人[ %s ] %s" % ip.encode('utf8'), inf)
    info = "接收人[ %s ]保存成功！" % name.encode('utf8')
    return HttpResponseRedirect('/alarm/recver/list_recver/?&ret_info=%s' % (urllib2.quote( info )))

@authority_required(100)
def addRecver(request):
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    phone = request.REQUEST.get('phone', '')
    name = request.REQUEST.get('name', '')
    email = request.REQUEST.get('email', '')
    msn = request.REQUEST.get('msn', '')
    
    try:
        rcv= recver.objects.get(name=name) 
        # error , recver is exist.
        
        info = "接收人[ %s ]已经存在，不能重复添加！" % name.encode('utf8')
        return HttpResponseRedirect('/alarm/recver/list_recver/?ret_info=%s' % (urllib2.quote( info )))
    except:
        rcv = recver()
        rcv.name=name
        rcv.phone=phone
        rcv.email=email
        rcv.msn=msn
        rcv.group_list = rgroup
        rcv.app_list = rapp
        rcv.save()
        
    writeLog(getUser(request).id, 'alarm', "添加接收人%s" %  name.encode('utf8') )
    #writeLog(getUser(request).id, 20, "添加接收人[ %s ]" % ip.encode('utf8'))
    info = "接收人[ %s ]添加成功！" % (name.encode('utf8'))
    return HttpResponseRedirect('/alarm/recver/list_recver/?ret_info=%s' % (urllib2.quote( info )))


@authority_required(100)
def delRecver(request):
    recver_id = request.REQUEST.get('recver_id', '')
    recver_name = request.REQUEST.get('recver_name', '')
    try:
        dvc = recver.objects.get(id=recver_id) 
        dvc.delete()
        
    except:
        info = "接收人[ %s ]删除失败！" % recver_name.encode('utf8')
        return HttpResponseRedirect('/alarm/recver/list_recver/?ret_info=%s' % (urllib2.quote( info )))
    
    writeLog(getUser(request).id, 'alarm', "删除接收人%s" %  recver_name.encode('utf8') )
    #writeLog(getUser(request).id, 21, "删除接收人[ %s ]" % dip.encode('utf8'))
    info = "接收人[ %s ]删除成功！" % recver_name.encode('utf8')
    return HttpResponseRedirect('/alarm/recver/list_recver/?ret_info=%s' % (urllib2.quote( info )))
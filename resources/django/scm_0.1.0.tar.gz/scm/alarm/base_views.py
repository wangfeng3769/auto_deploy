# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage
from scm.common.models import group,device,application
from scm.alarm.models import base_threshold
import simplejson
import urllib2
from scm.util.decorators import authority_required

# webluker login main page
@login_required
def index(request):
    return listBase(request)

@authority_required(100)
def listBase(request):
    ret_info = request.REQUEST.get('ret_info', '')
    base_list = base_threshold.objects.all()
    
    return render_to_response('alarm/base/base_list.html', {'ret_info':ret_info, 'base_list':base_list}, context_instance = RequestContext(request))

@authority_required(100)
def editBasePage(request):
    base_id = request.REQUEST.get('base_id', '')
    rapp = request.REQUEST.get('rapp', '')
    rgroup = request.REQUEST.get('rgroup', '')
    try:
        base_data = base_threshold.objects.get(id=base_id)
        # error , zone is exist.
    except:
        return listBase(request)
    
    return render_to_response('alarm/base/base_edit.html', {'rapp':rapp,'rgroup':rgroup,'ret_info':'','base_data':base_data}, context_instance = RequestContext(request))

@authority_required(100)
def saveBase(request):
    base_id = request.REQUEST.get('base_id', '')
    
    try:
        dvc = base_threshold.objects.get(id=base_id)
        dvc.mem_left = request.REQUEST.get('mem_left', '0')
	dvc.load = request.REQUEST.get('load', '0')
	dvc.out_put = request.REQUEST.get('out_put', '0')
	dvc.in_put = request.REQUEST.get('in_put', '0')
	dvc.connects = request.REQUEST.get('connects', '0')
	dvc.tasks = request.REQUEST.get('tasks', '0')
	dvc.df_use = request.REQUEST.get('df_use', '0')

        dvc.save()
    except:
        return render_to_response('alarm/base/base_edit.html', {'ret_info':'找不到解析组！'}, context_instance = RequestContext(request))
    
    #writeLog(getUser(request).id, 22, "修改解析组[ %s ] %s" % ip.encode('utf8'), inf)
    info = "解析组[ %s ]保存成功！" % dvc.group.name.encode('utf8')
    return HttpResponseRedirect('/alarm/base/list_base/?&ret_info=%s' % (urllib2.quote( info )))

from django.db import models
from django.db import connection

# Create your models here.
class history(models.Model):
    device_sn = models.CharField(max_length=16,default='unkown')
    username = models.CharField(max_length=64,default='unkown')
    command = models.TextField(blank=True,default='unkown')
    exec_time = models.DateTimeField()
    modify_time = models.DateTimeField(auto_now=True)
    
    @staticmethod
    def getLog(dvc='',gp_id='',app_id=''):
        condition = '1=1 '
        
        if len(app_id) > 0:
            condition += 'AND d.app_id=%d ' % int(app_id)
        if len(gp_id) > 0:
            condition += 'AND d.group_id=%d ' % int(gp_id)
        if len(dvc) > 0:
            condition += "AND d.hostname='%s' " % (dvc)
        
        cursor = connection.cursor()
        cursor.execute("""
            SELECT d.group_id,d.app_id,d.hostname,l.username,l.command,l.exec_time
            FROM log_history AS l,common_device AS d
            WHERE %s AND l.device_sn=d.sn
            ORDER BY l.device_sn, l.exec_time DESC
            LIMIT 300
             """ % condition )
        
        return cursor.fetchall()

class login(models.Model):
    device_sn = models.CharField(max_length=16,default='unkown')
    username = models.CharField(max_length=64,default='unkown')
    login_ip = models.CharField(max_length=15,default='unkown')
    login_port = models.CharField(max_length=15,default='unkown')
    login_time = models.DateTimeField()
    modify_time = models.DateTimeField(auto_now=True)

    @staticmethod
    def getLog(dvc='',gp_id='',app_id=''):
        condition = '1=1 '
        
        if len(app_id) > 0:
            condition += 'AND d.app_id=%d ' % int(app_id)
        if len(gp_id) > 0:
            condition += 'AND d.group_id=%d ' % int(gp_id)
        if len(dvc) > 0:
            condition += "AND d.hostname='%s' " % (dvc)
        
        cursor = connection.cursor()
        cursor.execute("""
            SELECT d.group_id,d.app_id,d.hostname,l.username,l.login_ip,l.login_port,l.login_time
            FROM log_login AS l,common_device AS d
            WHERE %s AND l.device_sn=d.sn
            ORDER BY l.device_sn, l.login_time DESC
            LIMIT 300
             """ % condition )
        
        return cursor.fetchall()
    
def getTaskLog(dvc='',gp_id='',app_id=''):
        condition = '1=1 '
        
        if len(app_id) > 0:
            condition += 'AND d.app_id=%d ' % int(app_id)
        if len(gp_id) > 0:
            condition += 'AND d.group_id=%d ' % int(gp_id)
        if len(dvc) > 0:
            condition += "AND d.hostname='%s' " % (dvc)
        
        cursor = connection.cursor()
        cursor.execute("""
            SELECT d.group_id,d.app_id,d.hostname,l.task_info,l.status,l.add_time
            FROM common_task_queue AS l,common_device AS d
            WHERE %s AND l.device_sn=d.sn
            ORDER BY l.add_time DESC
            limit 300
             """ % condition )
        
        return cursor.fetchall()
    
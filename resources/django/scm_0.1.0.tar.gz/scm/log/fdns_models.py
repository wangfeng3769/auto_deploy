from scm.dbsettings import get_conn_log
    
def getQueriesDomainCount(conn, rdate, rsn, rdomain):
    try:
        cursor = conn.cursor()
        sql = """SELECT COUNT(*) FROM domain_sum_%s """ %(rdate)
        if len(rdomain) > 0:
            sql += "WHERE domain like \'%s%s%s\'" % ('%', rdomain, '%')
        cursor.execute(sql)
        row = cursor.fetchone()
        return row[0]
    except:
        return 0
    
def getQueriesDomainData(conn, rdate, rsn, rdomain, pstart, pend):
    try:
        cursor = conn.cursor()
        sql = """SELECT domain,device_sn,queries_type,queries_count,queries_ok_count,queries_ref_count,queries_nxr_count,queries_nxd_count,queries_rec_count,queries_fail_count
        FROM domain_sum_%s """ %(rdate)
        if len(rdomain) > 0:
            sql += "WHERE domain like \'%s%s%s\'" % ('%', rdomain, '%')
            
        sql += "order by queries_count desc limit %s,%s" % (pstart, pend)
        cursor.execute(sql)
        return cursor.fetchall()
    except:
        return []

def getQueriesLocaldnsCount(conn, rdate, rsn, rip):
    try:
        cursor = conn.cursor()
        sql = """SELECT COUNT(*) FROM localdns_sum_%s """ %(rdate)
        if len(rip) > 0:
            sql += "WHERE localdns like \'%s%s%s\'" % ('%', rip, '%')
        cursor.execute(sql)
        row = cursor.fetchone()
        return row[0]
    except:
        return 0


def getQueriesLocaldnsData(conn, rdate, rsn, rip, pstart, pend):
    try:
        cursor = conn.cursor()
        sql = """SELECT localdns,device_sn,queries_type,queries_count,queries_ok_count,queries_ref_count,queries_nxr_count,queries_nxd_count,queries_rec_count,queries_fail_count
        FROM localdns_sum_%s """ %(rdate)
        if len(rip) > 0:
            sql += "WHERE localdns like \'%s%s%s\'" % ('%', rip, '%')
            
        sql += "order by queries_count desc limit %s,%s" % (pstart, pend)
        cursor.execute(sql)
        return cursor.fetchall()
    except:
        return []
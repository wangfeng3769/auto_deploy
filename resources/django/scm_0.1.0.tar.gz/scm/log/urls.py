from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

from scm import settings

urlpatterns = patterns('',
     (r'^$','scm.log.views.index'),
     (r'^index/$','scm.log.views.index'),
     
     
     (r'^task/$','scm.log.views.taskLog'),
     (r'^login/$','scm.log.views.loginLog'),
     (r'^history/$','scm.log.views.historyLog'),
     (r'^dns/domain/$','scm.log.views.dnsDomainLog'),
     (r'^dns/localdns/$','scm.log.views.dnsLocaldnsLog'),
     
)

# vim: set encoding=utf-8: 
# -*- encoding=utf-8 -*-

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.template import RequestContext
from scm.common.models import group,device,application
from scm.log.models import login,history,getTaskLog
from scm.util.lukWeb import split_page, writeLog, getUser,generateXmlMessage, addUserDev
from scm.log.fdns_models import getQueriesDomainCount,getQueriesDomainData,getQueriesLocaldnsCount,getQueriesLocaldnsData
from scm.dbsettings import get_conn_log
import datetime
from scm.util.decorators import authority_required

@login_required
def index(request):
    return taskLog(request)

@authority_required(1)
def taskLog(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rhost = request.REQUEST.get('rhost', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    group_list = group.objects.all()
    app_list = application.objects.all()  
    group_map = {}
    for item in group_list:
        group_map[item.id] = item.name 
    app_map = {}
    for item in app_list:
        app_map[item.id] = item.cn_name 
        
    task_list = []
    for item in getTaskLog(rhost,rgroup,rapp):
        data = {}
        data['group'] =  group_map[item[0]]
        data['app'] =  app_map[item[1]]
        data['hostname'] =  item[2]
        data['task_info'] =  item[3]
        data['task_status'] =  item[4]
        data['add_time'] =  item[5]
        
        task_list.append(data)
      
        
    if hits:
        pagination = split_page(hits, '/log/task/?rapp=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rhost, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(len(task_list), '/log/task/?rapp=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rhost, rgroup), \
                                results_per_page, page)
        
    return render_to_response('log/task_log.html', {'rapp':rapp,'rhost':rhost,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'app_list':app_list,'task_list':task_list[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))



@authority_required(1)
def historyLog(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rhost = request.REQUEST.get('rhost', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    group_list = group.objects.all()
    app_list = application.objects.all()  
    group_map = {}
    for item in group_list:
        group_map[item.id] = item.name 
    app_map = {}
    for item in app_list:
        app_map[item.id] = item.cn_name 
        
    history_list = []
    for item in history.getLog(rhost,rgroup,rapp):
        data = {}
        data['group'] =  group_map[item[0]]
        data['app'] =  app_map[item[1]]
        data['hostname'] =  item[2]
        data['username'] =  item[3]
        data['command'] =  item[4]
        data['exec_time'] =  item[5]

        history_list.append(data)
      
        
    if hits:
        pagination = split_page(hits, '/log/history/?rapp=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rhost, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(len(history_list), '/log/history/?rapp=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rhost, rgroup), \
                                results_per_page, page)
        
    return render_to_response('log/history_log.html', {'rapp':rapp,'rhost':rhost,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'app_list':app_list,'history_list':history_list[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))


@authority_required(1)
def loginLog(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rapp = request.REQUEST.get('rapp', '')
    rhost = request.REQUEST.get('rhost', '')
    rgroup = request.REQUEST.get('rgroup', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    group_list = group.objects.all()
    app_list = application.objects.all()  
    group_map = {}
    for item in group_list:
        group_map[item.id] = item.name 
    app_map = {}
    for item in app_list:
        app_map[item.id] = item.cn_name 
        
    login_list = []
    for item in login.getLog(rhost,rgroup,rapp):
        data = {}
        data['group'] =  group_map[item[0]]
        data['app'] =  app_map[item[1]]
        data['hostname'] =  item[2]
        data['username'] =  item[3]
        data['login_ip'] =  item[4]
        data['login_port'] =  item[5]
        data['login_time'] =  item[6]

        login_list.append(data)
      
        
    if hits:
        pagination = split_page(hits, '/log/login/?rapp=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rhost, rgroup), \
                                results_per_page, page)
    else:
        pagination = split_page(len(login_list), '/log/login/?rapp=%s&rhost=%s&rgroup=%s&'% \
                                (rapp, rhost, rgroup), \
                                results_per_page, page)
        
    return render_to_response('log/login_log.html', {'rapp':rapp,'rhost':rhost,'rgroup':rgroup,'ret_info':ret_info,'group_list':group_list,'app_list':app_list,'login_list':login_list[pagination['start']:pagination['end']], 'pagination':pagination}, context_instance = RequestContext(request))


@authority_required(1)
def dnsDomainLog(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rdate = request.REQUEST.get('rdate',  str(datetime.date.today().year)[2:] + str(datetime.date.today().month) + str(datetime.date.today().day) )
    rsn = request.REQUEST.get('rsn', '')
    rdomain = request.REQUEST.get('rdomain', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    conn = get_conn_log()
    dcount = getQueriesDomainCount(conn, rdate, rsn, rdomain)
    if hits:
        pagination = split_page(hits, '/log/dns/domain/?rdate=%s&rsn=%s&'% \
                                (rdate, rsn), \
                                results_per_page, page)
    else:
        pagination = split_page(dcount, '/log/dns/domain/?rdate=%s&rsn=%s&'% \
                                (rdate, rsn), \
                                results_per_page, page)

    dataList = []
    for row in getQueriesDomainData(conn, rdate, rsn, rdomain, pagination['start'], pagination['end']):
        item = {}
	item['domain'] = row[0]
	item['device_sn'] = row[1]
	item['queries_type'] = row[2]
	item['queries_count'] = row[3]
	item['queries_ok_count'] = row[4]
	item['queries_ref_count'] = row[5]
	item['queries_nxr_count'] = row[6]
	item['queries_nxd_count'] = row[7]
	item['queries_rec_count'] = row[8]
	item['queries_fail_count'] = row[9]
        dataList.append(item)
    
    conn.close()
    return render_to_response('log/domain_log.html', {'rdate':rdate, 'rsn':rsn,'ret_info':ret_info,'dataList':dataList, 'pagination':pagination}, context_instance = RequestContext(request))


@authority_required(1)
def dnsLocaldnsLog(request):
    ret_info = request.REQUEST.get('ret_info', '')
    rdate = request.REQUEST.get('rdate',  str(datetime.date.today().year)[2:] + str(datetime.date.today().month) + str(datetime.date.today().day) )
    rsn = request.REQUEST.get('rsn', '')
    rip = request.REQUEST.get('rip', '')
    
    hits=int(request.REQUEST.get('hits',0))
    pages=int(request.REQUEST.get('pages',0))
    results_per_page=int(request.REQUEST.get('numpp', '30'))
    page=int(request.REQUEST.get('page',1)) 
         
    conn = get_conn_log()
    dcount = getQueriesLocaldnsCount(conn, rdate, rsn, rip)
    if hits:
        pagination = split_page(hits, '/log/dns/localdns/?rdate=%s&rsn=%s&'% \
                                (rdate, rsn), \
                                results_per_page, page)
    else:
        pagination = split_page(dcount, '/log/dns/localdns/?rdate=%s&rsn=%s&'% \
                                (rdate, rsn), \
                                results_per_page, page)

    dataList = []
    for row in getQueriesLocaldnsData(conn, rdate, rsn, rip, pagination['start'], pagination['end']):
        item = {}
	item['localdns'] = row[0]
	item['device_sn'] = row[1]
	item['queries_type'] = row[2]
	item['queries_count'] = row[3]
	item['queries_ok_count'] = row[4]
	item['queries_ref_count'] = row[5]
	item['queries_nxr_count'] = row[6]
	item['queries_nxd_count'] = row[7]
	item['queries_rec_count'] = row[8]
	item['queries_fail_count'] = row[9]
        dataList.append(item)
    
    conn.close()
    return render_to_response('log/localdns_log.html', {'rdate':rdate, 'rsn':rsn,'ret_info':ret_info,'dataList':dataList, 'pagination':pagination}, context_instance = RequestContext(request))

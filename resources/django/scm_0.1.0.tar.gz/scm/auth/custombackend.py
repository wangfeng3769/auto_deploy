# -*- coding:utf8 -*-

from django.contrib.auth.models import User
from scm.util.webservice import remote_auth
#from scm.user.models import User_Power
#from django.contrib.auth.backends import ModelBackend

class Backend:
    def authenticate(self, username=None, password=None):
        try:
            retcode = remote_auth(username,password)
        except Exception,e:
            raise Exception("remote authenticate interface error：%s" % (e))
        if retcode == 0:
            #remote auth success
            try:
                user = User.objects.get(username=username)
                return user
            except User.DoesNotExist:
                #user is not exist,first login,create user
                #user = User.objects.create_user(username = username, email = username)
                #User_Power(user_id=user.id,group=User_Power.GROUP[2][1],power=User_Power.POWER[2][1]).save()
                return None
        return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None

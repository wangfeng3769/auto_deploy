# -*- coding:utf8 -*-

from django.contrib.auth.views import login
from django.contrib.auth import login as login_without_pwd
#from django.shortcuts import render_to_response
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
#from form import AuthenticationForm
from scm.util.webservice import get_username

def check_user(request):
    
    sessionID = request.REQUEST.get('sid')
    
    if sessionID:
        try:
            username = get_username(sessionID)
        except Exception,e:
            raise Exception("remote authenticate interface error：%s" % (e))
        if username:
            try:
                user = User.objects.get(username=username)
                user.backend = 'django.contrib.auth.backends.ModelBackend'    
                login_without_pwd(request, user)
                return HttpResponseRedirect('/accounts/profile/')
            except User.DoesNotExist:
                return login(request)         
    return login(request)
    

    #if request.method == "POST":
        #return login(request,authentication_form = AuthenticationForm)
    #else:   
        #username = request.REQUEST.get('username')
        #password = request.REQUEST.get('password')
        
        #return render_to_response('registration/login_auth.html',{'username':username,'password':password})
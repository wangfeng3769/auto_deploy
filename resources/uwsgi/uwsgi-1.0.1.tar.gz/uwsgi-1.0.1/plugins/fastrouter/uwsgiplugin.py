
NAME='fastrouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['fastrouter']

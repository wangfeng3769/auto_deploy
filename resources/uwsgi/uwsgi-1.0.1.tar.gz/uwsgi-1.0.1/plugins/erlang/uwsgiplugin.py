
NAME='erlang'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lei']

GCC_LIST = ['erlang']
